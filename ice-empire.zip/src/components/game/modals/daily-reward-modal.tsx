'use client';

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useGameStore } from '@/lib/game-store';
import { Check, Flame } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DailyRewardModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const REWARDS = [
  { day: 1, label: '100 ◆', special: false },
  { day: 2, label: '50 ❄', special: false },
  { day: 3, label: '200 ◆', special: false },
  { day: 4, label: 'Ледяной сундук', special: false },
  { day: 5, label: '300 ◆', special: false },
  { day: 6, label: '100 ❄', special: false },
  { day: 7, label: 'Epic существо', special: true },
  { day: 8, label: '400 ◆', special: false },
  { day: 9, label: '150 ❄', special: false },
  { day: 10, label: 'Северный сундук', special: false },
  { day: 14, label: 'Legendary существо', special: true },
  { day: 21, label: 'Сундук Авроры', special: true },
  { day: 30, label: 'Legendary сундук', special: true },
];

export function DailyRewardModal({ open, onOpenChange }: DailyRewardModalProps) {
  const dailyStreak = useGameStore((s) => s.dailyStreak);
  const lastDailyClaim = useGameStore((s) => s.lastDailyClaim);
  const claimDailyReward = useGameStore((s) => s.claimDailyReward);

  const canClaim = Date.now() - lastDailyClaim >= 24 * 3600 * 1000;

  const handleClaim = () => {
    const result = claimDailyReward();
    if (result.claimed) {
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass-strong border-border max-w-md">
        <DialogHeader>
          <DialogTitle className="text-frost-white flex items-center gap-2 text-[15px]">
            <Flame className="w-4 h-4 text-gold" strokeWidth={1.75} />
            Ежедневные награды
          </DialogTitle>
          <DialogDescription className="text-muted-fg text-[11px]">
            Серия: {dailyStreak} дней · заходи каждый день
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-4 gap-1.5 mt-2">
          {REWARDS.map((reward) => {
            const claimed = dailyStreak >= reward.day;
            const isNext = !claimed && dailyStreak + 1 === reward.day;
            return (
              <div
                key={reward.day}
                className={cn(
                  'relative aspect-square rounded-lg p-1.5 flex flex-col items-center justify-center text-center',
                  claimed
                    ? 'surface-elevated'
                    : isNext
                    ? 'surface-elevated ring-active'
                    : 'surface-sunken',
                  reward.special && 'col-span-2'
                )}
              >
                <span className="text-[9px] text-muted-fg absolute top-1 left-1.5">{reward.day}</span>
                {claimed && (
                  <Check className="w-3 h-3 text-ice absolute top-1 right-1.5" strokeWidth={2.5} />
                )}
                <div className="text-base mb-0.5">
                  {reward.label.includes('◆') ? '◆' :
                   reward.label.includes('❄') ? '❄' :
                   reward.label.includes('существо') ? '✦' : '🎁'}
                </div>
                <span className={cn(
                  'text-[9px] leading-tight',
                  reward.special ? 'text-gold font-semibold' : 'text-frost-white/80'
                )}>
                  {reward.label}
                </span>
              </div>
            );
          })}
        </div>

        <button
          onClick={handleClaim}
          disabled={!canClaim}
          className={cn(
            'w-full mt-4 py-2.5 rounded-lg font-semibold text-[13px] transition-all',
            canClaim
              ? 'bg-ice text-ice-deep hover:opacity-90 active:scale-[0.98]'
              : 'surface-sunken text-muted-fg'
          )}
        >
          {canClaim ? 'Получить награду' : 'Уже получено сегодня'}
        </button>
      </DialogContent>
    </Dialog>
  );
}
