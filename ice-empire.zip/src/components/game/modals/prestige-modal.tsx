'use client';

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useGameStore } from '@/lib/game-store';
import { Crown, AlertTriangle } from 'lucide-react';
import { formatNumber } from '@/lib/format';
import { toast } from 'sonner';
import { useState } from 'react';
import { cn } from '@/lib/utils';

interface PrestigeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function PrestigeModal({ open, onOpenChange }: PrestigeModalProps) {
  const playerLevel = useGameStore((s) => s.playerLevel);
  const totalEarned = useGameStore((s) => s.totalEarned);
  const northCrowns = useGameStore((s) => s.northCrowns);
  const prestigeLevel = useGameStore((s) => s.prestigeLevel);
  const prestige = useGameStore((s) => s.prestige);
  const [confirming, setConfirming] = useState(false);

  const canPrestige = playerLevel >= 100;
  const crownsToGain = canPrestige ? Math.max(1, Math.floor(Math.sqrt(totalEarned / 1000000))) : 0;

  const handlePrestige = () => {
    if (!confirming) {
      setConfirming(true);
      return;
    }
    const result = prestige();
    if (result.success) {
      toast.success('Престиж выполнен', {
        description: `+${result.crownsGained} ♛ Корон Севера`,
      });
      onOpenChange(false);
      setConfirming(false);
    } else {
      toast.error('Недостаточно прогресса для престижа');
      setConfirming(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); setConfirming(false); }}>
      <DialogContent className="glass-strong border-border max-w-md">
        <DialogHeader>
          <DialogTitle className="text-gold flex items-center gap-2 text-[15px]">
            <Crown className="w-4 h-4" strokeWidth={1.75} />
            Престиж · Короны Севера
          </DialogTitle>
          <DialogDescription className="text-muted-fg text-[11px]">
            Начни заново с постоянными бонусами
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3 mt-2">
          <div className="grid grid-cols-3 gap-1.5">
            <Stat label="Уровень" value={`${playerLevel}/100`} accent={canPrestige ? 'text-ice' : 'text-red-400'} />
            <Stat label="Престиж" value={`P${prestigeLevel}`} accent="text-gold" />
            <Stat label="Короны" value={`${northCrowns} ♛`} accent="text-gold" />
          </div>

          <div className="surface-sunken rounded-lg p-3 space-y-1.5">
            <p className="text-[11px] text-muted-fg leading-relaxed">
              После 100 уровня ты можешь сбросить прогресс в обмен на
              <span className="text-gold font-semibold"> Короны Севера ♛</span>. Каждая корона даёт:
            </p>
            <ul className="text-[11px] text-frost-white/80 space-y-0.5 pl-3">
              <li className="flex items-center gap-1.5"><span className="text-ice">·</span> +10% к доходу навсегда</li>
              <li className="flex items-center gap-1.5"><span className="text-aurora">·</span> +5% к удаче</li>
              <li className="flex items-center gap-1.5"><span className="text-ice">·</span> +5% к скорости экспедиций</li>
            </ul>
          </div>

          {canPrestige && (
            <div className="rounded-lg bg-gold/10 border border-gold/20 p-3 text-center">
              <p className="text-[10px] text-gold/70 uppercase tracking-wider mb-1">Будет получено</p>
              <p className="text-2xl font-semibold text-gold tabular-nums">+{crownsToGain} ♛</p>
              <p className="text-[9px] text-gold/50 mt-1">из {formatNumber(totalEarned)} ◆ всего добыто</p>
            </div>
          )}

          {canPrestige && confirming && (
            <div className="rounded-lg bg-red-500/10 border border-red-500/20 p-2.5 flex items-start gap-2">
              <AlertTriangle className="w-3.5 h-3.5 text-red-400 flex-shrink-0 mt-0.5" strokeWidth={2} />
              <p className="text-[11px] text-red-300">
                Существа, локации и кристаллы будут сброшены. Останутся: ❄ осколки, ✦ эссенция, ♛ короны, ★ звёзды.
              </p>
            </div>
          )}

          <button
            onClick={handlePrestige}
            disabled={!canPrestige}
            className={cn(
              'w-full py-2.5 rounded-lg font-semibold text-[13px] transition-all',
              !canPrestige
                ? 'surface-sunken text-muted-fg'
                : confirming
                ? 'bg-red-500/20 text-red-300 active:scale-[0.98]'
                : 'bg-gold text-ice-deep hover:opacity-90 active:scale-[0.98]'
            )}
          >
            {!canPrestige
              ? `Доступно с 100 уровня (сейчас ${playerLevel})`
              : confirming
              ? 'Подтвердить престиж'
              : `Выполнить престиж · +${crownsToGain} ♛`}
          </button>
          {confirming && (
            <button
              onClick={() => setConfirming(false)}
              className="w-full text-[11px] text-muted-fg hover:text-frost-white"
            >
              Отмена
            </button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent: string }) {
  return (
    <div className="surface-sunken rounded-lg p-2 text-center">
      <p className="text-[9px] text-muted-fg uppercase tracking-wider">{label}</p>
      <p className={cn('text-[12px] font-semibold tabular-nums mt-0.5', accent)}>{value}</p>
    </div>
  );
}
