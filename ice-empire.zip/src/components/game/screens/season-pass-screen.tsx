'use client';

import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore } from '@/lib/game-store';
import {
  SEASON_PASS,
  SEASON_XP_REWARDS,
  RARITY_META,
  getSeasonTimeRemaining,
  getSeasonProgress,
  type SeasonTier,
  type SeasonTierReward,
} from '@/lib/game-data';
import { formatNumber } from '@/lib/format';
import {
  Trophy, Star, Crown, Lock, Check, Gift, Zap,
  ChevronRight, Clock, Sparkles, Shield, Gem,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export function SeasonPassScreen() {
  const seasonXp = useGameStore((s) => s.seasonXp);
  const seasonPremium = useGameStore((s) => s.seasonPremium);
  const telegramStars = useGameStore((s) => s.telegramStars);
  const purchaseSeasonPremium = useGameStore((s) => s.purchaseSeasonPremium);
  const claimSeasonTier = useGameStore((s) => s.claimSeasonTier);
  const getSeasonTierStatus = useGameStore((s) => s.getSeasonTierStatus);

  const progress = getSeasonProgress(seasonXp);
  const timeLeft = getSeasonTimeRemaining();
  const [showBuyPremium, setShowBuyPremium] = useState(false);
  const [claimedAnimation, setClaimedAnimation] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to current tier
  useEffect(() => {
    if (scrollRef.current) {
      const currentTierEl = scrollRef.current.querySelector(`[data-tier="${progress.currentTier + 1}"]`);
      if (currentTierEl) {
        currentTierEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }, [progress.currentTier]);

  const handleBuyPremium = () => {
    const result = purchaseSeasonPremium();
    if (result.success) {
      toast.success('Премиум-пропуск активирован!', {
        description: 'Теперь тебе доступны премиум-награды!',
      });
      setShowBuyPremium(false);
    } else {
      toast.error(result.error || 'Ошибка покупки');
    }
  };

  const handleClaim = (tierLevel: number, track: 'free' | 'premium') => {
    const result = claimSeasonTier(tierLevel, track);
    if (result.success && result.reward) {
      setClaimedAnimation(`${tierLevel}-${track}`);
      setTimeout(() => setClaimedAnimation(null), 600);
      toast.success('Награда получена!', {
        description: result.reward.label,
      });
    } else if (!result.success) {
      toast.error(result.error || 'Ошибка');
    }
  };

  // Calculate claimable tiers count
  let claimableCount = 0;
  for (const tier of SEASON_PASS.tiers) {
    if (tier.level > progress.currentTier) break;
    const status = getSeasonTierStatus(tier.level);
    if (!status.freeClaimed) claimableCount++;
    if (status.premiumUnlocked && !status.premiumClaimed) claimableCount++;
  }

  return (
    <div className="px-4 pt-5 pb-8 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-[17px] font-semibold text-frost-white tracking-tight">
            {SEASON_PASS.emoji} {SEASON_PASS.name}
          </h2>
          <p className="text-[11px] text-muted-fg mt-0.5">{SEASON_PASS.description}</p>
        </div>
        <div className="flex flex-col items-end">
          <div className="flex items-center gap-1 text-[11px] text-ice">
            <Clock className="w-3 h-3" strokeWidth={2} />
            <span>{timeLeft.days}д {timeLeft.hours}ч</span>
          </div>
          {claimableCount > 0 && (
            <span className="text-[9px] text-gold font-semibold animate-pulse-soft mt-0.5">
              {claimableCount} наград!
            </span>
          )}
        </div>
      </div>

      {/* Season progress bar */}
      <div className="surface rounded-xl p-3.5">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-ice" strokeWidth={2} />
            <span className="text-[12px] font-semibold text-frost-white">
              Тир {progress.currentTier} / {SEASON_PASS.tiers.length}
            </span>
          </div>
          <span className="text-[11px] text-ice tabular-nums">
            {formatNumber(seasonXp)} XP
          </span>
        </div>
        <div className="h-2.5 bg-slate-700/40 rounded-full overflow-hidden">
          <motion.div
            className="h-full rounded-full"
            style={{
              background: 'linear-gradient(90deg, oklch(0.55 0.12 215), oklch(0.78 0.10 215), oklch(0.65 0.14 295))',
            }}
            initial={{ width: 0 }}
            animate={{ width: `${progress.progress * 100}%` }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
          />
        </div>
        <div className="flex items-center justify-between mt-1.5">
          <span className="text-[9px] text-muted-fg">
            До след. тира: {formatNumber(progress.nextTierXp - seasonXp)} XP
          </span>
          <span className="text-[9px] text-muted-fg">
            {Math.round(progress.progress * 100)}%
          </span>
        </div>
      </div>

      {/* Premium banner */}
      {!seasonPremium ? (
        <button
          onClick={() => setShowBuyPremium(true)}
          className="w-full relative overflow-hidden rounded-xl p-4 text-left group transition-all hover:scale-[1.01]"
          style={{
            background: 'linear-gradient(135deg, oklch(0.30 0.06 280), oklch(0.25 0.10 295), oklch(0.22 0.12 85))',
            border: '1px solid oklch(0.78 0.12 85 / 30%)',
          }}
        >
          <div className="absolute inset-0 opacity-20"
            style={{
              background: 'linear-gradient(45deg, transparent 30%, oklch(0.78 0.12 85 / 0.3) 50%, transparent 70%)',
              backgroundSize: '200% 200%',
              animation: 'shimmerMove 3s ease-in-out infinite',
            }}
          />
          <div className="relative flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
              style={{ background: 'oklch(0.78 0.13 85 / 0.15)' }}
            >
              <Crown className="w-6 h-6 text-gold" strokeWidth={1.75} />
            </div>
            <div className="flex-1">
              <p className="text-[14px] font-semibold text-gold">Премиум-пропуск</p>
              <p className="text-[10px] text-frost-white/60 mt-0.5">
                Открой премиум-награды: рамки, скины, до Ancient редкости!
              </p>
              <div className="flex items-center gap-1.5 mt-1.5">
                <Star className="w-3 h-3 text-gold" strokeWidth={2} />
                <span className="text-[12px] font-semibold text-gold">{SEASON_PASS.premiumCost} ★</span>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-gold/60 group-hover:text-gold transition-colors" strokeWidth={1.75} />
          </div>
        </button>
      ) : (
        <div
          className="w-full rounded-xl p-3 flex items-center gap-3"
          style={{
            background: 'linear-gradient(135deg, oklch(0.78 0.13 85 / 0.08), oklch(0.65 0.14 295 / 0.08))',
            border: '1px solid oklch(0.78 0.12 85 / 20%)',
          }}
        >
          <Crown className="w-5 h-5 text-gold" strokeWidth={1.75} />
          <span className="text-[12px] font-semibold text-gold">Премиум активен</span>
          <Sparkles className="w-3.5 h-3.5 text-gold/70 ml-auto" strokeWidth={2} />
        </div>
      )}

      {/* XP sources info */}
      <div className="surface rounded-xl p-3">
        <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em] mb-2">Как получить XP</p>
        <div className="grid grid-cols-2 gap-1.5">
          <XpSource icon={<Shield className="w-3 h-3" strokeWidth={2} />} label="Убийство босса" xp={SEASON_XP_REWARDS.bossKill} />
          <XpSource icon={<Gift className="w-3 h-3" strokeWidth={2} />} label="Открытие сундука" xp={SEASON_XP_REWARDS.chestOpen} />
          <XpSource icon={<Zap className="w-3 h-3" strokeWidth={2} />} label="Ежедневная награда" xp={SEASON_XP_REWARDS.dailyClaim} />
          <XpSource icon={<Star className="w-3 h-3" strokeWidth={2} />} label="Престиж" xp={SEASON_XP_REWARDS.prestige} />
          <XpSource icon={<Trophy className="w-3 h-3" strokeWidth={2} />} label="Апгрейд существа" xp={SEASON_XP_REWARDS.creatureUpgrade} />
          <XpSource icon={<Crown className="w-3 h-3" strokeWidth={2} />} label="Взнос в клан" xp={SEASON_XP_REWARDS.clanContribute} />
        </div>
      </div>

      {/* Tier list */}
      <div ref={scrollRef} className="space-y-2">
        <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em]">
          Награды · {SEASON_PASS.tiers.length} тиров
        </p>
        {SEASON_PASS.tiers.map((tier) => (
          <TierCard
            key={tier.level}
            tier={tier}
            currentTier={progress.currentTier}
            seasonPremium={seasonPremium}
            getSeasonTierStatus={getSeasonTierStatus}
            onClaim={handleClaim}
            isAnimating={claimedAnimation === `${tier.level}-free` || claimedAnimation === `${tier.level}-premium`}
          />
        ))}
      </div>

      {/* Buy Premium Modal */}
      <AnimatePresence>
        {showBuyPremium && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowBuyPremium(false)}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
          >
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 30, opacity: 0 }}
              transition={{ type: 'tween', duration: 0.2 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-sm rounded-2xl glass-strong overflow-hidden"
            >
              <div className="p-5 text-center space-y-4">
                <div className="w-16 h-16 rounded-2xl mx-auto flex items-center justify-center"
                  style={{ background: 'oklch(0.78 0.13 85 / 0.12)' }}
                >
                  <Crown className="w-8 h-8 text-gold" strokeWidth={1.5} />
                </div>
                <div>
                  <h3 className="text-[16px] font-semibold text-frost-white">Премиум-пропуск</h3>
                  <p className="text-[11px] text-muted-fg mt-1">
                    Разблокируй премиум-награды на всех 50 тирах: рамки, скины, кристаллы и Telegram Stars!
                  </p>
                </div>

                {/* Premium rewards preview */}
                <div className="grid grid-cols-3 gap-2">
                  <div className="surface rounded-lg p-2 text-center">
                    <p className="text-[9px] text-muted-fg uppercase">Рамки</p>
                    <p className="text-[13px] font-semibold text-aurora">11</p>
                  </div>
                  <div className="surface rounded-lg p-2 text-center">
                    <p className="text-[9px] text-muted-fg uppercase">Скины</p>
                    <p className="text-[13px] font-semibold text-ice">7</p>
                  </div>
                  <div className="surface rounded-lg p-2 text-center">
                    <p className="text-[9px] text-muted-fg uppercase">★ Stars</p>
                    <p className="text-[13px] font-semibold text-gold">225</p>
                  </div>
                </div>

                <div className="flex items-center justify-center gap-2">
                  <span className="text-[10px] text-muted-fg">Стоимость:</span>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-gold" strokeWidth={2} />
                    <span className="text-[18px] font-bold text-gold">{SEASON_PASS.premiumCost}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1 justify-center text-[10px] text-muted-fg">
                  <span>У тебя:</span>
                  <Star className="w-3 h-3 text-gold" strokeWidth={2} />
                  <span className={cn('font-semibold', telegramStars >= SEASON_PASS.premiumCost ? 'text-gold' : 'text-red-400')}>
                    {telegramStars} ★
                  </span>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => setShowBuyPremium(false)}
                    className="flex-1 py-2.5 rounded-xl surface-sunken text-[12px] font-medium text-muted-fg hover:text-frost-white transition-colors"
                  >
                    Отмена
                  </button>
                  <button
                    onClick={handleBuyPremium}
                    disabled={telegramStars < SEASON_PASS.premiumCost}
                    className={cn(
                      'flex-1 py-2.5 rounded-xl text-[12px] font-semibold transition-all',
                      telegramStars >= SEASON_PASS.premiumCost
                        ? 'text-ice-deep hover:brightness-110'
                        : 'opacity-40 cursor-not-allowed surface-sunken text-muted-fg'
                    )}
                    style={{
                      background: telegramStars >= SEASON_PASS.premiumCost
                        ? 'linear-gradient(135deg, oklch(0.78 0.12 85), oklch(0.72 0.14 55))'
                        : undefined,
                    }}
                  >
                    Активировать
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ===== Tier Card =====
function TierCard({
  tier,
  currentTier,
  seasonPremium,
  getSeasonTierStatus,
  onClaim,
  isAnimating,
}: {
  tier: SeasonTier;
  currentTier: number;
  seasonPremium: boolean;
  getSeasonTierStatus: (level: number) => { freeUnlocked: boolean; premiumUnlocked: boolean; freeClaimed: boolean; premiumClaimed: boolean };
  onClaim: (level: number, track: 'free' | 'premium') => void;
  isAnimating: boolean;
}) {
  const status = getSeasonTierStatus(tier.level);
  const isCurrent = tier.level === currentTier + 1;
  const isPast = tier.level <= currentTier;
  const isLocked = !isPast && !isCurrent;

  return (
    <div
      data-tier={tier.level}
      className={cn(
        'surface rounded-xl overflow-hidden transition-all',
        isCurrent && 'ring-active',
        isLocked && 'opacity-50',
      )}
    >
      {/* Tier header */}
      <div className={cn(
        'flex items-center justify-between px-3 py-2',
        isCurrent && 'season-tier-current-header',
      )}>
        <div className="flex items-center gap-2">
          <div className={cn(
            'w-7 h-7 rounded-lg flex items-center justify-center text-[11px] font-bold',
            isPast ? 'bg-ice/20 text-ice' : isCurrent ? 'bg-aurora/20 text-aurora' : 'surface-sunken text-muted-fg',
          )}>
            {isPast && status.freeClaimed && (seasonPremium ? status.premiumClaimed : true) ? (
              <Check className="w-3.5 h-3.5" strokeWidth={2.5} />
            ) : (
              tier.level
            )}
          </div>
          <span className={cn(
            'text-[11px] font-medium',
            isPast ? 'text-frost-white' : isCurrent ? 'text-ice' : 'text-muted-fg',
          )}>
            Тир {tier.level}
          </span>
          {isCurrent && (
            <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-aurora/15 text-aurora font-semibold uppercase tracking-wider">
              Текущий
            </span>
          )}
        </div>
        <span className="text-[9px] text-muted-fg tabular-nums">
          {formatNumber(tier.xpRequired)} XP
        </span>
      </div>

      {/* Rewards row */}
      <div className="grid grid-cols-2 gap-1 px-3 pb-3 pt-1">
        {/* Free reward */}
        <RewardCell
          reward={tier.freeReward}
          track="free"
          unlocked={status.freeUnlocked || isPast}
          claimed={status.freeClaimed}
          onClaim={() => onClaim(tier.level, 'free')}
          isAnimating={isAnimating && status.freeClaimed}
        />
        {/* Premium reward */}
        <RewardCell
          reward={tier.premiumReward}
          track="premium"
          unlocked={(status.premiumUnlocked || (isPast && seasonPremium)) && seasonPremium}
          claimed={status.premiumClaimed}
          onClaim={() => onClaim(tier.level, 'premium')}
          isAnimating={isAnimating && status.premiumClaimed}
          isPremiumLocked={!seasonPremium}
        />
      </div>
    </div>
  );
}

// ===== Reward Cell =====
function RewardCell({
  reward,
  track,
  unlocked,
  claimed,
  onClaim,
  isAnimating,
  isPremiumLocked,
}: {
  reward: SeasonTierReward;
  track: 'free' | 'premium';
  unlocked: boolean;
  claimed: boolean;
  onClaim: () => void;
  isAnimating: boolean;
  isPremiumLocked?: boolean;
}) {
  const rarityMeta = reward.rarity ? RARITY_META[reward.rarity] : null;
  const isFrameOrSkin = reward.type === 'frame' || reward.type === 'skin';
  const isStars = reward.type === 'stars';

  return (
    <motion.button
      onClick={unlocked && !claimed ? onClaim : undefined}
      disabled={!unlocked || claimed}
      className={cn(
        'relative rounded-lg p-2.5 text-left transition-all',
        track === 'premium' ? 'season-premium-cell' : 'surface-sunken',
        unlocked && !claimed && 'cursor-pointer hover:brightness-110',
        claimed && 'opacity-60',
        isAnimating && 'reward-pop-in',
      )}
      whileTap={unlocked && !claimed ? { scale: 0.95 } : undefined}
    >
      {/* Track label */}
      <div className="flex items-center gap-1 mb-1.5">
        <span className={cn(
          'text-[7px] uppercase tracking-[0.15em] font-semibold',
          track === 'free' ? 'text-ice/70' : 'text-gold/70',
        )}>
          {track === 'free' ? 'Бесплатно' : 'Премиум'}
        </span>
        {isPremiumLocked && track === 'premium' && (
          <Lock className="w-2 h-2 text-muted-fg" strokeWidth={2} />
        )}
      </div>

      {/* Reward content */}
      <div className="flex items-center gap-2">
        <div className={cn(
          'w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0',
          isFrameOrSkin && 'text-sm',
          isStars && 'bg-gold/10',
        )}
          style={rarityMeta ? { boxShadow: `0 0 8px ${rarityMeta.glow.replace('rarity-glow-', '')}20` } : undefined}
        >
          {getRewardEmoji(reward)}
        </div>
        <div className="flex-1 min-w-0">
          <p className={cn(
            'text-[10px] font-medium truncate',
            claimed ? 'text-muted-fg' : 'text-frost-white',
          )}>
            {reward.label}
          </p>
          {reward.rarity && (
            <span className={cn('text-[7px] uppercase tracking-wider', rarityMeta?.color)}>
              {rarityMeta?.label}
            </span>
          )}
        </div>
      </div>

      {/* Claimed overlay */}
      {claimed && (
        <div className="absolute inset-0 rounded-lg flex items-center justify-center bg-black/30">
          <Check className="w-4 h-4 text-ice" strokeWidth={2.5} />
        </div>
      )}

      {/* Claimable indicator */}
      {unlocked && !claimed && (
        <div className="absolute top-1 right-1">
          <span className="w-2 h-2 rounded-full bg-ice animate-pulse-soft block" />
        </div>
      )}
    </motion.button>
  );
}

function getRewardEmoji(reward: SeasonTierReward): string {
  switch (reward.type) {
    case 'crystals': return '💎';
    case 'iceShards': return '❄️';
    case 'auroraEssence': return '✦';
    case 'stars': return '★';
    case 'frame': return '🖼️';
    case 'skin': return '🎭';
    case 'creature': return '🐾';
    case 'chest': return '🎁';
    default: return '?';
  }
}

// ===== XP Source =====
function XpSource({ icon, label, xp }: { icon: React.ReactNode; label: string; xp: number }) {
  return (
    <div className="flex items-center gap-1.5 surface-sunken rounded-lg px-2 py-1.5">
      <span className="text-ice/70">{icon}</span>
      <span className="text-[9px] text-muted-fg flex-1 truncate">{label}</span>
      <span className="text-[9px] text-ice font-semibold tabular-nums">+{xp}</span>
    </div>
  );
}
