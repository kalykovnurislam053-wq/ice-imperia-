'use client';

import { useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore } from '@/lib/game-store';
import { BOSSES, CREATURES, RARITY_META, checkBossRequirements, type Boss } from '@/lib/game-data';
import { formatNumber, formatTimeShort } from '@/lib/format';
import { Swords, Clock, Skull, Trophy, Zap, Heart, Shield, AlertCircle, Lock } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

export function BossesScreen() {
  const activeBoss = useGameStore((s) => s.activeBoss);
  const startBoss = useGameStore((s) => s.startBoss);
  const attackBoss = useGameStore((s) => s.attackBoss);
  const lastBossDefeat = useGameStore((s) => s.lastBossDefeat);
  const bossesDefeated = useGameStore((s) => s.bossesDefeated);
  const getIncomePerSecond = useGameStore((s) => s.getIncomePerSecond);
  const ownedCreatures = useGameStore((s) => s.ownedCreatures);
  const getClanBonus = useGameStore((s) => s.getClanBonus);
  const [now, setNow] = useState(Date.now());

  // Boss defeat effect state
  const [defeatEffect, setDefeatEffect] = useState<{
    boss: Boss;
    reward: number;
    auroraEssence: number;
    timestamp: number;
  } | null>(null);

  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  const income = getIncomePerSecond();
  const clanBonus = getClanBonus();
  const tapDamage = Math.max(10, Math.floor(income * 0.5 * (1 + clanBonus.clickBonus / 100)));

  const handleAttack = useCallback(() => {
    if (!activeBoss) return;
    const result = attackBoss(tapDamage);
    if (result.defeated && result.reward) {
      const boss = BOSSES.find((b) => b.id === activeBoss.bossId);
      if (boss) {
        setDefeatEffect({ boss, reward: result.reward, auroraEssence: boss.auroraEssence, timestamp: Date.now() });
        // Auto-dismiss after 4 seconds
        setTimeout(() => setDefeatEffect(null), 4000);
      }
      toast.success('Босс повержен', {
        description: `+${formatNumber(result.reward)} ◆ · +${boss?.auroraEssence} ✦`,
      });
    }
    if (result.reflectedDamage && result.reflectedDamage > 0) {
      toast.error('Босс отразил урон', {
        description: `-${formatNumber(result.reflectedDamage)} ◆ возвращено`,
      });
    }
  }, [activeBoss, tapDamage, attackBoss]);

  const handleStartBoss = (boss: Boss) => {
    if (activeBoss) {
      toast.error('У тебя уже активен босс');
      return;
    }
    const result = startBoss(boss.id);
    if (result.success) {
      toast.success('Босс появился', { description: `${boss.emoji} ${boss.name}` });
    } else {
      toast.error(result.error || 'Нельзя начать битву');
    }
  };

  const handleCloseDefeat = useCallback(() => {
    setDefeatEffect(null);
  }, []);

  return (
    <div className="px-4 pt-5 pb-8 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-[17px] font-semibold text-frost-white tracking-tight flex items-center gap-2">
            <Swords className="w-4 h-4 text-red-400" strokeWidth={1.75} />
            Мировые боссы
          </h2>
          <p className="text-[11px] text-muted-fg mt-0.5">Побеждено: {bossesDefeated} · Урон: {formatNumber(tapDamage)}</p>
        </div>
      </div>

      {/* Active boss */}
      {activeBoss && (
        <ActiveBossCard
          bossId={activeBoss.bossId}
          currentHp={activeBoss.currentHp}
          maxHp={activeBoss.maxHp}
          endTime={activeBoss.endTime}
          now={now}
          onAttack={handleAttack}
          tapDamage={tapDamage}
          phase={activeBoss.phase || 1}
        />
      )}

      {/* Boss list */}
      <div className="space-y-2.5">
        <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em] px-1">Доступные боссы</p>
        {BOSSES.map((boss, idx) => {
          const isActive = activeBoss?.bossId === boss.id;
          const lastDefeat = lastBossDefeat[boss.id];
          const onCooldown = lastDefeat && Date.now() - lastDefeat < 6 * 3600 * 1000;
          const reqCheck = checkBossRequirements(boss, ownedCreatures);

          return (
            <motion.div
              key={boss.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.06 }}
              className={cn(
                'rounded-xl surface p-3.5',
                isActive && 'ring-active'
              )}
            >
              <div className="flex items-start gap-3">
                <div className="w-14 h-14 rounded-lg surface-sunken flex items-center justify-center text-3xl flex-shrink-0">
                  {boss.emoji}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="text-[13px] font-semibold text-frost-white">{boss.name}</h3>
                    <span className="text-[8px] uppercase tracking-wider text-red-300/70 font-semibold">Boss</span>
                    {boss.mechanic && (
                      <span className="text-[8px] uppercase tracking-wider text-amber-300/70 font-semibold">Механика</span>
                    )}
                  </div>
                  <p className="text-[10px] text-muted-fg mt-0.5 line-clamp-2">{boss.description}</p>

                  <div className="grid grid-cols-3 gap-1.5 mt-2">
                    <div className="surface-sunken rounded p-1.5 text-center">
                      <Heart className="w-2.5 h-2.5 text-red-400/80 mx-auto" strokeWidth={2} />
                      <p className="text-[10px] text-frost-white/80 font-medium tabular-nums mt-0.5">{formatNumber(boss.maxHp)}</p>
                    </div>
                    <div className="surface-sunken rounded p-1.5 text-center">
                      <Trophy className="w-2.5 h-2.5 text-gold/80 mx-auto" strokeWidth={2} />
                      <p className="text-[10px] text-gold/90 font-medium tabular-nums mt-0.5">{formatNumber(boss.reward)}</p>
                    </div>
                    <div className="surface-sunken rounded p-1.5 text-center">
                      <span className="text-[10px] text-aurora">✦</span>
                      <p className="text-[10px] text-aurora/90 font-medium tabular-nums mt-0.5">{boss.auroraEssence}</p>
                    </div>
                  </div>

                  {/* Boss mechanic */}
                  {boss.mechanic && (
                    <div className="mt-2 p-2 rounded-lg bg-amber-500/5 border border-amber-500/10">
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <AlertCircle className="w-3 h-3 text-amber-300" strokeWidth={2} />
                        <p className="text-[10px] font-semibold text-amber-300">{boss.mechanic.name}</p>
                      </div>
                      <p className="text-[9px] text-amber-200/60 leading-relaxed">{boss.mechanic.description}</p>
                    </div>
                  )}

                  {/* Required creatures */}
                  {boss.requiredCreatures && (
                    <div className="mt-2 p-2 rounded-lg surface-sunken">
                      <p className="text-[9px] text-muted-fg uppercase tracking-wider mb-1">Требования</p>
                      <div className="flex flex-wrap gap-1">
                        {boss.requiredCreatures.map((req, i) => {
                          const currentCount = Object.values(ownedCreatures).filter(
                            (c) => c.unlocked && CREATURES.find((cr) => cr.id === c.id)?.rarity === req.rarity
                          ).length;
                          const met = currentCount >= req.minCount;
                          return (
                            <span
                              key={i}
                              className={cn(
                                'text-[9px] px-1.5 py-0.5 rounded font-medium',
                                met
                                  ? 'bg-emerald-500/10 text-emerald-300'
                                  : 'bg-red-500/10 text-red-300'
                              )}
                            >
                              {req.minCount}+ {RARITY_META[req.rarity].label} ({currentCount})
                            </span>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <button
                onClick={() => handleStartBoss(boss)}
                disabled={isActive || !!activeBoss || !!onCooldown || !reqCheck.met}
                className={cn(
                  'w-full mt-3 py-2.5 rounded-lg font-semibold text-[12px] transition-all flex items-center justify-center gap-1.5',
                  isActive
                    ? 'surface-sunken text-red-300 cursor-default'
                    : activeBoss
                    ? 'surface-sunken text-muted-fg cursor-not-allowed'
                    : onCooldown
                    ? 'surface-sunken text-muted-fg'
                    : !reqCheck.met
                    ? 'surface-sunken text-amber-300/50'
                    : 'bg-red-500/15 text-red-300 hover:bg-red-500/25 active:scale-[0.98]'
                )}
              >
                {isActive ? (
                  <>Битва идёт</>
                ) : activeBoss ? (
                  <>Заверши текущий бой</>
                ) : onCooldown ? (
                  <>
                    <Clock className="w-3 h-3" strokeWidth={2} />
                    Отдыхает
                  </>
                ) : !reqCheck.met ? (
                  <>
                    <Lock className="w-3 h-3" strokeWidth={2} />
                    Требуются существа
                  </>
                ) : (
                  <>
                    <Skull className="w-3.5 h-3.5" strokeWidth={2} />
                    Начать битву · {boss.duration}ч
                  </>
                )}
              </button>
            </motion.div>
          );
        })}
      </div>

      {/* Boss Defeat Epic Effect */}
      <AnimatePresence>
        {defeatEffect && (
          <BossDefeatEffect
            boss={defeatEffect.boss}
            reward={defeatEffect.reward}
            auroraEssence={defeatEffect.auroraEssence}
            onClose={handleCloseDefeat}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// ===== EPIC BOSS DEATH EFFECT =====
function BossDefeatEffect({
  boss,
  reward,
  auroraEssence,
  onClose,
}: {
  boss: Boss;
  reward: number;
  auroraEssence: number;
  onClose: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.95)' }}
    >
      {/* Screen shake wrapper */}
      <motion.div
        animate={{
          x: [0, -8, 8, -6, 6, -3, 3, 0],
          y: [0, 4, -4, 3, -3, 2, -2, 0],
        }}
        transition={{ duration: 0.6, ease: 'easeOut' }}
        className="relative w-full max-w-xs"
      >
        {/* Explosion flash */}
        <motion.div
          initial={{ scale: 0, opacity: 1 }}
          animate={{ scale: 5, opacity: 0 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
        >
          <div className="w-32 h-32 rounded-full bg-red-500/40 blur-2xl" />
        </motion.div>

        {/* Second explosion ring */}
        <motion.div
          initial={{ scale: 0, opacity: 0.8 }}
          animate={{ scale: 3, opacity: 0 }}
          transition={{ duration: 1.0, ease: 'easeOut', delay: 0.1 }}
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
        >
          <div className="w-24 h-24 rounded-full bg-amber-500/30 blur-xl" />
        </motion.div>

        {/* Ice shatter particles */}
        {[...Array(16)].map((_, i) => {
          const angle = (i / 16) * Math.PI * 2;
          const distance = 80 + Math.random() * 100;
          const startX = Math.cos(angle) * 20;
          const startY = Math.sin(angle) * 20;
          const endX = Math.cos(angle) * distance;
          const endY = Math.sin(angle) * distance;
          const rotation = Math.random() * 720 - 360;
          const size = 6 + Math.random() * 12;
          const colors = ['bg-red-400', 'bg-amber-400', 'bg-sky-300', 'bg-purple-400', 'bg-cyan-300', 'bg-rose-400'];
          const emojis = ['❄', '✦', '💥', '⭐', '❄', '✧', '🔥', '💎', '❄', '✦', '⚡', '❄', '✧', '💥', '❄', '✦'];

          return (
            <motion.div
              key={i}
              initial={{ x: startX, y: startY, scale: 1, opacity: 1, rotate: 0 }}
              animate={{ x: endX, y: endY, scale: 0, opacity: 0, rotate: rotation }}
              transition={{ duration: 0.8 + Math.random() * 0.6, ease: 'easeOut', delay: 0.05 * Math.random() }}
              className="absolute top-1/2 left-1/2 pointer-events-none text-lg"
              style={{ fontSize: `${size}px` }}
            >
              {emojis[i % emojis.length]}
            </motion.div>
          );
        })}

        {/* Boss death — shrink + fade */}
        <motion.div
          initial={{ scale: 1.5, opacity: 1 }}
          animate={{ scale: 0, opacity: 0, rotate: 180 }}
          transition={{ duration: 0.8, ease: 'easeIn', delay: 0.2 }}
          className="flex justify-center mb-4"
        >
          <span className="text-7xl">{boss.emoji}</span>
        </motion.div>

        {/* Victory content */}
        <motion.div
          initial={{ opacity: 0, y: 30, scale: 0.8 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ delay: 1.0, type: 'spring', stiffness: 200, damping: 18 }}
          className="relative"
        >
          <div className="rounded-2xl glass-strong overflow-hidden rarity-glow-legendary">
            <div className="h-1.5 rarity-strip-legendary" />

            <div className="p-6 text-center">
              <button
                onClick={onClose}
                className="absolute top-3 right-3 w-7 h-7 rounded-md surface-sunken flex items-center justify-center text-muted-fg hover:text-frost-white z-10"
              >
                ✕
              </button>

              {/* Victory title */}
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.2 }}
              >
                <p className="text-[10px] text-red-300/70 uppercase tracking-[0.4em] mb-1">Босс повержен</p>
                <h3 className="text-[20px] font-bold text-frost-white mb-1">{boss.name}</h3>
                <p className="text-[11px] text-amber-300/70 mb-4">Победа!</p>
              </motion.div>

              {/* Rewards */}
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.5 }}
                className="grid grid-cols-2 gap-2 mb-4"
              >
                <div className="surface-sunken rounded-xl p-3">
                  <span className="text-2xl block mb-1">💎</span>
                  <p className="text-[14px] font-bold text-frost-white tabular-nums">{formatNumber(reward)}</p>
                  <p className="text-[9px] text-muted-fg">Кристаллы</p>
                </div>
                <div className="surface-sunken rounded-xl p-3">
                  <span className="text-2xl block mb-1">✦</span>
                  <p className="text-[14px] font-bold text-aurora tabular-nums">{auroraEssence}</p>
                  <p className="text-[9px] text-muted-fg">Эссенция</p>
                </div>
              </motion.div>

              {/* Sparkle celebration */}
              {[...Array(10)].map((_, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0, y: 0 }}
                  animate={{ opacity: [0, 1, 0], scale: [0, 1.2, 0], y: -30 - Math.random() * 40 }}
                  transition={{ duration: 1.2, delay: 1.3 + i * 0.08, ease: 'easeOut' }}
                  className="absolute pointer-events-none"
                  style={{
                    left: `${10 + (i * 9) % 80}%`,
                    top: `${30 + (i * 7) % 40}%`,
                    fontSize: '14px',
                  }}
                >
                  {['✦', '✧', '❄', '⭐', '💎', '✨', '🌟', '💫', '❄', '✦'][i]}
                </motion.div>
              ))}

              <motion.button
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.8 }}
                onClick={onClose}
                className="w-full py-3 rounded-lg font-semibold text-[13px] bg-gold text-ice-deep active:scale-[0.98]"
              >
                Забрать награду
              </motion.button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </motion.div>
  );
}

function ActiveBossCard({
  bossId,
  currentHp,
  maxHp,
  endTime,
  now,
  onAttack,
  tapDamage,
  phase,
}: {
  bossId: string;
  currentHp: number;
  maxHp: number;
  endTime: number;
  now: number;
  onAttack: () => void;
  tapDamage: number;
  phase: number;
}) {
  const boss = BOSSES.find((b) => b.id === bossId)!;
  const hpPercent = (currentHp / maxHp) * 100;
  const timeLeft = Math.max(0, endTime - now);
  const isImmune = boss.mechanic?.immuneInterval
    ? (() => {
        const elapsed = (now - (endTime - boss.duration * 3600 * 1000)) / 1000;
        const cyclePosition = elapsed % boss.mechanic.immuneInterval;
        return cyclePosition > boss.mechanic.immuneInterval - 3;
      })()
    : false;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className={cn(
        'rounded-2xl surface-elevated p-5 ring-active',
        phase >= 2 && 'boss-phase-shift'
      )}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-1.5">
          <span className={cn('w-1.5 h-1.5 rounded-full', isImmune ? 'bg-amber-400 boss-immune-pulse' : 'bg-red-400 animate-pulse-soft')} />
          <p className={cn(
            'text-[10px] uppercase tracking-[0.2em] font-semibold',
            isImmune ? 'text-amber-300' : 'text-red-300'
          )}>
            {isImmune ? 'Иммунитет' : 'Битва'}
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          {phase >= 2 && (
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 font-semibold">
              Фаза {phase}
            </span>
          )}
          <div className="flex items-center gap-1 text-[11px] text-red-300/80 tabular-nums">
            <Clock className="w-3 h-3" strokeWidth={2} />
            {formatTimeShort(timeLeft)}
          </div>
        </div>
      </div>

      {/* Boss mechanic info */}
      {boss.mechanic && (
        <div className="mb-3 p-2 rounded-lg bg-amber-500/5 border border-amber-500/10">
          <p className="text-[9px] text-amber-300/70">
            <AlertCircle className="w-2.5 h-2.5 inline mr-1" strokeWidth={2} />
            {boss.mechanic.name}: {boss.mechanic.description}
          </p>
        </div>
      )}

      <div className="flex flex-col items-center text-center mb-4">
        <motion.div
          animate={{ y: [0, -4, 0] }}
          transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
          className={cn('text-6xl mb-1', phase >= 2 && 'hue-rotate-30')}
        >
          {boss.emoji}
        </motion.div>
        <h3 className="text-[15px] font-semibold text-frost-white">{boss.name}</h3>
      </div>

      <div className="space-y-1.5 mb-4">
        <div className="flex items-center justify-between text-[11px]">
          <span className="text-red-300/80 flex items-center gap-1">
            <Heart className="w-3 h-3" strokeWidth={2} />
            HP
          </span>
          <span className="font-semibold text-frost-white tabular-nums">
            {formatNumber(currentHp)} / {formatNumber(maxHp)}
          </span>
        </div>
        <div className="h-2 surface-sunken rounded-full overflow-hidden">
          <motion.div
            className={cn(
              'h-full rounded-full',
              phase >= 2
                ? 'bg-gradient-to-r from-amber-500/80 to-red-500/80'
                : 'bg-gradient-to-r from-red-500/80 to-red-400/80'
            )}
            animate={{ width: `${hpPercent}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>
      </div>

      <motion.button
        onClick={onAttack}
        whileTap={{ scale: 0.97 }}
        disabled={isImmune}
        className={cn(
          'w-full py-3.5 rounded-lg font-semibold text-[14px] transition-colors flex items-center justify-center gap-2',
          isImmune
            ? 'bg-amber-500/10 text-amber-300/50 cursor-not-allowed'
            : 'bg-red-500/20 text-red-200 hover:bg-red-500/30'
        )}
      >
        <Zap className="w-4 h-4" strokeWidth={2} />
        {isImmune ? 'Иммунитет...' : `Атака · ${formatNumber(tapDamage)} урона`}
      </motion.button>

      <p className="text-[10px] text-muted-fg text-center mt-2">
        Тапай быстро — каждый удар наносит урон
        {boss.mechanic?.reflectDamage && ` · Босс отражает ${boss.mechanic.reflectDamage}% урона`}
      </p>
    </motion.div>
  );
}
