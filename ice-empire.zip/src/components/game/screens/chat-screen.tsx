'use client';

import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore, type ChatMessage } from '@/lib/game-store';
import { PROFILE_FRAMES, PROFILE_SKINS, RARITY_META, getProfileFrameById, getProfileSkinById } from '@/lib/game-data';
import { cn } from '@/lib/utils';
import { ChatAvatar } from '../profile-avatar';
import { Send, MessageCircle, Crown, Sparkles, Flame } from 'lucide-react';

// ===== Simulated bot messages for demo =====
const BOT_MESSAGES: Omit<ChatMessage, 'id' | 'timestamp'>[] = [
  { playerId: 'bot_1', playerName: 'Ледяной Страж', playerLevel: 42, frameId: 'pf7', skinId: 'ps8', avatarUrl: null, text: 'Кто хочет в клан? У нас бонусы x3!' },
  { playerId: 'bot_2', playerName: 'Морозная Ведьма', playerLevel: 78, frameId: 'pf11', skinId: 'ps5', avatarUrl: null, text: 'Только что выбила дракона из сундука 🔥' },
  { playerId: 'bot_3', playerName: 'Снежный Бард', playerLevel: 15, frameId: null, skinId: 'ps1', avatarUrl: null, text: 'Как быстро фармить кристаллы?' },
  { playerId: 'bot_4', playerName: 'Йети_2024', playerLevel: 99, frameId: 'pf17', skinId: 'ps10', avatarUrl: null, text: '10-й престиж! Ура!' },
  { playerId: 'bot_5', playerName: 'Пингвин-шахтёр', playerLevel: 5, frameId: null, skinId: 'ps2', avatarUrl: null, text: 'Всем привет! Новичок тут 🐧' },
  { playerId: 'bot_6', playerName: 'Королева Льда', playerLevel: 120, frameId: 'pf14', skinId: 'ps9', avatarUrl: null, text: 'Босс через 5 минут, готовьтесь!' },
  { playerId: 'bot_7', playerName: 'Ледяной Феникс', playerLevel: 55, frameId: 'pf10', skinId: 'ps7', avatarUrl: null, text: 'Донатные сундуки реально топ, 10 предметов!' },
  { playerId: 'bot_8', playerName: 'Аврорный Лучник', playerLevel: 33, frameId: 'pf4', skinId: 'ps4', avatarUrl: null, text: 'Кто-нибудь знает, когда сброс цен на сундуки?' },
];

export function ChatScreen() {
  const chatMessages = useGameStore((s) => s.chatMessages);
  const sendChatMessage = useGameStore((s) => s.sendChatMessage);
  const loadChatMessages = useGameStore((s) => s.loadChatMessages);
  const playerName = useGameStore((s) => s.playerName);
  const playerLevel = useGameStore((s) => s.playerLevel);
  const selectedFrame = useGameStore((s) => s.selectedFrame);
  const selectedSkin = useGameStore((s) => s.selectedSkin);
  const telegramAvatarUrl = useGameStore((s) => s.telegramAvatarUrl);
  const telegramUserId = useGameStore((s) => s.telegramUserId);
  const prestigeLevel = useGameStore((s) => s.prestigeLevel);
  const bossesDefeated = useGameStore((s) => s.bossesDefeated);

  const [input, setInput] = useState('');
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Load chat messages on mount
  useEffect(() => {
    loadChatMessages();

    // Add some simulated bot messages if chat is empty
    const saved = localStorage.getItem('ice-empire-chat');
    if (!saved || JSON.parse(saved).length === 0) {
      const now = Date.now();
      const simulated: ChatMessage[] = BOT_MESSAGES.map((msg, i) => ({
        ...msg,
        id: `bot_msg_${i}`,
        timestamp: now - (BOT_MESSAGES.length - i) * 30000, // 30s apart
      }));
      try {
        localStorage.setItem('ice-empire-chat', JSON.stringify(simulated));
      } catch {}
      simulated.forEach((msg) => sendChatMessage('')); // trigger reload
      // Actually, let's just set them directly
      loadChatMessages();
    }
  }, []);

  // Add periodic bot messages for liveliness
  useEffect(() => {
    const interval = setInterval(() => {
      const randomBot = BOT_MESSAGES[Math.floor(Math.random() * BOT_MESSAGES.length)];
      const msg: ChatMessage = {
        ...randomBot,
        id: 'bot_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
        timestamp: Date.now(),
      };
      try {
        const saved = localStorage.getItem('ice-empire-chat');
        const existing: ChatMessage[] = saved ? JSON.parse(saved) : [];
        const updated = [...existing, msg].slice(-100);
        localStorage.setItem('ice-empire-chat', JSON.stringify(updated));
        loadChatMessages();
      } catch {}
    }, 15000 + Math.random() * 20000); // every 15-35s

    return () => clearInterval(interval);
  }, []);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleSend = () => {
    if (!input.trim() || isSending) return;
    setIsSending(true);
    sendChatMessage(input);
    setInput('');
    setTimeout(() => setIsSending(false), 300);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="flex flex-col h-[calc(100vh-120px)]">
      {/* Header */}
      <div className="px-4 pt-4 pb-2">
        <div className="flex items-center gap-2">
          <MessageCircle className="w-4 h-4 text-ice" strokeWidth={1.75} />
          <h2 className="text-[17px] font-semibold text-frost-white tracking-tight">Глобальный чат</h2>
        </div>
        <p className="text-[11px] text-muted-fg mt-0.5">Общайся с игроками Ice Empire</p>
      </div>

      {/* My profile quick card */}
      <div className="mx-4 mb-2 surface rounded-xl p-2.5 flex items-center gap-2.5">
        <ChatAvatar
          avatarUrl={telegramAvatarUrl}
          skinId={selectedSkin}
          frameId={selectedFrame}
          size="sm"
        />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="text-[12px] font-semibold text-frost-white truncate">{playerName}</span>
            <span className="text-[9px] text-ice font-semibold">L{playerLevel}</span>
            {prestigeLevel > 0 && (
              <Crown className="w-2.5 h-2.5 text-gold" strokeWidth={2} />
            )}
          </div>
          <div className="flex items-center gap-2 text-[9px] text-muted-fg">
            <span>{bossesDefeated} боссов</span>
            <span>·</span>
            <span>{selectedFrame ? getProfileFrameById(selectedFrame)?.name : 'Без рамки'}</span>
          </div>
        </div>
      </div>

      {/* Messages area */}
      <div className="flex-1 overflow-y-auto scrollbar-thin px-4 space-y-1">
        <AnimatePresence initial={false}>
          {chatMessages.map((msg) => (
            <ChatMessageBubble key={msg.id} message={msg} isOwn={msg.playerId === (telegramUserId || 'local_player')} />
          ))}
        </AnimatePresence>
        <div ref={messagesEndRef} />
      </div>

      {/* Input area */}
      <div className="p-3 glass">
        <div className="flex items-center gap-2">
          <input
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Написать сообщение..."
            maxLength={200}
            className="flex-1 px-3 py-2.5 rounded-xl surface-sunken text-[13px] text-frost-white placeholder:text-muted-fg/60 outline-none focus:ring-active transition-all"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isSending}
            className={cn(
              'w-10 h-10 rounded-xl flex items-center justify-center transition-all active:scale-[0.95]',
              input.trim()
                ? 'bg-ice text-ice-deep'
                : 'surface-sunken text-muted-fg'
            )}
          >
            <Send className="w-4 h-4" strokeWidth={2} />
          </button>
        </div>
      </div>
    </div>
  );
}

function ChatMessageBubble({ message, isOwn }: { message: ChatMessage; isOwn: boolean }) {
  const frame = message.frameId ? getProfileFrameById(message.frameId) : null;
  const skin = getProfileSkinById(message.skinId);
  const rarityColor = frame ? RARITY_META[frame.rarity].color : '';

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 8, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.2 }}
      className={cn(
        'flex gap-2 py-1.5',
        isOwn && 'flex-row-reverse',
      )}
    >
      {/* Avatar */}
      <ChatAvatar
        avatarUrl={message.avatarUrl}
        skinId={message.skinId}
        frameId={message.frameId}
        size="sm"
      />

      {/* Content */}
      <div className={cn('flex flex-col max-w-[75%]', isOwn && 'items-end')}>
        {/* Name + level */}
        <div className={cn('flex items-center gap-1.5 mb-0.5', isOwn && 'flex-row-reverse')}>
          <span className={cn('text-[11px] font-semibold', rarityColor || 'text-frost-white/80')}>
            {message.playerName}
          </span>
          <span className="text-[8px] text-muted-fg font-medium">L{message.playerLevel}</span>
          {frame && (
            <span className={cn('text-[7px] uppercase tracking-wider', rarityColor)}>
              {frame.emoji}
            </span>
          )}
        </div>

        {/* Bubble */}
        <div
          className={cn(
            'rounded-2xl px-3 py-2 text-[13px] leading-relaxed break-words',
            isOwn
              ? 'bg-ice/15 text-frost-white rounded-tr-sm'
              : 'surface text-frost-white/90 rounded-tl-sm',
            frame?.rarity === 'legendary' && 'border border-amber-500/20',
            frame?.rarity === 'mythic' && 'border border-pink-500/20',
            frame?.rarity === 'ancient' && 'border border-cyan-400/30',
          )}
        >
          {message.text}
        </div>

        {/* Timestamp */}
        <span className="text-[8px] text-muted-fg/60 mt-0.5 px-1">
          {formatTime(message.timestamp)}
        </span>
      </div>
    </motion.div>
  );
}
