'use client';

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore } from '@/lib/game-store';
import {
  CREATURES,
  RARITY_META,
  type Creature,
  type Rarity,
  getCreatureIncome,
  getUpgradeCost,
} from '@/lib/game-data';
import { formatNumber } from '@/lib/format';
import { Lock, ChevronUp, Star, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const RARITY_FILTERS: (Rarity | 'all' | 'owned')[] = ['all', 'owned', 'common', 'uncommon', 'rare', 'epic', 'legendary', 'mythic', 'ancient'];

const RARITY_LABELS: Record<string, string> = {
  all: 'Все',
  owned: 'Мои',
  common: 'Common',
  uncommon: 'Uncommon',
  rare: 'Rare',
  epic: 'Epic',
  legendary: 'Legendary',
  mythic: 'Mythic',
  ancient: 'Ancient',
};

export function CreaturesScreen() {
  const ownedCreatures = useGameStore((s) => s.ownedCreatures);
  const crystals = useGameStore((s) => s.crystals);
  const buyCreature = useGameStore((s) => s.buyCreature);
  const upgradeCreature = useGameStore((s) => s.upgradeCreature);
  const [filter, setFilter] = useState<Rarity | 'all' | 'owned'>('all');
  const [selected, setSelected] = useState<Creature | null>(null);

  const filteredCreatures = useMemo(() => {
    let list = CREATURES;
    if (filter === 'owned') {
      list = list.filter((c) => ownedCreatures[c.id]?.unlocked);
    } else if (filter !== 'all') {
      list = list.filter((c) => c.rarity === filter);
    }
    return list;
  }, [filter, ownedCreatures]);

  const ownedCount = Object.values(ownedCreatures).filter((c) => c.unlocked).length;

  const handleBuy = (creature: Creature) => {
    if (buyCreature(creature.id)) {
      toast.success('Существо получено', { description: `${creature.emoji} ${creature.name}` });
    } else {
      toast.error('Недостаточно кристаллов');
    }
  };

  const handleUpgrade = (creature: Creature) => {
    if (upgradeCreature(creature.id)) {
      const owned = useGameStore.getState().ownedCreatures[creature.id];
      toast.success(`${creature.name} → L${owned.level}`, {
        description: `Доход: ${formatNumber(getCreatureIncome(creature, owned.level))}/с`,
      });
    } else {
      toast.error('Недостаточно кристаллов');
    }
  };

  return (
    <div className="px-4 pt-5 pb-8 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-[17px] font-semibold text-frost-white tracking-tight">Коллекция</h2>
          <p className="text-[11px] text-muted-fg mt-0.5">{ownedCount} из {CREATURES.length} открыто</p>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md surface-sunken">
          <span className="text-[11px] text-ice">◆</span>
          <span className="text-[12px] font-semibold text-ice tabular-nums">{formatNumber(crystals)}</span>
        </div>
      </div>

      {/* Progress */}
      <div className="h-1 surface-sunken rounded-full overflow-hidden">
        <motion.div
          className="h-full bg-ice/60 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${(ownedCount / CREATURES.length) * 100}%` }}
          transition={{ duration: 0.5 }}
        />
      </div>

      {/* Filters */}
      <div className="flex items-center gap-1 overflow-x-auto scrollbar-thin -mx-4 px-4">
        {RARITY_FILTERS.map((r) => (
          <button
            key={r}
            onClick={() => setFilter(r)}
            className={cn(
              'flex-shrink-0 px-3 py-1.5 rounded-md text-[11px] font-medium tracking-tight transition-all',
              filter === r
                ? 'surface-elevated text-ice ring-active'
                : 'text-muted-fg hover:text-frost-white/80'
            )}
          >
            {RARITY_LABELS[r]}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-4 gap-1.5">
        {filteredCreatures.map((creature, idx) => {
          const owned = ownedCreatures[creature.id];
          const isOwned = owned?.unlocked;
          const rarityMeta = RARITY_META[creature.rarity];

          return (
            <motion.button
              key={creature.id}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: Math.min(idx * 0.01, 0.15) }}
              onClick={() => setSelected(creature)}
              className={cn(
                'relative aspect-[3/4] rounded-lg overflow-hidden flex flex-col items-center justify-between p-1.5 transition-all',
                isOwned ? 'surface' : 'surface-sunken',
                'hover:border-ice/30 active:scale-[0.97]'
              )}
            >
              {/* Rarity strip */}
              <div className={cn('absolute top-0 left-0 right-0 h-[2px]', `rarity-strip-${creature.rarity}`)} />

              {/* Level badge */}
              {isOwned && (
                <div className="self-end text-[8px] font-semibold text-ice tabular-nums">
                  L{owned.level}
                </div>
              )}

              {/* Emoji */}
              <div className={cn('flex-1 flex items-center justify-center', !isOwned && 'opacity-30')}>
                {isOwned ? (
                  <span className="text-[22px] leading-none">{creature.emoji}</span>
                ) : (
                  <Lock className="w-3 h-3 text-muted-fg" strokeWidth={1.5} />
                )}
              </div>

              {/* Name */}
              <div className="w-full text-center">
                <p className={cn(
                  'text-[8px] font-medium leading-tight line-clamp-1',
                  isOwned ? 'text-frost-white/90' : 'text-muted-fg'
                )}>
                  {isOwned ? creature.name : '???'}
                </p>
                <span className={cn('text-[7px] uppercase tracking-wider mt-0.5 block', rarityMeta.color)}>
                  {rarityMeta.label}
                </span>
              </div>
            </motion.button>
          );
        })}
      </div>

      <AnimatePresence>
        {selected && (
          <CreatureDetailModal
            creature={selected}
            owned={ownedCreatures[selected.id]}
            onClose={() => setSelected(null)}
            onBuy={() => handleBuy(selected)}
            onUpgrade={() => handleUpgrade(selected)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function CreatureDetailModal({
  creature,
  owned,
  onClose,
  onBuy,
  onUpgrade,
}: {
  creature: Creature;
  owned?: { id: string; level: number; unlocked: boolean };
  onClose: () => void;
  onBuy: () => void;
  onUpgrade: () => void;
}) {
  const crystals = useGameStore((s) => s.crystals);
  const rarityMeta = RARITY_META[creature.rarity];
  const isOwned = owned?.unlocked;
  const upgradeCost = owned ? getUpgradeCost(creature, owned.level) : creature.baseCost;
  const income = isOwned ? getCreatureIncome(creature, owned.level) : creature.baseIncome;
  const nextLevelIncome = isOwned ? getCreatureIncome(creature, owned.level + 1) : creature.baseIncome;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
    >
      <motion.div
        initial={{ y: 30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 30, opacity: 0 }}
        transition={{ type: 'tween', duration: 0.2 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm rounded-2xl glass-strong overflow-hidden"
      >
        <div className={cn('h-[3px]', `rarity-strip-${creature.rarity}`)} />

        <div className="p-5">
          <button
            onClick={onClose}
            className="absolute top-3 right-3 w-7 h-7 rounded-md surface-sunken flex items-center justify-center text-muted-fg hover:text-frost-white"
          >
            <X className="w-3.5 h-3.5" strokeWidth={2} />
          </button>

          <div className="flex flex-col items-center text-center pt-2 pb-4">
            <div className={cn(
              'relative w-20 h-20 rounded-xl surface-sunken flex items-center justify-center text-5xl mb-3',
              !isOwned && 'opacity-40'
            )}>
              {isOwned ? creature.emoji : <Lock className="w-6 h-6 text-muted-fg" strokeWidth={1.5} />}
            </div>
            <h3 className="text-[15px] font-semibold text-frost-white">
              {isOwned ? creature.name : 'Неизвестное существо'}
            </h3>
            <span className={cn('text-[10px] uppercase tracking-[0.2em] mt-1', rarityMeta.color)}>
              {rarityMeta.label}
            </span>
          </div>

          <p className="text-[12px] text-muted-fg text-center mb-4 leading-relaxed">
            {isOwned ? creature.description : 'Открой это существо, чтобы узнать о нём больше.'}
          </p>

          {isOwned && (
            <div className="surface-sunken rounded-lg p-3 mb-3">
              <div className="flex items-center gap-1.5 mb-1">
                <Star className="w-3 h-3 text-gold" strokeWidth={2} />
                <p className="text-[12px] font-semibold text-gold">{creature.skill}</p>
              </div>
              <p className="text-[11px] text-muted-fg">{creature.skillDescription}</p>
            </div>
          )}

          {isOwned && (
            <div className="grid grid-cols-2 gap-2 mb-2">
              <div className="surface-sunken rounded-lg p-2.5 text-center">
                <p className="text-[9px] text-muted-fg uppercase tracking-wider">Уровень</p>
                <p className="text-[16px] font-semibold text-frost-white tabular-nums mt-0.5">{owned.level}</p>
              </div>
              <div className="surface-sunken rounded-lg p-2.5 text-center">
                <p className="text-[9px] text-muted-fg uppercase tracking-wider">Доход</p>
                <p className="text-[16px] font-semibold text-ice tabular-nums mt-0.5">{formatNumber(income)}/с</p>
              </div>
            </div>
          )}

          {isOwned && (
            <div className="surface-sunken rounded-lg p-2 mb-4">
              <div className="flex items-center justify-between text-[10px]">
                <span className="text-muted-fg">Следующий уровень:</span>
                <span className="text-ice tabular-nums">{formatNumber(nextLevelIncome)}/с</span>
              </div>
              <div className="flex items-center justify-between text-[10px] mt-1">
                <span className="text-muted-fg">Стоимость улучшения:</span>
                <span className="text-frost-white tabular-nums">{formatNumber(upgradeCost)} ◆</span>
              </div>
            </div>
          )}

          {!isOwned ? (
            <button
              onClick={onBuy}
              disabled={crystals < creature.baseCost}
              className={cn(
                'w-full py-3 rounded-lg font-semibold text-[13px] transition-all',
                crystals >= creature.baseCost
                  ? 'bg-ice text-ice-deep hover:opacity-90 active:scale-[0.98]'
                  : 'surface-sunken text-muted-fg'
              )}
            >
              Открыть · {formatNumber(creature.baseCost)} ◆
            </button>
          ) : (
            <button
              onClick={onUpgrade}
              disabled={crystals < upgradeCost}
              className={cn(
                'w-full py-3 rounded-lg font-semibold text-[13px] transition-all flex items-center justify-center gap-1.5',
                crystals >= upgradeCost
                  ? 'bg-ice text-ice-deep hover:opacity-90 active:scale-[0.98]'
                  : 'surface-sunken text-muted-fg'
              )}
            >
              <ChevronUp className="w-3.5 h-3.5" strokeWidth={2} />
              Улучшить до L{owned.level + 1} · {formatNumber(upgradeCost)} ◆
            </button>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
