'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore } from '@/lib/game-store';
import {
  CHESTS,
  ARTIFACTS,
  ARTIFACT_SETS,
  DONATE_PACKS,
  CLAN_LEVELS,
  RARITY_META,
  getClanLevel,
  getNextClanLevel,
  type Chest,
  type Rarity,
  type ProfileFrame,
} from '@/lib/game-data';
import { formatNumber, formatTime } from '@/lib/format';
import { Gift, Sparkles, X, Crown, Star, Shield, Swords, TrendingUp, Users, ChevronRight, Gem, Zap, Trophy, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

type Tab = 'chests' | 'artifacts' | 'clan' | 'donate';

export function ShopScreen() {
  const [tab, setTab] = useState<Tab>('chests');

  return (
    <div className="px-4 pt-5 pb-8 space-y-4">
      <div>
        <h2 className="text-[17px] font-semibold text-frost-white tracking-tight">Магазин</h2>
        <p className="text-[11px] text-muted-fg mt-0.5">Сундуки, кристаллы, артефакты и кланы</p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-0.5 p-0.5 rounded-lg surface-sunken overflow-x-auto scrollbar-thin">
        <TabButton active={tab === 'chests'} onClick={() => setTab('chests')} icon={<Gift className="w-3.5 h-3.5" strokeWidth={1.75} />} label="Сундуки" />
        <TabButton active={tab === 'donate'} onClick={() => setTab('donate')} icon={<Gem className="w-3.5 h-3.5" strokeWidth={1.75} />} label="Кристаллы" />
        <TabButton active={tab === 'artifacts'} onClick={() => setTab('artifacts')} icon={<Sparkles className="w-3.5 h-3.5" strokeWidth={1.75} />} label="Артефакты" />
        <TabButton active={tab === 'clan'} onClick={() => setTab('clan')} icon={<Shield className="w-3.5 h-3.5" strokeWidth={1.75} />} label="Клан" />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -6 }}
          transition={{ duration: 0.15 }}
        >
          {tab === 'chests' && <ChestsTab />}
          {tab === 'donate' && <DonateTab />}
          {tab === 'artifacts' && <ArtifactsTab />}
          {tab === 'clan' && <ClanTab />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

function TabButton({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'flex-1 flex items-center justify-center gap-1 py-2 rounded-md text-[11px] font-medium tracking-tight transition-all whitespace-nowrap',
        active ? 'surface-elevated text-ice' : 'text-muted-fg hover:text-frost-white/80'
      )}
    >
      {icon}
      {label}
    </button>
  );
}

// ===== CHESTS TAB =====
interface ChestItem {
  type: 'creature' | 'frame';
  rarity: Rarity;
  creatureEmoji: string;
  creatureName: string;
  frame?: ProfileFrame;
  isDuplicate: boolean;
  shardReward?: number;
}

function ChestsTab() {
  const openChest = useGameStore((s) => s.openChest);
  const getCurrentChestCost = useGameStore((s) => s.getCurrentChestCost);
  const crystals = useGameStore((s) => s.crystals);
  const telegramStars = useGameStore((s) => s.telegramStars);
  const totalChestsOpened = useGameStore((s) => s.totalChestsOpened);
  const chestPurchases = useGameStore((s) => s.chestPurchases);
  const getNextChestResetTime = useGameStore((s) => s.getNextChestResetTime);
  const [opening, setOpening] = useState<{
    chest: Chest;
    items: ChestItem[];
    currentCost: number;
  } | null>(null);
  const [animationPhase, setAnimationPhase] = useState<'idle' | 'shaking' | 'bursting' | 'revealing' | 'done'>('idle');

  const nextReset = getNextChestResetTime();
  const resetCountdown = nextReset > Date.now() ? formatTime(nextReset - Date.now()) : null;

  const [countdown, setCountdown] = useState<string | null>(resetCountdown);
  useEffect(() => {
    if (nextReset <= Date.now()) { setCountdown(null); return; }
    const interval = setInterval(() => {
      const remaining = nextReset - Date.now();
      if (remaining <= 0) { setCountdown(null); clearInterval(interval); return; }
      setCountdown(formatTime(remaining));
    }, 1000);
    return () => clearInterval(interval);
  }, [nextReset]);

  const handleOpen = (chest: Chest) => {
    const currentCost = getCurrentChestCost(chest.id);
    const canAfford = chest.currency === 'crystals' ? crystals >= currentCost : telegramStars >= currentCost;
    if (!canAfford) {
      toast.error('Недостаточно валюты');
      return;
    }

    const result = openChest(chest.id);
    if (!result.success) {
      toast.error(result.error || 'Не удалось открыть');
      return;
    }

    const items: ChestItem[] = result.items.map((item) => ({
      type: item.type,
      rarity: item.rarity,
      creatureEmoji: item.type === 'frame' ? (item.frame?.emoji || '🖼️') : (item.creature?.emoji || '❓'),
      creatureName: item.type === 'frame' ? (item.frame?.name || 'Рамка') : (item.creature?.name || '???'),
      frame: item.frame,
      isDuplicate: item.isDuplicate,
      shardReward: item.shardReward,
    }));

    // Sort items by rarity — best last (for dramatic reveal)
    const rarityOrder: Record<Rarity, number> = { common: 1, uncommon: 2, rare: 3, epic: 4, legendary: 5, mythic: 6, ancient: 7 };
    items.sort((a, b) => rarityOrder[a.rarity] - rarityOrder[b.rarity]);

    setOpening({ chest, items, currentCost });

    setAnimationPhase('shaking');
    setTimeout(() => setAnimationPhase('bursting'), 350);
    setTimeout(() => setAnimationPhase('revealing'), 600);
    setTimeout(() => setAnimationPhase('done'), 1000 + items.length * 80);
  };

  const handleClose = useCallback(() => {
    setOpening(null);
    setAnimationPhase('idle');
  }, []);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between text-[11px]">
        <span className="text-muted-fg">Открыто: <span className="text-frost-white font-semibold">{totalChestsOpened}</span></span>
        <div className="flex items-center gap-1.5">
          {countdown && (
            <span className="flex items-center gap-1 px-2 py-0.5 rounded surface-sunken text-[9px] text-muted-fg">
              Сброс цен через {countdown}
            </span>
          )}
          <span className="flex items-center gap-1 px-2 py-0.5 rounded surface-sunken">
            <span className="text-ice">◆</span>
            <span className="text-ice font-semibold tabular-nums">{formatNumber(crystals)}</span>
          </span>
          <span className="flex items-center gap-1 px-2 py-0.5 rounded surface-sunken">
            <span className="text-gold">★</span>
            <span className="text-gold font-semibold tabular-nums">{telegramStars}</span>
          </span>
        </div>
      </div>

      <div className="space-y-2">
        {CHESTS.map((chest, idx) => {
          const currentCost = getCurrentChestCost(chest.id);
          const canAfford = chest.currency === 'crystals' ? crystals >= currentCost : telegramStars >= currentCost;
          const isStarChest = chest.currency === 'stars';
          const purchaseCount = chestPurchases[chest.id]?.count || 0;
          const priceIncreased = currentCost > chest.baseCost;

          return (
            <motion.div
              key={chest.id}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.06 }}
              className={cn('surface rounded-xl p-3', chest.isDonate && 'ring-1 ring-gold/30')}
            >
              <div className="flex items-center gap-3">
                <motion.div
                  animate={{ rotate: [0, -2, 2, 0] }}
                  transition={{ duration: 4, repeat: Infinity, delay: idx * 0.3, ease: 'easeInOut' }}
                  className="w-14 h-14 rounded-lg surface-sunken flex items-center justify-center text-2xl flex-shrink-0"
                >
                  {chest.emoji}
                </motion.div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5">
                    <h3 className="text-[13px] font-semibold text-frost-white">{chest.name}</h3>
                    {chest.isDonate && (
                      <span className="text-[8px] px-1 py-0.5 rounded bg-gold/15 text-gold font-semibold">
                        ДОНАТ
                      </span>
                    )}
                    <span className="text-[8px] px-1 py-0.5 rounded bg-ice/15 text-ice font-medium">
                      x{chest.itemCount}
                    </span>
                    {purchaseCount > 0 && (
                      <span className="text-[8px] px-1 py-0.5 rounded bg-amber-500/15 text-amber-300 font-medium">
                        куплено x{purchaseCount}
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-muted-fg line-clamp-1 mt-0.5">{chest.description}</p>

                  <div className="flex flex-wrap gap-0.5 mt-1.5">
                    {(['rare', 'epic', 'legendary', 'mythic', 'ancient'] as Rarity[]).map((r) => {
                      const chance = chest.rarityDrops[r];
                      if (chance <= 0) return null;
                      return (
                        <span
                          key={r}
                          className={cn('text-[8px] px-1 py-0.5 rounded font-medium', RARITY_META[r].color, 'bg-white/[0.03]')}
                        >
                          {RARITY_META[r].label} {chance}%
                        </span>
                      );
                    })}
                  </div>
                </div>
              </div>

              <button
                onClick={() => handleOpen(chest)}
                disabled={!canAfford}
                className={cn(
                  'w-full mt-2.5 py-2.5 rounded-lg font-semibold text-[12px] transition-all flex items-center justify-center gap-1.5',
                  canAfford
                    ? isStarChest
                      ? 'bg-gold text-ice-deep hover:opacity-90 active:scale-[0.98]'
                      : 'bg-ice text-ice-deep hover:opacity-90 active:scale-[0.98]'
                    : 'surface-sunken text-muted-fg'
                )}
              >
                <Gift className="w-3.5 h-3.5" strokeWidth={2} />
                Открыть · {formatNumber(currentCost)} {chest.currency === 'crystals' ? '◆' : '★'}
                {priceIncreased && (
                  <span className="text-[8px] text-amber-300/70 ml-1">(цена растёт)</span>
                )}
              </button>
            </motion.div>
          );
        })}
      </div>

      <div className="surface rounded-lg p-2.5">
        <p className="text-[9px] text-muted-fg leading-relaxed">
          Цена каждого сундука растёт после покупки. Сброс до базовых значений — каждые 3 дня. Донатные сундуки дают 10 предметов с усиленными шансами!
        </p>
      </div>

      <AnimatePresence>
        {opening && (
          <ChestOpeningAnimation
            chest={opening.chest}
            items={opening.items}
            currentCost={opening.currentCost}
            phase={animationPhase}
            onClose={handleClose}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// ===== CLASH ROYALE-STYLE CHEST OPENING ANIMATION =====
function ChestOpeningAnimation({
  chest,
  items,
  currentCost,
  phase,
  onClose,
}: {
  chest: Chest;
  items: ChestItem[];
  currentCost: number;
  phase: 'idle' | 'shaking' | 'bursting' | 'revealing' | 'done';
  onClose: () => void;
}) {
  // Find the best rarity among all items for the overall glow effect
  const rarityOrder: Record<Rarity, number> = { common: 1, uncommon: 2, rare: 3, epic: 4, legendary: 5, mythic: 6, ancient: 7 };
  const bestRarity = items.reduce((best, item) => rarityOrder[item.rarity] > rarityOrder[best] ? item.rarity : best, 'common' as Rarity);
  const bestRarityMeta = RARITY_META[bestRarity];
  const isHighRarity = ['legendary', 'mythic', 'ancient'].includes(bestRarity);
  const isMultiDrop = items.length > 1;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.92)' }}
    >
      {/* Background flash for rare+ */}
      {isHighRarity && phase === 'revealing' && (
        <div
          className="absolute inset-0 pointer-events-none screen-flash"
          style={{
            background: bestRarity === 'legendary' ? 'rgba(234,179,8,0.15)' :
                        bestRarity === 'mythic' ? 'rgba(236,72,153,0.15)' :
                        'rgba(103,232,249,0.15)',
          }}
        />
      )}

      <div className="relative w-full max-w-sm max-h-[85vh] overflow-y-auto scrollbar-thin py-8">
        {/* Phase 1: Chest shaking — overflow-visible to prevent clipping */}
        {(phase === 'shaking' || phase === 'bursting') && (
          <div className="flex flex-col items-center overflow-visible">
            <div className={cn(
              'text-7xl mb-6 overflow-visible',
              phase === 'shaking' && 'chest-shake',
              phase === 'bursting' && 'chest-burst'
            )}>
              {chest.emoji}
            </div>

            {/* Light beam */}
            {phase === 'bursting' && (
              <div className="chest-light-beam absolute top-0 left-1/2 -translate-x-1/2 w-20 h-48 bg-gradient-to-t from-white/0 via-white/25 to-white/5 rounded-full pointer-events-none" />
            )}
          </div>
        )}

        {/* Phase 2: Multi-item reveal */}
        {(phase === 'revealing' || phase === 'done') && (
          <motion.div
            initial={{ y: 30, scale: 0.5, opacity: 0 }}
            animate={{ y: 0, scale: 1, opacity: 1 }}
            transition={{ type: 'spring', stiffness: 200, damping: 15 }}
            className="relative"
          >
            <div
              className={cn(
                'rounded-2xl glass-strong overflow-hidden',
                `rarity-glow-${bestRarity}`
              )}
            >
              <div className={cn('h-1.5', `rarity-strip-${bestRarity}`)} />

              <div className="p-4 text-center">
                <button
                  onClick={onClose}
                  className="absolute top-3 right-3 w-7 h-7 rounded-md surface-sunken flex items-center justify-center text-muted-fg hover:text-frost-white z-10"
                >
                  <X className="w-3.5 h-3.5" strokeWidth={2} />
                </button>

                <p className="text-[10px] text-muted-fg uppercase tracking-[0.3em] mb-1">
                  {chest.name}
                </p>
                <p className="text-[11px] text-frost-white/70 font-semibold mb-3">
                  {items.length} {items.length === 1 ? 'предмет' : items.length < 5 ? 'предмета' : 'предметов'}
                </p>

                {/* Items grid */}
                <div className={cn(
                  'grid gap-2 mb-4',
                  items.length <= 3 ? 'grid-cols-1' : items.length <= 6 ? 'grid-cols-2' : 'grid-cols-2'
                )}>
                  {items.map((item, idx) => {
                    const rMeta = RARITY_META[item.rarity];
                    const isFrame = item.type === 'frame';
                    const delay = idx * 0.12;

                    return (
                      <motion.div
                        key={idx}
                        initial={{ opacity: 0, y: 20, scale: 0.7 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        transition={{ delay, type: 'spring', stiffness: 250, damping: 18 }}
                        className={cn(
                          'rounded-xl surface-sunken p-3 text-center relative overflow-hidden',
                          phase === 'revealing' && 'card-flip-reveal'
                        )}
                        style={{ animationDelay: `${delay}s` }}
                      >
                        {/* Rarity strip at top of card */}
                        <div className={cn('absolute top-0 left-0 right-0 h-0.5', `rarity-strip-${item.rarity}`)} />

                        {/* Frame preview */}
                        {isFrame && item.frame ? (
                          <div className="mb-1.5 flex justify-center">
                            <div
                              className="w-12 h-12 rounded-full flex items-center justify-center"
                              style={{
                                background: item.frame.borderColor,
                                boxShadow: item.frame.glowColor,
                                padding: '3px',
                              }}
                            >
                              <div className="w-full h-full rounded-full surface-sunken flex items-center justify-center text-xl">
                                🧊
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="text-3xl mb-1">{item.creatureEmoji}</div>
                        )}

                        <p className="text-[11px] font-semibold text-frost-white leading-tight">{item.creatureName}</p>
                        <span className={cn('inline-block text-[8px] uppercase tracking-[0.15em] mt-0.5', rMeta.color)}>
                          {rMeta.label}
                        </span>

                        {item.isDuplicate && (
                          <p className="text-[8px] text-amber-300 mt-0.5">
                            Дубль +{formatNumber(item.shardReward || 0)} ❄️
                          </p>
                        )}
                      </motion.div>
                    );
                  })}
                </div>

                {/* Sparkle particles for best item */}
                {phase === 'revealing' && isHighRarity && (
                  <>
                    {[...Array(8)].map((_, i) => (
                      <div
                        key={i}
                        className="particle-float absolute text-lg pointer-events-none"
                        style={{
                          left: `${20 + (i * 8) % 60}%`,
                          top: `${15 + (i * 13) % 40}%`,
                          animationDelay: `${i * 0.1}s`,
                        }}
                      >
                        {['✦', '✧', '❄', '⭐', '💎', '✨', '🌟', '💫'][i]}
                      </div>
                    ))}
                  </>
                )}

                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  className="text-[10px] text-muted-fg mb-3"
                >
                  Потрачено: {formatNumber(currentCost)} {chest.currency === 'crystals' ? '◆' : '★'}
                </motion.p>

                <motion.button
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                  onClick={onClose}
                  className={cn(
                    'w-full py-3 rounded-lg font-semibold text-[13px] active:scale-[0.98]',
                    chest.isDonate ? 'bg-gold text-ice-deep' : 'bg-ice text-ice-deep'
                  )}
                >
                  Забрать всё
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}

// ===== DONATE TAB =====
function DonateTab() {
  const telegramStars = useGameStore((s) => s.telegramStars);
  const crystals = useGameStore((s) => s.crystals);
  const purchaseDonatePack = useGameStore((s) => s.purchaseDonatePack);

  const handlePurchase = (packId: string) => {
    const result = purchaseDonatePack(packId);
    if (result.success) {
      toast.success('Кристаллы получены', {
        description: `+${formatNumber(result.crystalsAdded!)} 💎`,
      });
    } else {
      toast.error(result.error || 'Не удалось приобрести');
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md surface-sunken">
          <span className="text-gold">★</span>
          <span className="text-[12px] font-semibold text-gold tabular-nums">{telegramStars}</span>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md surface-sunken">
          <span className="text-ice">💎</span>
          <span className="text-[12px] font-semibold text-ice tabular-nums">{formatNumber(crystals)}</span>
        </div>
      </div>

      <div className="space-y-2">
        {DONATE_PACKS.map((pack, idx) => {
          const canAfford = telegramStars >= pack.stars;
          return (
            <motion.div
              key={pack.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.08 }}
              className={cn(
                'surface rounded-xl p-4 relative overflow-hidden',
                pack.popular && 'ring-active'
              )}
            >
              {pack.popular && (
                <div className="absolute top-0 right-0 bg-gold text-ice-deep text-[8px] font-bold px-2 py-0.5 rounded-bl-lg">
                  ХИТ
                </div>
              )}

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-lg surface-sunken flex items-center justify-center text-2xl">
                    💎
                  </div>
                  <div>
                    <p className="text-[15px] font-semibold text-frost-white">
                      {formatNumber(pack.crystals)} 💎
                    </p>
                    {pack.bonus && (
                      <p className="text-[10px] text-gold mt-0.5">{pack.bonus}</p>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => handlePurchase(pack.id)}
                  disabled={!canAfford}
                  className={cn(
                    'px-4 py-2.5 rounded-lg font-semibold text-[12px] transition-all flex items-center gap-1.5',
                    canAfford
                      ? 'bg-gold text-ice-deep hover:opacity-90 active:scale-[0.98]'
                      : 'surface-sunken text-muted-fg'
                  )}
                >
                  <Star className="w-3.5 h-3.5" strokeWidth={2} />
                  {pack.stars}
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="surface rounded-lg p-3">
        <p className="text-[10px] text-muted-fg leading-relaxed">
          Telegram Stars — внутренняя валюта Telegram. Покупка кристаллов мгновенная. В продакшн-версии оплата через Telegram Invoice API.
        </p>
      </div>
    </div>
  );
}

// ===== ARTIFACTS TAB =====
function ArtifactsTab() {
  const ownedArtifacts = useGameStore((s) => s.ownedArtifacts);
  const equippedArtifacts = useGameStore((s) => s.equippedArtifacts);
  const equipArtifact = useGameStore((s) => s.equipArtifact);
  const unequipArtifact = useGameStore((s) => s.unequipArtifact);

  return (
    <div className="space-y-3">
      <div className="surface rounded-xl p-3">
        <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em] mb-2 flex items-center gap-1.5">
          <Sparkles className="w-3 h-3 text-aurora" strokeWidth={1.75} />
          Комплекты
        </p>
        <div className="grid grid-cols-2 gap-1.5">
          {ARTIFACT_SETS.map((set) => (
            <div key={set.name} className="surface-sunken rounded-lg p-2">
              <p className="text-[11px] font-medium text-aurora">{set.name}</p>
              <p className="text-[10px] text-gold mt-0.5">{set.bonus}</p>
              <p className="text-[9px] text-muted-fg mt-0.5">{set.pieces} предмета</p>
            </div>
          ))}
        </div>
      </div>

      <div className="surface rounded-xl p-3">
        <div className="flex items-center justify-between mb-2">
          <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em]">Экипировано</p>
          <span className="text-[11px] text-ice font-semibold tabular-nums">{equippedArtifacts.length}/6</span>
        </div>
        <div className="grid grid-cols-6 gap-1">
          {Array.from({ length: 6 }).map((_, i) => {
            const artId = equippedArtifacts[i];
            const art = artId ? ARTIFACTS.find((a) => a.id === artId) : null;
            return (
              <div
                key={i}
                className={cn(
                  'aspect-square rounded-md flex items-center justify-center text-lg',
                  art ? 'surface-elevated' : 'surface-sunken border border-dashed border-border'
                )}
              >
                {art ? art.emoji : <Star className="w-3 h-3 text-muted-fg/50" strokeWidth={1.5} />}
              </div>
            );
          })}
        </div>
      </div>

      <div>
        <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em] mb-2 px-1">
          Коллекция · {ownedArtifacts.length}
        </p>
        {ownedArtifacts.length === 0 ? (
          <div className="surface rounded-xl p-6 text-center">
            <Sparkles className="w-7 h-7 text-muted-fg/50 mx-auto mb-2" strokeWidth={1.5} />
            <p className="text-[11px] text-muted-fg">
              Пока нет артефактов. Побеждай боссов и открывай сундуки.
            </p>
          </div>
        ) : (
          <div className="space-y-1.5">
            {ownedArtifacts.map((artId) => {
              const art = ARTIFACTS.find((a) => a.id === artId);
              if (!art) return null;
              const isEquipped = equippedArtifacts.includes(artId);
              const rarityMeta = RARITY_META[art.rarity];

              return (
                <div
                  key={artId}
                  className={cn('surface rounded-lg p-2.5 flex items-center gap-2.5', isEquipped && 'ring-active')}
                >
                  <div className="relative w-10 h-10 rounded-md surface-sunken flex items-center justify-center text-xl flex-shrink-0">
                    {art.emoji}
                    <div className={cn('absolute top-0 left-0 right-0 h-0.5 rounded-t-md', `rarity-strip-${art.rarity}`)} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="text-[12px] font-semibold text-frost-white truncate">{art.name}</p>
                      <span className={cn('text-[8px] uppercase tracking-wider', rarityMeta.color)}>
                        {rarityMeta.label}
                      </span>
                    </div>
                    <p className="text-[9px] text-muted-fg">{art.set}</p>
                    <p className="text-[10px] text-gold mt-0.5">{art.bonus}</p>
                  </div>
                  <button
                    onClick={() => (isEquipped ? unequipArtifact(artId) : equipArtifact(artId))}
                    className={cn(
                      'flex-shrink-0 px-2.5 py-1.5 rounded-md text-[10px] font-semibold transition-all',
                      isEquipped
                        ? 'surface-sunken text-red-300'
                        : 'bg-ice/15 text-ice hover:bg-ice/25'
                    )}
                  >
                    {isEquipped ? 'Снять' : 'Надеть'}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// ===== CLAN TAB =====
function ClanTab() {
  const clan = useGameStore((s) => s.clan);
  const crystals = useGameStore((s) => s.crystals);
  const createClan = useGameStore((s) => s.createClan);
  const leaveClan = useGameStore((s) => s.leaveClan);
  const contributeToClan = useGameStore((s) => s.contributeToClan);
  const getClanBonus = useGameStore((s) => s.getClanBonus);
  const getClanLevelInfo = useGameStore((s) => s.getClanLevelInfo);
  const bossesDefeated = useGameStore((s) => s.bossesDefeated);

  const [showCreate, setShowCreate] = useState(false);
  const [clanNameInput, setClanNameInput] = useState('');
  const [contributeAmount, setContributeAmount] = useState<string>('10000');

  const clanLevelInfo = getClanLevelInfo();
  const clanBonus = getClanBonus();
  const currentLevelData = getClanLevel(clan.treasury);
  const nextLevelData = getNextClanLevel(clan.treasury);

  const handleCreate = () => {
    if (clanNameInput.trim().length < 3) {
      toast.error('Название клана минимум 3 символа');
      return;
    }
    createClan(clanNameInput.trim());
    toast.success('Клан создан', { description: `«${clanNameInput.trim()}»` });
    setShowCreate(false);
    setClanNameInput('');
  };

  const handleContribute = () => {
    const amount = parseInt(contributeAmount) || 0;
    if (amount < 1000) {
      toast.error('Минимальный вклад — 1 000 кристаллов');
      return;
    }
    if (contributeToClan(amount)) {
      toast.success('Вклад внесён', { description: `+${formatNumber(amount)} 💎 в казну` });
    } else {
      toast.error('Недостаточно кристаллов');
    }
  };

  if (clan.id) {
    const progressToNext = nextLevelData
      ? ((clan.treasury - currentLevelData.requiredTreasury) / (nextLevelData.requiredTreasury - currentLevelData.requiredTreasury)) * 100
      : 100;

    return (
      <div className="space-y-3">
        <div className="surface-elevated rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-lg surface-sunken flex items-center justify-center text-3xl">
              ⚑
            </div>
            <div className="flex-1">
              <h3 className="text-[15px] font-semibold text-frost-white">{clan.name}</h3>
              <p className="text-[10px] text-gold mt-0.5">{currentLevelData.title} · Уровень {clanLevelInfo.level}</p>
              <p className="text-[10px] text-muted-fg">{clan.members.length} участников</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <div className="surface rounded-lg p-2.5 text-center">
            <Trophy className="w-3 h-3 text-gold mx-auto mb-1" strokeWidth={1.75} />
            <p className="text-[8px] text-muted-fg uppercase tracking-wider">Казна</p>
            <p className="text-[12px] font-semibold text-gold tabular-nums mt-0.5">{formatNumber(clan.treasury)}</p>
          </div>
          <div className="surface rounded-lg p-2.5 text-center">
            <Swords className="w-3 h-3 text-red-400 mx-auto mb-1" strokeWidth={1.75} />
            <p className="text-[8px] text-muted-fg uppercase tracking-wider">Боссы</p>
            <p className="text-[12px] font-semibold text-red-300 tabular-nums mt-0.5">{bossesDefeated}</p>
          </div>
          <div className="surface rounded-lg p-2.5 text-center">
            <Zap className="w-3 h-3 text-ice mx-auto mb-1" strokeWidth={1.75} />
            <p className="text-[8px] text-muted-fg uppercase tracking-wider">Бонус</p>
            <p className="text-[12px] font-semibold text-ice tabular-nums mt-0.5">+{clanBonus.autoMineBonus}%</p>
          </div>
        </div>

        {nextLevelData && (
          <div className="surface rounded-xl p-3">
            <div className="flex items-center justify-between mb-1.5">
              <p className="text-[10px] text-muted-fg uppercase tracking-[0.15em]">
                До уровня {nextLevelData.level} — {nextLevelData.title}
              </p>
              <span className="text-[10px] text-ice font-semibold tabular-nums">
                {formatNumber(clan.treasury)} / {formatNumber(nextLevelData.requiredTreasury)}
              </span>
            </div>
            <div className="h-2 surface-sunken rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-ice/60 to-aurora/60 rounded-full"
                animate={{ width: `${Math.min(100, progressToNext)}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
            <p className="text-[9px] text-muted-fg mt-1.5">
              Осталось: {formatNumber(nextLevelData.requiredTreasury - clan.treasury)} 💎
            </p>
          </div>
        )}

        <div className="surface rounded-xl p-3 space-y-1.5">
          <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em] mb-1">Бонусы уровня {clanLevelInfo.level}</p>
          <div className="flex items-center gap-2 p-2 rounded surface-sunken">
            <Zap className="w-3 h-3 text-ice" strokeWidth={2} />
            <div>
              <p className="text-[11px] font-medium text-frost-white">Сила клика: +{clanBonus.clickBonus}%</p>
              <p className="text-[9px] text-muted-fg">Увеличивает урон за тап</p>
            </div>
          </div>
          <div className="flex items-center gap-2 p-2 rounded surface-sunken">
            <TrendingUp className="w-3 h-3 text-ice" strokeWidth={2} />
            <div>
              <p className="text-[11px] font-medium text-frost-white">Авто-добыча: +{clanBonus.autoMineBonus}%</p>
              <p className="text-[9px] text-muted-fg">Увеличивает пассивный доход</p>
            </div>
          </div>
          <div className="flex items-center gap-2 p-2 rounded surface-sunken">
            <Users className="w-3 h-3 text-ice" strokeWidth={2} />
            <div>
              <p className="text-[11px] font-medium text-frost-white">Лимит участников: {currentLevelData.memberLimit}</p>
              <p className="text-[9px] text-muted-fg">Максимум членов клана</p>
            </div>
          </div>
        </div>

        <div className="surface rounded-xl p-3 space-y-2">
          <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em]">Внести вклад в казну</p>
          <div className="flex gap-2">
            <input
              type="text"
              value={contributeAmount}
              onChange={(e) => setContributeAmount(e.target.value.replace(/\D/g, ''))}
              placeholder="10000"
              className="flex-1 px-3 py-2.5 rounded-lg surface-sunken text-[13px] text-frost-white placeholder:text-muted-fg outline-none focus:ring-active"
            />
            <button
              onClick={handleContribute}
              disabled={crystals < (parseInt(contributeAmount) || 0)}
              className={cn(
                'px-4 py-2.5 rounded-lg font-semibold text-[12px] transition-all',
                crystals >= (parseInt(contributeAmount) || 0) && parseInt(contributeAmount) >= 1000
                  ? 'bg-gold text-ice-deep hover:opacity-90 active:scale-[0.98]'
                  : 'surface-sunken text-muted-fg'
              )}
            >
              Внести
            </button>
          </div>
          <div className="flex gap-1.5">
            {['1000', '10000', '100000', '1000000'].map((amount) => (
              <button
                key={amount}
                onClick={() => setContributeAmount(amount)}
                className={cn(
                  'flex-1 py-1.5 rounded text-[9px] font-medium transition-all',
                  contributeAmount === amount
                    ? 'surface-elevated text-ice ring-active'
                    : 'surface-sunken text-muted-fg hover:text-frost-white/80'
                )}
              >
                {formatNumber(parseInt(amount))}
              </button>
            ))}
          </div>
        </div>

        <div className="surface rounded-xl p-3">
          <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em] mb-2">Вклады участников</p>
          {clan.members.map((member) => (
            <div key={member.id} className="flex items-center justify-between py-1.5">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded surface-sunken flex items-center justify-center text-[10px]">👤</div>
                <span className="text-[11px] text-frost-white">{member.name}</span>
              </div>
              <span className="text-[10px] text-gold tabular-nums">{formatNumber(member.contribution)} 💎</span>
            </div>
          ))}
        </div>

        <div className="surface rounded-xl p-3 space-y-1.5">
          <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em] mb-1">Возможности</p>
          {[
            { icon: '💬', label: 'Общий чат', desc: 'Общайся с участниками' },
            { icon: '⚔', label: 'Клановые рейды', desc: 'Атакуй боссов вместе' },
            { icon: '🏆', label: 'Общий рейтинг', desc: 'Соревнуйся с другими кланами' },
            { icon: '👑', label: 'Клановые боссы', desc: 'Уникальные награды' },
          ].map((f) => (
            <div key={f.label} className="flex items-center gap-2.5 p-2 rounded surface-sunken">
              <span className="text-base">{f.icon}</span>
              <div>
                <p className="text-[11px] font-medium text-frost-white">{f.label}</p>
                <p className="text-[9px] text-muted-fg">{f.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={leaveClan}
          className="w-full py-2.5 rounded-lg surface-sunken text-red-300 text-[11px] font-semibold hover:bg-red-500/10"
        >
          Покинуть клан
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="surface rounded-xl p-6 text-center">
        <div className="text-4xl mb-3">⚑</div>
        <h3 className="text-[14px] font-semibold text-frost-white mb-1">Создай ледяной клан</h3>
        <p className="text-[11px] text-muted-fg leading-relaxed">
          Объединяйся с другими игроками для совместных рейдов и уникальных наград
        </p>
      </div>

      {showCreate ? (
        <div className="surface-elevated rounded-xl p-4 space-y-3">
          <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em]">Название клана</p>
          <input
            value={clanNameInput}
            onChange={(e) => setClanNameInput(e.target.value)}
            maxLength={20}
            placeholder="Ледяные Волки"
            className="w-full px-3 py-2.5 rounded-lg surface-sunken text-[13px] text-frost-white placeholder:text-muted-fg outline-none focus:ring-active"
          />
          <div className="flex gap-2">
            <button
              onClick={() => setShowCreate(false)}
              className="flex-1 py-2.5 rounded-lg surface-sunken text-muted-fg text-[12px] font-medium"
            >
              Отмена
            </button>
            <button
              onClick={handleCreate}
              className="flex-1 py-2.5 rounded-lg bg-ice text-ice-deep text-[12px] font-semibold active:scale-[0.98]"
            >
              Создать
            </button>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setShowCreate(true)}
          className="w-full py-3 rounded-lg bg-aurora/20 text-aurora font-semibold text-[13px] hover:bg-aurora/30 active:scale-[0.98]"
        >
          Создать клан
        </button>
      )}

      <div className="surface rounded-xl p-3">
        <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em] mb-2">Уровни клана</p>
        <div className="space-y-1">
          {CLAN_LEVELS.slice(0, 5).map((lvl) => (
            <div key={lvl.level} className="flex items-center justify-between p-1.5 rounded surface-sunken">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-semibold text-gold tabular-nums w-4">L{lvl.level}</span>
                <span className="text-[10px] text-frost-white">{lvl.title}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[9px] text-ice">+{lvl.clickBonus}% клик</span>
                <span className="text-[9px] text-aurora">+{lvl.autoMineBonus}% доход</span>
              </div>
            </div>
          ))}
        </div>
        <p className="text-[9px] text-muted-fg mt-1.5 text-center">и ещё {CLAN_LEVELS.length - 5} уровней...</p>
      </div>

      <div className="surface rounded-xl p-3">
        <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em] mb-2">Топ кланов недели</p>
        {[
          { name: 'Аврора', score: 1250000, emoji: '✦' },
          { name: 'Вечный Мороз', score: 980000, emoji: '❄' },
          { name: 'Северные Волки', score: 750000, emoji: '🐺' },
        ].map((c, i) => (
          <div key={c.name} className="flex items-center gap-2.5 py-1.5">
            <span className="text-[11px] font-semibold text-muted-fg w-4 tabular-nums">{i + 1}</span>
            <span className="text-base">{c.emoji}</span>
            <span className="text-[12px] text-frost-white flex-1">{c.name}</span>
            <span className="text-[11px] font-semibold text-gold tabular-nums">{formatNumber(c.score)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
