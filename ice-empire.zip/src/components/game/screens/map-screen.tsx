'use client';

import { motion } from 'framer-motion';
import { useGameStore } from '@/lib/game-store';
import { LOCATIONS } from '@/lib/game-data';
import { formatNumber } from '@/lib/format';
import { Lock, Check, ChevronRight, MapPin } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { useState } from 'react';

export function MapScreen() {
  const unlockedLocations = useGameStore((s) => s.unlockedLocations);
  const currentLocation = useGameStore((s) => s.currentLocation);
  const crystals = useGameStore((s) => s.crystals);
  const unlockLocation = useGameStore((s) => s.unlockLocation);
  const setCurrentLocation = useGameStore((s) => s.setCurrentLocation);
  const getIncomePerSecond = useGameStore((s) => s.getIncomePerSecond);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const income = getIncomePerSecond();

  const handleUnlock = (locId: string) => {
    const loc = LOCATIONS.find((l) => l.id === locId);
    if (!loc) return;
    if (confirmId === locId) {
      if (unlockLocation(locId)) {
        toast.success('Локация открыта', { description: `${loc.emoji} ${loc.name}` });
      } else {
        toast.error('Недостаточно кристаллов');
      }
      setConfirmId(null);
    } else {
      setConfirmId(locId);
      setTimeout(() => setConfirmId(null), 3000);
    }
  };

  return (
    <div className="px-4 pt-5 pb-8 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-[17px] font-semibold text-frost-white tracking-tight flex items-center gap-2">
            <MapPin className="w-4 h-4 text-aurora" strokeWidth={1.75} />
            Карта мира
          </h2>
          <p className="text-[11px] text-muted-fg mt-0.5">Открой все 6 локаций Севера</p>
        </div>
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md surface-sunken">
          <span className="text-[11px] text-ice">◆</span>
          <span className="text-[12px] font-semibold text-ice tabular-nums">{formatNumber(crystals)}</span>
        </div>
      </div>

      <div className="space-y-2.5">
        {LOCATIONS.map((loc, idx) => {
          const isUnlocked = unlockedLocations.includes(loc.id);
          const isCurrent = currentLocation === loc.id;
          const canAfford = crystals >= loc.unlockCost;
          const isConfirm = confirmId === loc.id;

          return (
            <motion.div
              key={loc.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.06 }}
              className="relative"
            >
              {idx < LOCATIONS.length - 1 && (
                <div className="absolute left-[34px] top-full h-2.5 w-px bg-border" />
              )}

              <div
                className={cn(
                  'relative rounded-xl overflow-hidden transition-all',
                  isCurrent ? 'surface-elevated ring-active' : 'surface'
                )}
              >
                <div className="p-3.5 flex items-center gap-3">
                  <div
                    className={cn(
                      'relative w-12 h-12 rounded-lg flex items-center justify-center text-2xl flex-shrink-0',
                      isUnlocked ? 'surface-sunken' : 'surface-sunken opacity-50'
                    )}
                  >
                    {isUnlocked ? loc.emoji : <Lock className="w-4 h-4 text-muted-fg" strokeWidth={1.5} />}
                    {isCurrent && (
                      <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-ice" />
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h3 className={cn(
                        'text-[13px] font-semibold tracking-tight',
                        isUnlocked ? 'text-frost-white' : 'text-muted-fg'
                      )}>
                        {loc.name}
                      </h3>
                      {isCurrent && (
                        <span className="text-[8px] uppercase tracking-wider text-ice font-semibold">
                          Активна
                        </span>
                      )}
                      {isUnlocked && !isCurrent && (
                        <Check className="w-3 h-3 text-ice" strokeWidth={2.5} />
                      )}
                    </div>
                    <p className="text-[10px] text-muted-fg line-clamp-1 mt-0.5">{loc.description}</p>
                    <div className="flex items-center gap-3 mt-1.5">
                      <span className="text-[10px] text-ice/80 tabular-nums">x{loc.incomeMultiplier} доход</span>
                      <span className="text-[10px] text-aurora/80 tabular-nums">{loc.auroraDrop}% аврора</span>
                    </div>
                  </div>

                  {isUnlocked ? (
                    !isCurrent && (
                      <button
                        onClick={() => {
                          setCurrentLocation(loc.id);
                          toast.success(`Активна: ${loc.name}`);
                        }}
                        className="flex-shrink-0 px-2.5 py-1.5 rounded-md surface-sunken text-[11px] text-ice font-medium hover:ring-active"
                      >
                        Выбрать
                      </button>
                    )
                  ) : (
                    <button
                      onClick={() => handleUnlock(loc.id)}
                      className={cn(
                        'flex-shrink-0 px-2.5 py-1.5 rounded-md text-[11px] font-semibold transition-all flex items-center gap-1',
                        isConfirm
                          ? 'bg-red-500/15 text-red-300'
                          : canAfford
                          ? 'surface-sunken text-gold hover:ring-active'
                          : 'surface-sunken text-muted-fg'
                      )}
                    >
                      {isConfirm ? 'Точно?' : (
                        <>
                          {formatNumber(loc.unlockCost)}
                          <ChevronRight className="w-3 h-3" strokeWidth={2} />
                        </>
                      )}
                    </button>
                  )}
                </div>

                {isUnlocked && isCurrent && (
                  <div className="px-3.5 pb-3 -mt-1">
                    <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded surface-sunken">
                      <span className="text-[10px] text-muted-fg">Текущая добыча:</span>
                      <span className="text-[10px] font-semibold text-ice tabular-nums">
                        {formatNumber(income)}/с
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
