'use client';

import { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore } from '@/lib/game-store';
import { CREATURES, RARITY_META, LOCATIONS } from '@/lib/game-data';
import { formatNumber } from '@/lib/format';
import { Gift, Flame, ChevronRight, Crown, Users, Map as MapIcon, Zap, Gem, Trophy } from 'lucide-react';
import { DailyRewardModal } from '../modals/daily-reward-modal';
import { PrestigeModal } from '../modals/prestige-modal';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface HomeScreenProps {
  onNavigate: (screen: 'creatures' | 'map' | 'bosses' | 'shop' | 'season') => void;
}

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  const crystals = useGameStore((s) => s.crystals);
  const addCrystals = useGameStore((s) => s.addCrystals);
  const ownedCreatures = useGameStore((s) => s.ownedCreatures);
  const currentLocation = useGameStore((s) => s.currentLocation);
  const prestigeLevel = useGameStore((s) => s.prestigeLevel);
  const playerLevel = useGameStore((s) => s.playerLevel);
  const dailyStreak = useGameStore((s) => s.dailyStreak);
  const lastDailyClaim = useGameStore((s) => s.lastDailyClaim);
  const claimDailyReward = useGameStore((s) => s.claimDailyReward);
  const getIncomePerSecond = useGameStore((s) => s.getIncomePerSecond);
  const unlockedLocations = useGameStore((s) => s.unlockedLocations);
  const getClanBonus = useGameStore((s) => s.getClanBonus);
  const seasonXp = useGameStore((s) => s.seasonXp);
  const seasonPremium = useGameStore((s) => s.seasonPremium);

  const [showDaily, setShowDaily] = useState(false);
  const [showPrestige, setShowPrestige] = useState(false);
  const [tapEffects, setTapEffects] = useState<{ id: number; x: number; y: number }[]>([]);
  const tapIdRef = useRef(0);

  const location = LOCATIONS.find((l) => l.id === currentLocation);
  const income = getIncomePerSecond();
  const canClaimDaily = Date.now() - lastDailyClaim >= 24 * 3600 * 1000;
  const ownedCount = Object.values(ownedCreatures).filter((c) => c.unlocked).length;
  const clanBonus = getClanBonus();
  const tapReward = Math.max(1, Math.floor(income * 0.1 * (1 + clanBonus.clickBonus / 100)) + 1);

  const handleTap = (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const id = tapIdRef.current++;
    setTapEffects((prev) => [...prev, { id, x, y }]);
    setTimeout(() => setTapEffects((prev) => prev.filter((t) => t.id !== id)), 900);
    addCrystals(tapReward);
  };

  const owned = Object.values(ownedCreatures)
    .filter((c) => c.unlocked)
    .map((c) => ({ owned: c, def: CREATURES.find((cr) => cr.id === c.id)! }))
    .sort((a, b) => RARITY_META[b.def.rarity].order - RARITY_META[a.def.rarity].order);
  const featured = owned[0];

  return (
    <div className="px-4 pt-5 pb-8 space-y-5">
      {/* Location label */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-base">{location?.emoji}</span>
          <div>
            <p className="text-[13px] font-semibold text-frost-white tracking-tight">{location?.name}</p>
            <p className="text-[10px] text-muted-fg uppercase tracking-wider mt-0.5">x{location?.incomeMultiplier} добыча</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-[10px] text-muted-fg uppercase tracking-wider">Уровень</p>
          <p className="text-[13px] font-semibold text-ice tabular-nums">{playerLevel}</p>
        </div>
      </div>

      {/* Main tap zone */}
      <div className="relative">
        <div className="relative overflow-hidden rounded-2xl surface aurora-bg py-10 px-6 text-center">
          <p className="text-[10px] text-muted-fg uppercase tracking-[0.3em] mb-6">
            Кристальный монолит
          </p>

          <button
            onClick={handleTap}
            className="relative mx-auto block select-none active:scale-[0.97] transition-transform"
          >
            <motion.div
              animate={{ y: [0, -6, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
              className="relative"
            >
              <div className="text-[88px] leading-none drop-shadow-[0_8px_24px_rgba(125,211,252,0.25)]">
                ❄
              </div>
            </motion.div>

            <AnimatePresence>
              {tapEffects.map((effect) => (
                <motion.div
                  key={effect.id}
                  initial={{ opacity: 1, y: 0, scale: 0.8 }}
                  animate={{ opacity: 0, y: -50, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.9, ease: 'easeOut' }}
                  className="absolute pointer-events-none text-ice font-semibold text-sm tabular-nums"
                  style={{ left: effect.x, top: effect.y }}
                >
                  +{formatNumber(tapReward)}
                </motion.div>
              ))}
            </AnimatePresence>
          </button>

          <div className="mt-6 flex items-center justify-center gap-1.5">
            <Zap className="w-3 h-3 text-ice/70" strokeWidth={2} />
            <span className="text-[11px] text-muted-fg">+{formatNumber(tapReward)} за тап</span>
            {clanBonus.clickBonus > 0 && (
              <span className="text-[9px] text-gold ml-1">(+{clanBonus.clickBonus}% клан)</span>
            )}
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-2.5">
        <StatCard
          icon={<Users className="w-3.5 h-3.5" strokeWidth={1.75} />}
          label="Существа"
          value={`${ownedCount} / ${CREATURES.length}`}
          onClick={() => onNavigate('creatures')}
        />
        <StatCard
          icon={<MapIcon className="w-3.5 h-3.5" strokeWidth={1.75} />}
          label="Локации"
          value={`${unlockedLocations.length} / 6`}
          onClick={() => onNavigate('map')}
        />
      </div>

      {/* Daily reward */}
      <button
        onClick={() => {
          if (canClaimDaily) {
            const result = claimDailyReward();
            if (result.claimed && result.reward) {
              toast.success('Ежедневная награда получена', { description: result.reward });
            }
          } else {
            setShowDaily(true);
          }
        }}
        className="w-full group surface rounded-xl p-3.5 flex items-center gap-3 text-left transition-colors hover:border-ice/30"
      >
        <div className="w-10 h-10 rounded-lg surface-sunken flex items-center justify-center flex-shrink-0">
          <Gift className="w-4 h-4 text-gold" strokeWidth={1.75} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <p className="text-[13px] font-semibold text-frost-white">Ежедневная награда</p>
            {canClaimDaily && (
              <span className="w-1.5 h-1.5 rounded-full bg-ice animate-pulse-soft" />
            )}
          </div>
          <p className="text-[11px] text-muted-fg mt-0.5">
            {canClaimDaily ? 'Готово к получению' : `Серия ${dailyStreak} дн.`}
          </p>
        </div>
        <ChevronRight className="w-4 h-4 text-muted-fg group-hover:text-ice transition-colors" strokeWidth={1.75} />
      </button>

      {/* Featured creature */}
      {featured && (
        <div className="surface rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-3.5 pt-3 pb-2">
            <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em]">Лучшее существо</p>
            <button
              onClick={() => onNavigate('creatures')}
              className="text-[11px] text-ice hover:underline flex items-center gap-0.5"
            >
              Все <ChevronRight className="w-3 h-3" />
            </button>
          </div>
          <div className="divider mx-3.5" />
          <div className="px-3.5 py-3 flex items-center gap-3">
            <div className="relative w-14 h-14 rounded-lg surface-sunken flex items-center justify-center text-3xl flex-shrink-0">
              {featured.def.emoji}
              <div className={cn('absolute top-0 left-0 right-0 h-0.5 rounded-t-lg', `rarity-strip-${featured.def.rarity}`)} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="text-[13px] font-semibold text-frost-white truncate">{featured.def.name}</p>
                <span className={cn('text-[9px] font-medium uppercase tracking-wider', RARITY_META[featured.def.rarity].color)}>
                  {RARITY_META[featured.def.rarity].label}
                </span>
              </div>
              <p className="text-[11px] text-muted-fg mt-0.5 line-clamp-1">{featured.def.skill}</p>
              <div className="flex items-center gap-2 mt-1.5">
                <span className="text-[11px] font-semibold text-ice tabular-nums">L{featured.owned.level}</span>
                <div className="flex-1 h-1 bg-slate-700/40 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-ice/60 rounded-full"
                    style={{ width: `${Math.min(100, featured.owned.level)}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Season Pass */}
      <button
        onClick={() => onNavigate('season')}
        className="w-full group relative overflow-hidden rounded-xl p-3.5 flex items-center gap-3 text-left transition-all hover:scale-[1.01]"
        style={{
          background: seasonPremium
            ? 'linear-gradient(135deg, oklch(0.78 0.13 85 / 0.08), oklch(0.65 0.14 295 / 0.08))'
            : 'linear-gradient(135deg, oklch(0.25 0.08 250), oklch(0.22 0.10 295))',
          border: `1px solid ${seasonPremium ? 'oklch(0.78 0.12 85 / 20%)' : 'oklch(0.78 0.10 215 / 15%)'}`,
        }}
      >
        <div className={cn(
          'w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0',
          seasonPremium ? 'bg-gold/10' : 'bg-aurora/10',
        )}>
          <Trophy className={cn('w-4 h-4', seasonPremium ? 'text-gold' : 'text-aurora')} strokeWidth={1.75} />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-1.5">
            <p className={cn('text-[13px] font-semibold', seasonPremium ? 'text-gold' : 'text-frost-white')}>
              Сезонный пропуск
            </p>
            {seasonPremium && (
              <Crown className="w-3 h-3 text-gold" strokeWidth={2} />
            )}
          </div>
          <p className="text-[11px] text-muted-fg mt-0.5">
            {formatNumber(seasonXp)} XP · Эпоха Мороза
          </p>
        </div>
        <ChevronRight className="w-4 h-4 text-muted-fg group-hover:text-ice transition-colors" strokeWidth={1.75} />
      </button>

      {/* Prestige */}
      <button
        onClick={() => setShowPrestige(true)}
        className="w-full group surface rounded-xl p-3.5 flex items-center gap-3 text-left transition-colors hover:border-gold/30"
      >
        <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: 'oklch(0.78 0.13 85 / 0.12)' }}>
          <Crown className="w-4 h-4 text-gold" strokeWidth={1.75} />
        </div>
        <div className="flex-1">
          <p className="text-[13px] font-semibold text-frost-white">Престиж</p>
          <p className="text-[11px] text-muted-fg mt-0.5">
            {playerLevel >= 100 ? 'Доступен — получи Короны Севера' : `Доступно с уровня 100 (сейчас ${playerLevel})`}
          </p>
        </div>
        <ChevronRight className="w-4 h-4 text-muted-fg group-hover:text-gold transition-colors" strokeWidth={1.75} />
      </button>

      <DailyRewardModal open={showDaily} onOpenChange={setShowDaily} />
      <PrestigeModal open={showPrestige} onOpenChange={setShowPrestige} />
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="surface rounded-xl p-3.5 text-left transition-colors hover:border-ice/30"
    >
      <div className="flex items-center gap-1.5 text-muted-fg mb-1.5">
        {icon}
        <span className="text-[10px] uppercase tracking-[0.15em]">{label}</span>
      </div>
      <p className="text-[15px] font-semibold text-frost-white tabular-nums">{value}</p>
    </button>
  );
}
