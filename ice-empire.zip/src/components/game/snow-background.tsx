'use client';

import { useMemo } from 'react';

interface Snowflake {
  id: number;
  left: number;
  duration: number;
  delay: number;
  size: number;
  char: string;
}

const SNOW_CHARS = ['❄', '❅', '❆', '✦', '✧', '·'];

function seededFlake(i: number): Snowflake {
  const left = ((i * 37 + 13) % 1000) / 10;
  const duration = 14 + ((i * 7) % 18);
  const delay = ((i * 13) % 150) / 10;
  const size = 6 + ((i * 3) % 8);
  const char = SNOW_CHARS[i % SNOW_CHARS.length];
  return { id: i, left, duration, delay, size, char };
}

export function SnowBackground() {
  const snowflakes = useMemo(() => Array.from({ length: 10 }, (_, i) => seededFlake(i)), []);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {snowflakes.map((flake) => (
        <span
          key={flake.id}
          className="snow-particle"
          style={{
            left: `${flake.left}%`,
            fontSize: `${flake.size}px`,
            animationDuration: `${flake.duration}s`,
            animationDelay: `${flake.delay}s`,
          }}
        >
          {flake.char}
        </span>
      ))}
    </div>
  );
}
