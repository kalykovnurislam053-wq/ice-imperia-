'use client';

import { useGameStore } from '@/lib/game-store';
import { getProfileFrameById, getProfileSkinById, type Rarity } from '@/lib/game-data';
import { cn } from '@/lib/utils';

// ============================================================
// Avatar composition system
// ============================================================
// All decorative elements are absolutely positioned relative
// to the AvatarContainer. Every coordinate is calculated from
// a single `avatarSize` number (in pixels) so everything
// scales automatically when the avatar size changes.
//
// Structure:
//   AvatarContainer (position:relative, fixed px size)
//    ├── Frame        (absolute, centered on avatar)
//    ├── Avatar       (absolute, centered)
//    ├── SkinOverlay  (absolute, anchored to top of avatar)
//    └── LevelBadge   (absolute, top-left of avatar)
// ============================================================

// --- Pixel sizes for each variant ---
const PROFILE_SIZES: Record<string, number> = {
  sm: 32,   // top-bar
  md: 40,   // default
  lg: 56,   // profile modal
};

const CHAT_SIZES: Record<string, number> = {
  sm: 28,
  md: 36,
};

// --- Frame ring thickness (px per side) ---
const FRAME_PADDING = 3;
const CHAT_FRAME_PADDING = 2;

// ============================================================
// ProfileAvatar — main player avatar
// ============================================================
export function ProfileAvatar({ size = 'md' }: { size?: 'sm' | 'md' | 'lg' }) {
  const selectedFrame = useGameStore((s) => s.selectedFrame);
  const selectedSkin = useGameStore((s) => s.selectedSkin);
  const playerLevel = useGameStore((s) => s.playerLevel);
  const prestigeLevel = useGameStore((s) => s.prestigeLevel);
  const telegramAvatarUrl = useGameStore((s) => s.telegramAvatarUrl);

  const skin = getProfileSkinById(selectedSkin);
  const frame = selectedFrame ? getProfileFrameById(selectedFrame) : null;

  const a = PROFILE_SIZES[size]; // avatar diameter in px
  const fp = FRAME_PADDING;
  const total = a + fp * 2;     // container size (avatar + frame ring)
  const frameAnimClass = frame ? getFrameAnimationClass(frame.rarity) : '';

  // Skin overlay size scales with avatar
  const skinFontSize = a * 0.42 * (skin?.overlayScale ?? 1);
  // Level badge size scales with avatar
  const badgeSize = Math.max(14, Math.round(a * 0.38));
  const badgeFontSize = Math.max(7, Math.round(a * 0.2));

  return (
    <div
      className="relative flex-shrink-0"
      style={{ width: total, height: total }}
    >
      {/* ── Frame border (absolute, fills entire container) ── */}
      <div
        className={cn('absolute inset-0 rounded-full', frameAnimClass)}
        style={{
          background: frame?.borderColor || 'transparent',
          boxShadow: frame?.glowColor || 'none',
          padding: fp,
        }}
      >
        {/* ── Avatar image/emoji (fills inside the frame) ── */}
        <div
          className="w-full h-full rounded-full flex items-center justify-center overflow-hidden relative"
          style={{ background: skin?.bgColor || 'oklch(0.30 0.04 250)' }}
        >
          {telegramAvatarUrl ? (
            <img
              src={telegramAvatarUrl}
              alt="Avatar"
              className="w-full h-full object-cover rounded-full"
              referrerPolicy="no-referrer"
            />
          ) : (
            <span className="leading-none drop-shadow-sm" style={{ fontSize: a * 0.5 }}>🧊</span>
          )}
        </div>
      </div>

      {/* ── Skin / Hat / Crown overlay (absolute, anchored to top of avatar) ── */}
      {skin && (
        <span
          className="absolute leading-none pointer-events-none z-10"
          style={{
            fontSize: skinFontSize,
            filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.6))',
            ...getSkinPosition(skin.overlayPosition, skinFontSize, a, fp),
          }}
        >
          {skin.emoji}
        </span>
      )}

      {/* ── Level badge (absolute, bottom-right of container) ── */}
      <div
        className={cn(
          'absolute rounded-full flex items-center justify-center font-bold z-20',
          prestigeLevel > 0
            ? 'bg-gold text-ice-deep'
            : 'bg-ice text-ice-deep',
        )}
        style={{
          width: badgeSize,
          height: badgeSize,
          fontSize: badgeFontSize,
          bottom: -1,
          right: -1,
        }}
      >
        {playerLevel}
      </div>
    </div>
  );
}

// ============================================================
// ChatAvatar — smaller avatar for chat messages (no level badge)
// ============================================================
export function ChatAvatar({
  avatarUrl,
  skinId,
  frameId,
  size = 'sm',
}: {
  avatarUrl: string | null;
  skinId: string;
  frameId: string | null;
  size?: 'sm' | 'md';
}) {
  const skin = getProfileSkinById(skinId);
  const frame = frameId ? getProfileFrameById(frameId) : null;

  const a = CHAT_SIZES[size];
  const fp = CHAT_FRAME_PADDING;
  const total = a + fp * 2;
  const frameAnimClass = frame ? getFrameAnimationClass(frame.rarity) : '';

  // Skin overlay size scales with avatar
  const skinFontSize = a * 0.4 * (skin?.overlayScale ?? 1);

  return (
    <div
      className="relative flex-shrink-0"
      style={{ width: total, height: total }}
    >
      {/* ── Frame border ── */}
      <div
        className={cn('absolute inset-0 rounded-full', frameAnimClass)}
        style={{
          background: frame?.borderColor || 'transparent',
          boxShadow: frame?.glowColor || 'none',
          padding: fp,
        }}
      >
        {/* ── Avatar ── */}
        <div
          className="w-full h-full rounded-full flex items-center justify-center overflow-hidden"
          style={{ background: skin?.bgColor || 'oklch(0.30 0.04 250)' }}
        >
          {avatarUrl ? (
            <img
              src={avatarUrl}
              alt=""
              className="w-full h-full object-cover rounded-full"
              referrerPolicy="no-referrer"
            />
          ) : (
            <span className="leading-none" style={{ fontSize: a * 0.45 }}>🧊</span>
          )}
        </div>
      </div>

      {/* ── Skin / Hat overlay ── */}
      {skin && (
        <span
          className="absolute leading-none pointer-events-none z-10"
          style={{
            fontSize: skinFontSize,
            filter: 'drop-shadow(0 1px 3px rgba(0,0,0,0.5))',
            ...getSkinPosition(skin.overlayPosition, skinFontSize, a, fp),
          }}
        >
          {skin.emoji}
        </span>
      )}
    </div>
  );
}

// ============================================================
// Unified skin/hat positioning — only relative to avatar size
// ============================================================
function getSkinPosition(
  position: 'top' | 'top-right' | 'center',
  fontSize: number,
  avatarSize: number,
  framePadding: number,
): React.CSSProperties {
  // The avatar circle starts at (framePadding, framePadding) within the container
  // and has diameter = avatarSize
  const avatarTop = framePadding;
  const avatarLeft = framePadding;
  const avatarCenterX = avatarLeft + avatarSize / 2;
  const avatarCenterY = avatarTop + avatarSize / 2;

  switch (position) {
    case 'top':
      // Bottom of emoji sits on top edge of avatar
      return {
        left: avatarCenterX,
        top: avatarTop - fontSize * 0.15,
        transform: 'translateX(-50%)',
      };

    case 'top-right':
      // Sits on top-right of avatar
      return {
        right: framePadding - fontSize * 0.1,
        top: avatarTop - fontSize * 0.15,
      };

    case 'center':
      // Centered over the avatar
      return {
        left: avatarCenterX,
        top: avatarCenterY,
        transform: 'translate(-50%, -50%)',
      };
  }
}

// ============================================================
// Frame glow animation class
// ============================================================
function getFrameAnimationClass(rarity: Rarity): string {
  switch (rarity) {
    case 'legendary':
      return 'frame-glow-legendary';
    case 'mythic':
      return 'frame-glow-mythic';
    case 'ancient':
      return 'frame-glow-ancient';
    default:
      return '';
  }
}
