'use client';

import { useState } from 'react';
import { useGameStore } from '@/lib/game-store';
import { formatNumber } from '@/lib/format';
import { Crown, TrendingUp, Settings } from 'lucide-react';
import { ProfileAvatar } from './profile-avatar';
import { ProfileModal } from './profile-modal';

export function TopBar() {
  const crystals = useGameStore((s) => s.crystals);
  const iceShards = useGameStore((s) => s.iceShards);
  const auroraEssence = useGameStore((s) => s.auroraEssence);
  const northCrowns = useGameStore((s) => s.northCrowns);
  const telegramStars = useGameStore((s) => s.telegramStars);
  const prestigeLevel = useGameStore((s) => s.prestigeLevel);
  const getIncomePerSecond = useGameStore((s) => s.getIncomePerSecond);
  const [showProfile, setShowProfile] = useState(false);

  const income = getIncomePerSecond();

  return (
    <>
      <header className="sticky top-0 z-30 glass safe-top">
        <div className="px-4 pt-3 pb-2.5 flex flex-col gap-2.5">
          {/* Top row: profile + brand + prestige */}
          <div className="flex items-center justify-between">
            <button
              onClick={() => setShowProfile(true)}
              className="flex items-center gap-2.5 active:scale-[0.97] transition-transform"
            >
              <ProfileAvatar size="sm" />
              <div className="flex flex-col leading-none">
                <span className="text-[13px] font-semibold tracking-[0.18em] uppercase text-frost-white">
                  Ice Empire
                </span>
                <span className="text-[9px] font-medium tracking-[0.25em] uppercase text-muted-fg mt-0.5">
                  Frozen Dynasty
                </span>
              </div>
            </button>

            <div className="flex items-center gap-1.5">
              {prestigeLevel > 0 && (
                <div className="flex items-center gap-1 px-2 py-1 rounded-md surface-sunken">
                  <Crown className="w-3 h-3 text-gold" strokeWidth={2} />
                  <span className="text-[11px] font-semibold text-gold tabular-nums">{prestigeLevel}</span>
                </div>
              )}
              <div className="flex items-center gap-1 px-2 py-1 rounded-md surface-sunken">
                <TrendingUp className="w-3 h-3 text-ice" strokeWidth={2} />
                <span className="text-[11px] font-semibold text-ice tabular-nums">
                  +{formatNumber(income)}
                </span>
                <span className="text-[10px] text-muted-fg">/s</span>
              </div>
            </div>
          </div>

          {/* Currency row */}
          <div className="flex items-center gap-1 overflow-x-auto scrollbar-thin -mx-1 px-1">
            <CurrencyChip icon="💎" value={crystals} tone="ice" />
            <CurrencyChip icon="❄" value={iceShards} tone="ice" />
            <CurrencyChip icon="✦" value={auroraEssence} tone="aurora" />
            <CurrencyChip icon="♛" value={northCrowns} tone="gold" />
            <CurrencyChip icon="★" value={telegramStars} tone="gold" />
          </div>
        </div>
      </header>

      <ProfileModal open={showProfile} onOpenChange={setShowProfile} />
    </>
  );
}

type Tone = 'ice' | 'aurora' | 'gold';

function CurrencyChip({ icon, value, tone }: { icon: string; value: number; tone: Tone }) {
  const toneClass = tone === 'ice' ? 'text-ice' : tone === 'aurora' ? 'text-aurora' : 'text-gold';
  return (
    <div className="flex-shrink-0 flex items-center gap-1.5 px-2.5 py-1 rounded-md surface-sunken">
      <span className={`text-[11px] ${toneClass} opacity-90`}>{icon}</span>
      <span className={`text-[12px] font-semibold tabular-nums ${toneClass}`}>{formatNumber(value)}</span>
    </div>
  );
}
