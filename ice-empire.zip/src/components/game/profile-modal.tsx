'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore } from '@/lib/game-store';
import {
  PROFILE_FRAMES,
  PROFILE_SKINS,
  RARITY_META,
  getProfileFrameById,
  getProfileSkinById,
  type ProfileFrame,
  type ProfileSkin,
} from '@/lib/game-data';
import { formatNumber } from '@/lib/format';
import { X, ChevronRight, Crown, Star, Zap, Trophy, Shield, Swords, TrendingUp, Clock, Palette, Frame } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ProfileAvatar } from './profile-avatar';

type ProfileTab = 'info' | 'frames' | 'skins';

export function ProfileModal({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const [tab, setTab] = useState<ProfileTab>('info');

  if (!open) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={() => onOpenChange(false)}
        className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-4"
      >
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 30, opacity: 0 }}
          transition={{ type: 'tween', duration: 0.2 }}
          onClick={(e) => e.stopPropagation()}
          className="w-full max-w-sm rounded-2xl glass-strong overflow-hidden max-h-[85vh] flex flex-col"
        >
          {/* Header */}
          <div className="p-4 flex items-center justify-between border-b border-white/5">
            <h2 className="text-[15px] font-semibold text-frost-white">Профиль</h2>
            <button
              onClick={() => onOpenChange(false)}
              className="w-7 h-7 rounded-md surface-sunken flex items-center justify-center text-muted-fg hover:text-frost-white"
            >
              <X className="w-3.5 h-3.5" strokeWidth={2} />
            </button>
          </div>

          {/* Avatar preview */}
          <div className="p-5 flex flex-col items-center">
            <ProfileAvatar size="lg" />
            <ProfileName />
          </div>

          {/* Tabs */}
          <div className="flex items-center gap-0.5 p-0.5 mx-4 rounded-lg surface-sunken">
            <ProfileTabButton active={tab === 'info'} onClick={() => setTab('info')} label="Инфо" />
            <ProfileTabButton active={tab === 'frames'} onClick={() => setTab('frames')} label="Рамки" />
            <ProfileTabButton active={tab === 'skins'} onClick={() => setTab('skins')} label="Скины" />
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto scrollbar-thin p-4">
            {tab === 'info' && <ProfileInfoTab />}
            {tab === 'frames' && <FramesTab />}
            {tab === 'skins' && <SkinsTab />}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

function ProfileTabButton({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'flex-1 py-2 rounded-md text-[11px] font-medium tracking-tight transition-all',
        active ? 'surface-elevated text-ice' : 'text-muted-fg hover:text-frost-white/80'
      )}
    >
      {label}
    </button>
  );
}

function ProfileName() {
  const playerName = useGameStore((s) => s.playerName);
  const setPlayerName = useGameStore((s) => s.setPlayerName);
  const telegramAvatarUrl = useGameStore((s) => s.telegramAvatarUrl);
  const [editing, setEditing] = useState(false);
  const [nameInput, setNameInput] = useState(playerName);

  const handleSave = () => {
    if (nameInput.trim().length >= 2) {
      setPlayerName(nameInput.trim());
    }
    setEditing(false);
  };

  return (
    <div className="mt-3 text-center">
      {editing ? (
        <div className="flex items-center gap-2">
          <input
            value={nameInput}
            onChange={(e) => setNameInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSave()}
            maxLength={20}
            autoFocus
            className="px-2 py-1 rounded-md surface-sunken text-[13px] text-frost-white text-center w-32 outline-none focus:ring-active"
          />
          <button onClick={handleSave} className="text-[10px] text-ice font-semibold">OK</button>
        </div>
      ) : (
        <button
          onClick={() => { setNameInput(playerName); setEditing(true); }}
          className="text-[14px] font-semibold text-frost-white hover:text-ice transition-colors"
        >
          {playerName}
        </button>
      )}
      {telegramAvatarUrl && (
        <p className="text-[9px] text-ice/60 mt-1 flex items-center justify-center gap-1">
          <Star className="w-2.5 h-2.5" strokeWidth={2} />
          Telegram аккаунт подключён
        </p>
      )}
    </div>
  );
}

function ProfileInfoTab() {
  const playerLevel = useGameStore((s) => s.playerLevel);
  const prestigeLevel = useGameStore((s) => s.prestigeLevel);
  const totalEarned = useGameStore((s) => s.totalEarned);
  const totalClicks = useGameStore((s) => s.totalClicks);
  const totalChestsOpened = useGameStore((s) => s.totalChestsOpened);
  const bossesDefeated = useGameStore((s) => s.bossesDefeated);
  const ownedFrames = useGameStore((s) => s.ownedFrames);
  const ownedSkins = useGameStore((s) => s.ownedSkins);
  const getIncomePerSecond = useGameStore((s) => s.getIncomePerSecond);
  const joinedAt = useGameStore((s) => s.joinedAt);

  const daysPlaying = Math.floor((Date.now() - joinedAt) / (24 * 3600 * 1000));
  const income = getIncomePerSecond();

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <StatBlock icon={<Zap className="w-3 h-3 text-ice" strokeWidth={2} />} label="Уровень" value={String(playerLevel)} />
        <StatBlock icon={<Crown className="w-3 h-3 text-gold" strokeWidth={2} />} label="Престиж" value={String(prestigeLevel)} />
        <StatBlock icon={<TrendingUp className="w-3 h-3 text-ice" strokeWidth={2} />} label="Доход/с" value={formatNumber(income)} />
        <StatBlock icon={<Trophy className="w-3 h-3 text-gold" strokeWidth={2} />} label="Боссы" value={String(bossesDefeated)} />
        <StatBlock icon={<Star className="w-3 h-3 text-amber-400" strokeWidth={2} />} label="Сундуки" value={String(totalChestsOpened)} />
        <StatBlock icon={<Clock className="w-3 h-3 text-ice" strokeWidth={2} />} label="Дней в игре" value={String(Math.max(1, daysPlaying))} />
      </div>

      <div className="surface rounded-xl p-3">
        <div className="flex items-center justify-between mb-1">
          <p className="text-[10px] text-muted-fg uppercase tracking-[0.15em]">Коллекция</p>
        </div>
        <div className="grid grid-cols-3 gap-2 mt-2">
          <div className="text-center">
            <p className="text-[12px] font-semibold text-ice tabular-nums">{ownedFrames.length}/{PROFILE_FRAMES.length}</p>
            <p className="text-[9px] text-muted-fg">Рамки</p>
          </div>
          <div className="text-center">
            <p className="text-[12px] font-semibold text-aurora tabular-nums">{ownedSkins.length}/{PROFILE_SKINS.length}</p>
            <p className="text-[9px] text-muted-fg">Скины</p>
          </div>
          <div className="text-center">
            <p className="text-[12px] font-semibold text-gold tabular-nums">{formatNumber(totalEarned)}</p>
            <p className="text-[9px] text-muted-fg">Всего 💎</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function StatBlock({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="surface rounded-lg p-2.5 text-center">
      <div className="flex items-center justify-center gap-1 mb-1">{icon}</div>
      <p className="text-[14px] font-semibold text-frost-white tabular-nums">{value}</p>
      <p className="text-[8px] text-muted-fg uppercase tracking-wider">{label}</p>
    </div>
  );
}

function FramesTab() {
  const ownedFrames = useGameStore((s) => s.ownedFrames);
  const selectedFrame = useGameStore((s) => s.selectedFrame);
  const setSelectedFrame = useGameStore((s) => s.setSelectedFrame);

  return (
    <div className="space-y-2">
      <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em] px-1">
        Рамки профиля · {ownedFrames.length}/{PROFILE_FRAMES.length}
      </p>

      {/* None option */}
      <button
        onClick={() => setSelectedFrame(null)}
        className={cn(
          'w-full surface rounded-lg p-3 flex items-center gap-3 text-left transition-all',
          !selectedFrame && 'ring-active'
        )}
      >
        <div className="w-10 h-10 rounded-full surface-sunken flex items-center justify-center text-lg">
          🧊
        </div>
        <div className="flex-1">
          <p className="text-[12px] font-medium text-frost-white">Без рамки</p>
          <p className="text-[9px] text-muted-fg">Стандартный аватар</p>
        </div>
        {!selectedFrame && <span className="text-[9px] text-ice font-semibold">Активно</span>}
      </button>

      {PROFILE_FRAMES.map((frame) => {
        const owned = ownedFrames.includes(frame.id);
        const isSelected = selectedFrame === frame.id;
        const rarityMeta = RARITY_META[frame.rarity];
        const isAnimated = ['legendary', 'mythic', 'ancient'].includes(frame.rarity);

        return (
          <button
            key={frame.id}
            onClick={() => owned && setSelectedFrame(isSelected ? null : frame.id)}
            disabled={!owned}
            className={cn(
              'w-full surface rounded-lg p-3 flex items-center gap-3 text-left transition-all',
              isSelected && 'ring-active',
              !owned && 'opacity-40'
            )}
          >
            <div
              className={cn(
                'w-10 h-10 rounded-full flex items-center justify-center text-lg flex-shrink-0',
                owned && isAnimated && `frame-glow-${frame.rarity}`
              )}
              style={{
                background: owned ? frame.borderColor : 'oklch(0.20 0.02 250)',
                boxShadow: owned ? frame.glowColor : 'none',
                padding: '2px',
                ...(isAnimated && owned ? { backgroundSize: '200% 200%' } : {}),
              }}
            >
              <div className="w-full h-full rounded-full surface-sunken flex items-center justify-center">
                {owned ? frame.emoji : '?'}
              </div>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <p className={cn('text-[12px] font-medium', owned ? 'text-frost-white' : 'text-muted-fg')}>
                  {owned ? frame.name : '???'}
                </p>
                <span className={cn('text-[8px] uppercase tracking-wider', rarityMeta.color)}>
                  {rarityMeta.label}
                </span>
                {owned && isAnimated && (
                  <span className="text-[7px] px-1 py-0.5 rounded bg-amber-500/10 text-amber-300 font-semibold">
                    СВЕТИТСЯ
                  </span>
                )}
              </div>
              <p className="text-[9px] text-muted-fg mt-0.5">{owned ? frame.description : 'Не открыто'}</p>
            </div>
            {isSelected && <span className="text-[9px] text-ice font-semibold">Активно</span>}
          </button>
        );
      })}
    </div>
  );
}

function SkinsTab() {
  const ownedSkins = useGameStore((s) => s.ownedSkins);
  const selectedSkin = useGameStore((s) => s.selectedSkin);
  const setSelectedSkin = useGameStore((s) => s.setSelectedSkin);
  const telegramAvatarUrl = useGameStore((s) => s.telegramAvatarUrl);

  return (
    <div className="space-y-2">
      <p className="text-[10px] text-muted-fg uppercase tracking-[0.2em] px-1">
        Скины на голову · {ownedSkins.length}/{PROFILE_SKINS.length}
      </p>

      {!telegramAvatarUrl && (
        <div className="surface rounded-lg p-2.5 flex items-center gap-2 border border-amber-500/20">
          <Star className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" strokeWidth={2} />
          <p className="text-[10px] text-amber-200/70">Открой через Telegram чтобы увидеть свою аватарку со скином</p>
        </div>
      )}

      {PROFILE_SKINS.map((skin) => {
        const owned = ownedSkins.includes(skin.id);
        const isSelected = selectedSkin === skin.id;
        const rarityMeta = RARITY_META[skin.rarity];

        return (
          <button
            key={skin.id}
            onClick={() => owned && setSelectedSkin(skin.id)}
            disabled={!owned}
            className={cn(
              'w-full surface rounded-lg p-3 flex items-center gap-3 text-left transition-all',
              isSelected && 'ring-active',
              !owned && 'opacity-40'
            )}
          >
            {/* Preview: mini avatar with skin overlay — same composition system as ProfileAvatar */}
            {(() => {
              const previewSize = 40; // px
              const skinFontSize = previewSize * 0.4 * (skin.overlayScale ?? 1);
              return (
                <div
                  className="relative flex-shrink-0"
                  style={{ width: previewSize, height: previewSize }}
                >
                  {/* Avatar circle */}
                  <div
                    className="absolute inset-0 rounded-full flex items-center justify-center overflow-hidden"
                    style={{ background: owned ? skin.bgColor : 'oklch(0.20 0.02 250)' }}
                  >
                    {owned ? (
                      telegramAvatarUrl ? (
                        <img
                          src={telegramAvatarUrl}
                          alt=""
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      ) : (
                        <span className="leading-none" style={{ fontSize: previewSize * 0.45 }}>🧊</span>
                      )
                    ) : (
                      <span className="leading-none text-sm">?</span>
                    )}
                  </div>
                  {/* Skin overlay — absolute, outside overflow-hidden */}
                  {owned && (
                    <span
                      className="absolute leading-none pointer-events-none z-10"
                      style={{
                        fontSize: skinFontSize,
                        filter: 'drop-shadow(0 1px 2px rgba(0,0,0,0.5))',
                        ...getSkinPreviewPosition(skin.overlayPosition, skinFontSize, previewSize),
                      }}
                    >
                      {skin.emoji}
                    </span>
                  )}
                </div>
              );
            })()}
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <p className={cn('text-[12px] font-medium', owned ? 'text-frost-white' : 'text-muted-fg')}>
                  {owned ? skin.name : '???'}
                </p>
                <span className={cn('text-[8px] uppercase tracking-wider', rarityMeta.color)}>
                  {rarityMeta.label}
                </span>
              </div>
              <p className="text-[9px] text-muted-fg mt-0.5">{owned ? skin.description : 'Не открыто'}</p>
            </div>
            {isSelected && <span className="text-[9px] text-ice font-semibold">Активно</span>}
          </button>
        );
      })}
    </div>
  );
}

// Unified skin positioning for preview cards (no frame padding)
function getSkinPreviewPosition(
  position: 'top' | 'top-right' | 'center',
  fontSize: number,
  avatarSize: number,
): React.CSSProperties {
  const cx = avatarSize / 2;
  const cy = avatarSize / 2;

  switch (position) {
    case 'top':
      return {
        left: cx,
        top: -fontSize * 0.15,
        transform: 'translateX(-50%)',
      };
    case 'top-right':
      return {
        right: -fontSize * 0.1,
        top: -fontSize * 0.15,
      };
    case 'center':
      return {
        left: cx,
        top: cy,
        transform: 'translate(-50%, -50%)',
      };
  }
}
