'use client';

import { Home, Users, Map, Swords, Gift, MessageCircle, Crown } from 'lucide-react';
import { cn } from '@/lib/utils';

export type ScreenId = 'home' | 'creatures' | 'map' | 'bosses' | 'shop' | 'chat' | 'season';

interface NavItem {
  id: ScreenId;
  label: string;
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'home', label: 'Империя', icon: Home },
  { id: 'creatures', label: 'Существа', icon: Users },
  { id: 'map', label: 'Карта', icon: Map },
  { id: 'bosses', label: 'Боссы', icon: Swords },
  { id: 'season', label: 'Сезон', icon: Crown },
  { id: 'shop', label: 'Магазин', icon: Gift },
  { id: 'chat', label: 'Чат', icon: MessageCircle },
];

interface BottomNavProps {
  active: ScreenId;
  onChange: (screen: ScreenId) => void;
}

export function BottomNav({ active, onChange }: BottomNavProps) {
  return (
    <nav className="sticky bottom-0 z-30 glass safe-bottom">
      <div className="flex items-center justify-around px-1 py-1.5">
        {NAV_ITEMS.map((item) => {
          const isActive = active === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onChange(item.id)}
              className={cn(
                'relative flex flex-col items-center gap-0.5 px-2.5 py-1 rounded-lg transition-colors duration-150 min-w-[48px]',
                isActive ? 'text-ice' : 'text-muted-fg hover:text-frost-white/70'
              )}
            >
              <Icon className="w-[16px] h-[16px]" strokeWidth={isActive ? 2 : 1.5} />
              <span className="text-[9px] font-medium tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
