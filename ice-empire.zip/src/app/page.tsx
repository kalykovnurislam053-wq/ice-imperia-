'use client';

import { useEffect, useState } from 'react';
import { useGameStore } from '@/lib/game-store';
import { TopBar } from '@/components/game/top-bar';
import { BottomNav, type ScreenId } from '@/components/game/bottom-nav';
import { SnowBackground } from '@/components/game/snow-background';
import { HomeScreen } from '@/components/game/screens/home-screen';
import { CreaturesScreen } from '@/components/game/screens/creatures-screen';
import { MapScreen } from '@/components/game/screens/map-screen';
import { BossesScreen } from '@/components/game/screens/bosses-screen';
import { ShopScreen } from '@/components/game/screens/shop-screen';
import { ChatScreen } from '@/components/game/screens/chat-screen';
import { SeasonPassScreen } from '@/components/game/screens/season-pass-screen';
import { Toaster } from 'sonner';

export default function Home() {
  const [screen, setScreen] = useState<ScreenId>('home');
  const tickIncome = useGameStore((s) => s.tickIncome);
  const collectOfflineIncome = useGameStore((s) => s.collectOfflineIncome);
  const setTelegramAvatar = useGameStore((s) => s.setTelegramAvatar);
  const setPlayerName = useGameStore((s) => s.setPlayerName);

  // Income tick — runs every second
  useEffect(() => {
    const offline = collectOfflineIncome();
    if (offline > 0 && offline > 100) {
      // could show a toast for offline earnings
    }

    const interval = setInterval(() => {
      tickIncome();
    }, 1000);
    return () => clearInterval(interval);
  }, [tickIncome, collectOfflineIncome]);

  // Initialize Telegram WebApp + Avatar
  useEffect(() => {
    if (typeof window !== 'undefined' && (window as any).Telegram?.WebApp) {
      const tg = (window as any).Telegram.WebApp;
      tg.ready();
      tg.expand();
      tg.setHeaderColor('#0a1628');
      tg.setBackgroundColor('#0a1628');

      // Get Telegram user data
      const user = tg.initDataUnsafe?.user;
      if (user) {
        // Set avatar URL from Telegram
        const avatarUrl = user.photo_url || null;
        const userId = user.id ? String(user.id) : null;
        setTelegramAvatar(avatarUrl, userId);

        // Set player name from Telegram
        if (user.first_name) {
          const displayName = user.last_name
            ? `${user.first_name} ${user.last_name}`
            : user.first_name;
          setPlayerName(displayName);
        }
      }
    }
  }, [setTelegramAvatar, setPlayerName]);

  return (
    <div className="min-h-screen flex flex-col relative">
      <SnowBackground />

      <div className="relative z-10 flex flex-col min-h-screen max-w-md mx-auto w-full">
        <TopBar />

        <main className="flex-1 overflow-y-auto scrollbar-thin">
          {screen === 'home' && <HomeScreen onNavigate={(s) => setScreen(s)} />}
          {screen === 'creatures' && <CreaturesScreen />}
          {screen === 'map' && <MapScreen />}
          {screen === 'bosses' && <BossesScreen />}
          {screen === 'shop' && <ShopScreen />}
          {screen === 'chat' && <ChatScreen />}
          {screen === 'season' && <SeasonPassScreen />}
        </main>

        <BottomNav active={screen} onChange={setScreen} />
      </div>

      <Toaster
        position="top-center"
        theme="dark"
        toastOptions={{
          style: {
            background: 'rgba(20, 30, 50, 0.9)',
            backdropFilter: 'blur(16px)',
            border: '1px solid rgba(125, 211, 252, 0.2)',
            color: '#e0f2fe',
          },
        }}
      />
    </div>
  );
}
