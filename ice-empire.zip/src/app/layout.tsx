import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin", "cyrillic"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const TelegramScript = () => (
  <script
    dangerouslySetInnerHTML={{
      __html: `
        if (typeof window !== 'undefined') {
          var s = document.createElement('script');
          s.src = 'https://telegram.org/js/telegram-web-app.js';
          s.async = true;
          document.head.appendChild(s);
        }
      `,
    }}
  />
);

export const metadata: Metadata = {
  title: "Ice Empire: Frozen Dynasty",
  description: "Ледяная империя ждет своего повелителя. Собирай существ, покоряй Север и стань Королём Льда!",
  keywords: ["Ice Empire", "Frozen Dynasty", "Telegram game", "mini app", "idle", "коллекция"],
  authors: [{ name: "Ice Empire" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "Ice Empire: Frozen Dynasty",
    description: "Ледяная империя ждет своего повелителя",
    type: "website",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#0a1628",
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ru" suppressHydrationWarning className="dark">
      <head>
        <TelegramScript />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
