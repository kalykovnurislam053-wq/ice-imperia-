// ===== ICE EMPIRE: FROZEN DYNASTY — Game Data =====

export type Rarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary' | 'mythic' | 'ancient';

export interface Creature {
  id: string;
  name: string;
  emoji: string;
  rarity: Rarity;
  baseIncome: number; // crystals per second
  baseCost: number;
  skill: string;
  skillDescription: string;
  description: string;
}

export interface Location {
  id: string;
  name: string;
  emoji: string;
  description: string;
  unlockCost: number;
  incomeMultiplier: number;
  bgColor: string;
  auroraDrop: number; // % chance
}

export interface Boss {
  id: string;
  name: string;
  emoji: string;
  maxHp: number;
  reward: number;
  auroraEssence: number;
  artifactChance: number;
  description: string;
  duration: number; // hours available
  requiredCreatures?: RequiredCreature[];
  mechanic?: BossMechanic;
}

export interface RequiredCreature {
  rarity: Rarity;
  minCount: number;
}

export interface BossMechanic {
  id: string;
  name: string;
  description: string;
  damageReduction?: number; // % reduction to player damage
  reflectDamage?: number; // % reflected
  immuneInterval?: number; // seconds of immunity every X seconds
  drainPerSecond?: number; // % HP drained from player's total income per second
  phases?: number; // number of phases (HP thresholds)
}

export interface Artifact {
  id: string;
  name: string;
  emoji: string;
  set: string;
  rarity: Rarity;
  bonus: string;
  bonusValue: number;
  bonusType: 'income' | 'luck' | 'speed' | 'damage' | 'prestige';
  description: string;
}

export interface Chest {
  id: string;
  name: string;
  emoji: string;
  baseCost: number;
  currency: 'crystals' | 'stars';
  rarityDrops: Record<Rarity, number>;
  description: string;
  gradient: string;
  priceMultiplier: number; // how much price increases per purchase
  frameDropChance?: number; // % chance to drop a profile frame instead of creature
  itemCount: number; // how many items drop per opening
  isDonate: boolean; // donate chests have boosted rarity
}

export interface DailyReward {
  day: number;
  type: 'crystals' | 'creature' | 'chest' | 'shards';
  amount: number;
  label: string;
  rarity?: Rarity;
}

export interface DonatePack {
  id: string;
  stars: number;
  crystals: number;
  bonus: string;
  popular?: boolean;
}

export interface ClanLevel {
  level: number;
  requiredTreasury: number;
  clickBonus: number; // % increase to tap damage
  autoMineBonus: number; // % increase to auto income
  memberLimit: number;
  title: string;
}

// ===== Profile Frame System =====
export interface ProfileFrame {
  id: string;
  name: string;
  emoji: string;
  rarity: Rarity;
  borderColor: string; // CSS gradient or color
  glowColor: string; // box-shadow color
  description: string;
}

export interface ProfileSkin {
  id: string;
  name: string;
  emoji: string; // overlay emoji on top of avatar head
  rarity: Rarity;
  bgColor: string; // background color for avatar (fallback if no TG photo)
  description: string;
  overlayPosition: 'top' | 'top-right' | 'center'; // where overlay appears on avatar
  overlayScale: number; // scale factor for overlay emoji (1.0 = normal)
}

// Drop type from chests — can be creature OR profile frame
export type ChestDropType = 'creature' | 'frame';

export interface ChestReward {
  type: ChestDropType;
  rarity: Rarity;
  creature?: Creature;
  frame?: ProfileFrame;
  isDuplicate: boolean;
  shardReward?: number;
}

// ===== Rarity metadata =====
export const RARITY_META: Record<Rarity, { label: string; color: string; glow: string; order: number }> = {
  common: { label: 'Common', color: 'text-slate-400', glow: 'rarity-glow-common', order: 1 },
  uncommon: { label: 'Uncommon', color: 'text-emerald-400', glow: 'rarity-glow-uncommon', order: 2 },
  rare: { label: 'Rare', color: 'text-sky-400', glow: 'rarity-glow-rare', order: 3 },
  epic: { label: 'Epic', color: 'text-purple-400', glow: 'rarity-glow-epic', order: 4 },
  legendary: { label: 'Legendary', color: 'text-amber-400', glow: 'rarity-glow-legendary', order: 5 },
  mythic: { label: 'Mythic', color: 'text-pink-400', glow: 'rarity-glow-mythic', order: 6 },
  ancient: { label: 'Ancient', color: 'text-cyan-300', glow: 'rarity-glow-ancient', order: 7 },
};

// ===== 61 Creatures across 7 rarity tiers =====
export const CREATURES: Creature[] = [
  // ===== Common (10) =====
  { id: 'c1', name: 'Пингвин-шахтёр', emoji: '🐧', rarity: 'common', baseIncome: 1, baseCost: 50, skill: 'Копь', skillDescription: 'Добывает +5% к базовому доходу', description: 'Трудолюбивый житель ледяных шахт. Никогда не устаёт.' },
  { id: 'c2', name: 'Полярная лиса', emoji: '🦊', rarity: 'common', baseIncome: 2, baseCost: 120, skill: 'Хитрость', skillDescription: '+10% к удаче находки существ', description: 'Её белый мех идеально маскирует в снегах.' },
  { id: 'c3', name: 'Снежный заяц', emoji: '🐇', rarity: 'common', baseIncome: 1.5, baseCost: 80, skill: 'Прыгучесть', skillDescription: '+8% к скорости экспедиций', description: 'Самый быстрый зверёк в долине.' },
  { id: 'c4', name: 'Лемминг', emoji: '🐹', rarity: 'common', baseIncome: 1, baseCost: 40, skill: 'Стойкость', skillDescription: '+3% к доходу за каждого лемминга', description: 'Маленький, но очень упорный.' },
  { id: 'c5', name: 'Снежная куропатка', emoji: '🐦', rarity: 'common', baseIncome: 1.8, baseCost: 100, skill: 'Зоркость', skillDescription: '+5% к шансу артефакта', description: 'Видит добычу сквозь метель.' },
  { id: 'c6', name: 'Песец белый', emoji: '🦝', rarity: 'common', baseIncome: 2.2, baseCost: 150, skill: 'Ловкость', skillDescription: '+7% к скорости добычи', description: 'Мастер охоты в зимнюю ночь.' },
  { id: 'c31', name: 'Снеговик-страж', emoji: '⛄', rarity: 'common', baseIncome: 1.3, baseCost: 60, skill: 'Защита', skillDescription: '+4% к защите в рейдах', description: 'Стоит на посту даже в самый лютый мороз.' },
  { id: 'c32', name: 'Ледяной жук', emoji: '🪲', rarity: 'common', baseIncome: 0.8, baseCost: 30, skill: 'Упорство', skillDescription: '+2% к доходу за каждого жука', description: 'Копает лёд день и ночь без устали.' },
  { id: 'c33', name: 'Морской котик', emoji: '🦭', rarity: 'common', baseIncome: 1.6, baseCost: 90, skill: 'Ныряние', skillDescription: '+6% к находке осколков', description: 'Ловит рыбу в прорубях.' },
  { id: 'c34', name: 'Снежная мышь', emoji: '🐭', rarity: 'common', baseIncome: 0.9, baseCost: 35, skill: 'Пронырливость', skillDescription: '+3% к удаче', description: 'Пробирается в любые щели во льдах.' },

  // ===== Uncommon (10) =====
  { id: 'c7', name: 'Снежная сова', emoji: '🦉', rarity: 'uncommon', baseIncome: 5, baseCost: 500, skill: 'Ночное зрение', skillDescription: '+15% к доходу ночью', description: 'Безмолвный страж ледяных ночей.' },
  { id: 'c8', name: 'Тюлень-ныряльщик', emoji: '🐋', rarity: 'uncommon', baseIncome: 4, baseCost: 400, skill: 'Глубокое ныряние', skillDescription: '+12% к находке осколков', description: 'Добывает сокровища со дна океана.' },
  { id: 'c9', name: 'Морж', emoji: '🐘', rarity: 'uncommon', baseIncome: 6, baseCost: 700, skill: 'Мощь', skillDescription: '+20% к урону по боссам', description: 'Его бивни пробивают лёд толщиной в метр.' },
  { id: 'c10', name: 'Полярный гусь', emoji: '🦢', rarity: 'uncommon', baseIncome: 4.5, baseCost: 450, skill: 'Перелёт', skillDescription: '+10% к скорости экспедиций', description: 'Знает все тайные тропы Севера.' },
  { id: 'c11', name: 'Горностай', emoji: '🦔', rarity: 'uncommon', baseIncome: 5.5, baseCost: 600, skill: 'Невидимость', skillDescription: '+18% к удаче', description: 'Меняет шубку, но не характер.' },
  { id: 'c12', name: 'Снежный баран', emoji: '🐑', rarity: 'uncommon', baseIncome: 5, baseCost: 550, skill: 'Упорство', skillDescription: '+15% к доходу на склонах', description: 'Топчет тропы в самых высоких горах.' },
  { id: 'c35', name: 'Ледяная рысь', emoji: '🐱', rarity: 'uncommon', baseIncome: 5.8, baseCost: 650, skill: 'Резкость', skillDescription: '+22% к критическому урону', description: 'Нападает из засницы беззвучно.' },
  { id: 'c36', name: 'Морозный скунс', emoji: '🦨', rarity: 'uncommon', baseIncome: 4.2, baseCost: 420, skill: 'Защитный аромат', skillDescription: '+10% к защите клана', description: 'Его запах отпугивает даже боссов.' },
  { id: 'c37', name: 'Ледяной дятел', emoji: '🪶', rarity: 'uncommon', baseIncome: 4.8, baseCost: 480, skill: 'Долбление', skillDescription: '+14% к скорости добычи', description: 'Долбит лёд с невероятной скоростью.' },
  { id: 'c38', name: 'Северная норка', emoji: '🦦', rarity: 'uncommon', baseIncome: 5.2, baseCost: 520, skill: 'Мастерство', skillDescription: '+16% к доходу в воде', description: 'Грация в ледяных реках.' },

  // ===== Rare (11) =====
  { id: 'c13', name: 'Белый медведь', emoji: '🐻', rarity: 'rare', baseIncome: 15, baseCost: 2500, skill: 'Власть Севера', skillDescription: '+30% к доходу в ледяных локациях', description: 'Величественный хозяин арктических земель.' },
  { id: 'c14', name: 'Ледяной волк', emoji: '🐺', rarity: 'rare', baseIncome: 18, baseCost: 3000, skill: 'Стая', skillDescription: '+5% за каждого волка в коллекции', description: 'Его вой слышен за десять вёрст.' },
  { id: 'c15', name: 'Северный олень', emoji: '🦌', rarity: 'rare', baseIncome: 16, baseCost: 2800, skill: 'Северное сияние', skillDescription: '+25% к шансу Эссенции Авроры', description: 'Бежит за горизонт, за ним сияние.' },
  { id: 'c16', name: 'Ледяной орёл', emoji: '🦅', rarity: 'rare', baseIncome: 20, baseCost: 3500, skill: 'Божий глаз', skillDescription: '+35% к удаче находки', description: 'Видит добычу с высоты километра.' },
  { id: 'c17', name: 'Полярный медвежонок', emoji: '🐨', rarity: 'rare', baseIncome: 14, baseCost: 2200, skill: 'Обаяние', skillDescription: '+20% к наградам боссов', description: 'Таких не бросают в беде.' },
  { id: 'c18', name: 'Снежный барс', emoji: '🐆', rarity: 'rare', baseIncome: 22, baseCost: 4000, skill: 'Скрытность', skillDescription: '+40% к критическому урону', description: 'Призрак гор, которого видели единицы.' },
  { id: 'c39', name: 'Ледяной кит', emoji: '🐳', rarity: 'rare', baseIncome: 25, baseCost: 4500, skill: 'Песнь глубин', skillDescription: '+28% к доходу в океане', description: 'Его голос будит ледники изнутри.' },
  { id: 'c40', name: 'Морозный ворон', emoji: '🪶', rarity: 'rare', baseIncome: 17, baseCost: 2900, skill: 'Вещий ворон', skillDescription: '+30% к шансу артефакта', description: 'Видит будущее в узорах льда.' },
  { id: 'c41', name: 'Ледяная выдра', emoji: '🦦', rarity: 'rare', baseIncome: 19, baseCost: 3200, skill: 'Ловкость рук', skillDescription: '+22% к скорости добычи', description: 'Извлекает жемчуг из-под толщи льда.' },
  { id: 'c42', name: 'Снежный манул', emoji: '😻', rarity: 'rare', baseIncome: 16.5, baseCost: 2700, skill: 'Невозмутимость', skillDescription: '+18% к доходу в горах', description: 'Самый пушистый и самый опасный.' },
  { id: 'c43', name: 'Ледяной сокол', emoji: '🦅', rarity: 'rare', baseIncome: 23, baseCost: 4200, skill: 'Пике', skillDescription: '+45% к урону первой атаки по боссу', description: 'Пикирует со скоростью метели.' },

  // ===== Epic (10) =====
  { id: 'c19', name: 'Ледяной дух', emoji: '👻', rarity: 'epic', baseIncome: 50, baseCost: 12000, skill: 'Морозное прикосновение', skillDescription: '+50% к доходу, замораживает время', description: 'Древняя душа, заточённая во льдах тысячелетия назад.' },
  { id: 'c20', name: 'Хранитель Севера', emoji: '🧙', rarity: 'epic', baseIncome: 60, baseCost: 15000, skill: 'Древние знания', skillDescription: '+60% к доходу всех существ', description: 'Знает секреты забытой цивилизации льда.' },
  { id: 'c21', name: 'Ледяной голем', emoji: '🗿', rarity: 'epic', baseIncome: 55, baseCost: 14000, skill: 'Несокрушимость', skillDescription: '+80% к HP клана в рейдах', description: 'Сложен из вечной мерзлоты.' },
  { id: 'c22', name: 'Морозная ведьма', emoji: '🧝‍♀️', rarity: 'epic', baseIncome: 65, baseCost: 16000, skill: 'Зимнее проклятие', skillDescription: '+45% к урону по боссам', description: 'Умеет замораживать самих богов.' },
  { id: 'c23', name: 'Ледяной феникс', emoji: '🔥', rarity: 'epic', baseIncome: 70, baseCost: 18000, skill: 'Возрождение', skillDescription: 'Восстанавливает 50% дохода после престижа', description: 'Сгорает и рождается заново из снега.' },
  { id: 'c44', name: 'Морозный рыцарь', emoji: '⚔️', rarity: 'epic', baseIncome: 58, baseCost: 14500, skill: 'Ледяной клинок', skillDescription: '+55% к урону по боссам, замораживает', description: 'Воин, чей меч выкован из вечного льда.' },
  { id: 'c45', name: 'Снежная колдунья', emoji: '🪄', rarity: 'epic', baseIncome: 62, baseCost: 15500, skill: 'Метель', skillDescription: '+40% к скорости добычи всех', description: 'Призывет метель по щелчку пальцев.' },
  { id: 'c46', name: 'Ледяной мантикора', emoji: '🦂', rarity: 'epic', baseIncome: 68, baseCost: 17000, skill: 'Яд мороза', skillDescription: '+35% к урону, замедляет боссов', description: 'Хвост из сосулек с ядом холода.' },
  { id: 'c47', name: 'Храмовник Льда', emoji: '🛡️', rarity: 'epic', baseIncome: 52, baseCost: 13000, skill: 'Святой лёд', skillDescription: '+70% к защите клана', description: 'Защищает слабых силой веры и мороза.' },
  { id: 'c48', name: 'Ледяной некромант', emoji: '💀', rarity: 'epic', baseIncome: 72, baseCost: 19000, skill: 'Воскрешение', skillDescription: '+30% к доходу за каждое мёртвое существо', description: 'Поднимает павших для работы в шахтах.' },

  // ===== Legendary (9) =====
  { id: 'c24', name: 'Дракон Морозных Пиков', emoji: '🐉', rarity: 'legendary', baseIncome: 200, baseCost: 60000, skill: 'Дыхание зимы', skillDescription: '+150% к доходу, шанс заморозить босса', description: 'Его крылья вызывают метель на целом континенте.' },
  { id: 'c25', name: 'Йети', emoji: '🦍', rarity: 'legendary', baseIncome: 180, baseCost: 55000, skill: 'Сила гор', skillDescription: '+200% к урону по боссам', description: 'Легенда, которую все видели, но никто не поймал.' },
  { id: 'c26', name: 'Кракен ледяных глубин', emoji: '🐙', rarity: 'legendary', baseIncome: 220, baseCost: 65000, skill: 'Щупальца бури', skillDescription: '+120% к доходу в океане', description: 'Пробуждается раз в сто лет.' },
  { id: 'c27', name: 'Единорог Авроры', emoji: '🦄', rarity: 'legendary', baseIncome: 250, baseCost: 75000, skill: 'Свет полярного неба', skillDescription: '+100% к шансу Эссенции Авроры', description: 'Рог светится северным сиянием.' },
  { id: 'c49', name: 'Ледяной василиск', emoji: '🐍', rarity: 'legendary', baseIncome: 230, baseCost: 70000, skill: 'Взгляд вечности', skillDescription: '+180% к урону, шанс окаменить босса', description: 'Один взгляд — и враг превращается в ледяную статую.' },
  { id: 'c50', name: 'Снежная грифон', emoji: '🦅', rarity: 'legendary', baseIncome: 210, baseCost: 63000, skill: 'Воздушная атака', skillDescription: '+160% к доходу, +90% к скорости', description: 'Царь небес ледяных пустошей.' },
  { id: 'c51', name: 'Морозный Leviathan', emoji: '🐋', rarity: 'legendary', baseIncome: 260, baseCost: 80000, skill: 'Глубинный холод', skillDescription: '+200% к доходу в океане, замораживает время', description: 'Древнее существо со дна замёрзшего моря.' },
  { id: 'c52', name: 'Ледяной химера', emoji: '🦁', rarity: 'legendary', baseIncome: 240, baseCost: 72000, skill: 'Тройная суть', skillDescription: '+100% к доходу, +100% к урону, +100% к удаче', description: 'Три головы — три силы в одном теле.' },
  { id: 'c53', name: 'Властелин Вьюги', emoji: '🌪️', rarity: 'legendary', baseIncome: 280, baseCost: 85000, skill: 'Вьюга столетия', skillDescription: '+220% к доходу, замедляет всех врагов', description: 'Контролирует саму суть зимних бурь.' },

  // ===== Mythic (7) =====
  { id: 'c28', name: 'Король Льда', emoji: '👑', rarity: 'mythic', baseIncome: 800, baseCost: 250000, skill: 'Корона вечной зимы', skillDescription: '+300% к доходу всех существ', description: 'Тот, кто правит каждым снегопадом.' },
  { id: 'c29', name: 'Богиня Зимы', emoji: '👸', rarity: 'mythic', baseIncome: 900, baseCost: 300000, skill: 'Вечная мерзлота', skillDescription: '+500% к доходу, x2 к престижу', description: 'Сама зима приняла её облик.' },
  { id: 'c54', name: 'Архимаг Мороза', emoji: '🧙‍♂️', rarity: 'mythic', baseIncome: 1000, baseCost: 400000, skill: 'Абсолютный нуль', skillDescription: '+400% к доходу, замораживает время на 10с', description: 'Маг, постигший температуру пустоты.' },
  { id: 'c55', name: 'Ледяной титан', emoji: '🗿', rarity: 'mythic', baseIncome: 1100, baseCost: 500000, skill: 'Сотрясение', skillDescription: '+600% к урону по боссам, разрушает щиты', description: 'Каждый шаг создаёт трещины во льдах.' },
  { id: 'c56', name: 'Принц Авроры', emoji: '✨', rarity: 'mythic', baseIncome: 950, baseCost: 350000, skill: 'Сияние', skillDescription: '+350% к доходу, +200% к удаче', description: 'Рождён из первого северного сияния.' },
  { id: 'c57', name: 'Ледяной жнец', emoji: '⚰️', rarity: 'mythic', baseIncome: 1200, baseCost: 600000, skill: 'Урожай душ', skillDescription: '+450% к доходу, конвертирует врагов в ресурс', description: 'Собирает души замёрзших воинов.' },
  { id: 'c58', name: 'Вечный странник', emoji: '🚶', rarity: 'mythic', baseIncome: 1050, baseCost: 450000, skill: 'Бесконечный путь', skillDescription: '+380% к доходу, +150% к скорости', description: 'Ходит по льдам с начала времён.' },

  // ===== Ancient (4) =====
  { id: 'c30', name: 'Древний Император Льда', emoji: '🧊', rarity: 'ancient', baseIncome: 5000, baseCost: 2000000, skill: 'Начало и конец зимы', skillDescription: '+1000% к доходу, открывает Древнюю локацию', description: 'Первое существо, увидевшее снег этого мира.' },
  { id: 'c59', name: 'Первозданный Глас', emoji: '🔊', rarity: 'ancient', baseIncome: 6000, baseCost: 3000000, skill: 'Слово творения', skillDescription: '+1500% к доходу, удваивает всех существ', description: 'Произнёс «Зима» — и мир замёрз навеки.' },
  { id: 'c60', name: 'Абсолютный Нуль', emoji: '🌡️', rarity: 'ancient', baseIncome: 7000, baseCost: 5000000, skill: 'Температура пустоты', skillDescription: '+2000% к доходу, останавливает время', description: 'Точка, где холод становится вечностью.' },
  { id: 'c61', name: 'Снежный Прародитель', emoji: '❄️', rarity: 'ancient', baseIncome: 8000, baseCost: 8000000, skill: 'Первая снежинка', skillDescription: '+3000% к доходу, создает новых существ', description: 'От него произошёл каждый снегопад во вселенной.' },
];

// ===== 6 World locations =====
export const LOCATIONS: Location[] = [
  {
    id: 'l1',
    name: 'Ледяная долина',
    emoji: '❄️',
    description: 'Стартовая локация. Равнины вечного снега.',
    unlockCost: 0,
    incomeMultiplier: 1.0,
    bgColor: 'from-sky-900/40 to-blue-950/40',
    auroraDrop: 0.5,
  },
  {
    id: 'l2',
    name: 'Древний ледник',
    emoji: '🏔️',
    description: 'Ледник возрастом в миллион лет. Скрывает древние тайны.',
    unlockCost: 5000,
    incomeMultiplier: 1.3,
    bgColor: 'from-cyan-900/40 to-sky-950/40',
    auroraDrop: 1.0,
  },
  {
    id: 'l3',
    name: 'Аврора',
    emoji: '🌌',
    description: 'Место, где полярное сияние сходит к земле.',
    unlockCost: 50000,
    incomeMultiplier: 1.8,
    bgColor: 'from-purple-900/40 to-indigo-950/40',
    auroraDrop: 5.0,
  },
  {
    id: 'l4',
    name: 'Замёрзший океан',
    emoji: '🌊',
    description: 'Бескрайние льды над древним океаном.',
    unlockCost: 250000,
    incomeMultiplier: 2.5,
    bgColor: 'from-blue-900/40 to-cyan-950/40',
    auroraDrop: 3.0,
  },
  {
    id: 'l5',
    name: 'Ледяной вулкан',
    emoji: '🌋',
    description: 'Извергает лёд вместо лавы. Загадка природы.',
    unlockCost: 1000000,
    incomeMultiplier: 3.5,
    bgColor: 'from-indigo-900/40 to-purple-950/40',
    auroraDrop: 8.0,
  },
  {
    id: 'l6',
    name: 'Трон Вечного Мороза',
    emoji: '👑',
    description: 'Финальная локация. Трон самого Императора Льда.',
    unlockCost: 5000000,
    incomeMultiplier: 5.0,
    bgColor: 'from-amber-900/40 to-yellow-950/40',
    auroraDrop: 15.0,
  },
];

// ===== 9 Bosses =====
export const BOSSES: Boss[] = [
  {
    id: 'b1',
    name: 'Король Медведей',
    emoji: '🐻‍❄️',
    maxHp: 50000,
    reward: 5000,
    auroraEssence: 5,
    artifactChance: 15,
    description: 'Гигантский белый медведь, вождь всех медведей Севера.',
    duration: 4,
  },
  {
    id: 'b2',
    name: 'Древний Дух Льда',
    emoji: '👻',
    maxHp: 200000,
    reward: 25000,
    auroraEssence: 20,
    artifactChance: 25,
    description: 'Дух замёрзшей тысячи лет назад цивилизации.',
    duration: 6,
  },
  {
    id: 'b3',
    name: 'Северный Дракон',
    emoji: '🐲',
    maxHp: 1000000,
    reward: 150000,
    auroraEssence: 50,
    artifactChance: 40,
    description: 'Дракон, чьё дыхание вызывает метель на целом континенте.',
    duration: 8,
  },
  {
    id: 'b4',
    name: 'Император Мороза',
    emoji: '🧊',
    maxHp: 5000000,
    reward: 1000000,
    auroraEssence: 200,
    artifactChance: 75,
    description: 'Воплощение самой зимы. Появляется раз в месяц.',
    duration: 12,
  },
  {
    id: 'b5',
    name: 'Ледяной Титан',
    emoji: '🗿',
    maxHp: 15000000,
    reward: 3000000,
    auroraEssence: 400,
    artifactChance: 50,
    description: 'Колосс из чистого льда. Его шаги вызывают землетрясения.',
    duration: 10,
    requiredCreatures: [{ rarity: 'epic', minCount: 3 }],
    mechanic: {
      id: 'ice_armor',
      name: 'Ледяная броня',
      description: 'Уменьшает входящий урон на 50%, если у тебя нет ледяных существ',
      damageReduction: 50,
    },
  },
  {
    id: 'b6',
    name: 'Хранитель Вечности',
    emoji: '⏳',
    maxHp: 30000000,
    reward: 6000000,
    auroraEssence: 800,
    artifactChance: 60,
    description: 'Существо вне времени. Замораживает время каждые 10 секунд.',
    duration: 12,
    requiredCreatures: [{ rarity: 'legendary', minCount: 2 }],
    mechanic: {
      id: 'time_freeze',
      name: 'Заморозка времени',
      description: 'Становится неуязвимым на 3 секунды каждые 10 секунд',
      immuneInterval: 10,
    },
  },
  {
    id: 'b7',
    name: 'Бездна Мороза',
    emoji: '🕳️',
    maxHp: 60000000,
    reward: 12000000,
    auroraEssence: 1500,
    artifactChance: 65,
    description: 'Бездна, которая поглощает тепло и жизнь. Древнее зло.',
    duration: 14,
    requiredCreatures: [{ rarity: 'mythic', minCount: 1 }],
    mechanic: {
      id: 'life_drain',
      name: 'Поглощение жизни',
      description: 'Вытягивает 1% от твоего дохода в секунду',
      drainPerSecond: 1,
    },
  },
  {
    id: 'b8',
    name: 'Королева Авроры',
    emoji: '👑',
    maxHp: 100000000,
    reward: 25000000,
    auroraEssence: 3000,
    artifactChance: 70,
    description: 'Повелительница северного сияния. Отражает удары обратно.',
    duration: 16,
    requiredCreatures: [{ rarity: 'rare', minCount: 5 }],
    mechanic: {
      id: 'aurora_reflect',
      name: 'Отражение Авроры',
      description: 'Отражает 20% нанесённого урона обратно',
      reflectDamage: 20,
    },
  },
  {
    id: 'b9',
    name: 'Тёмный Император',
    emoji: '🌑',
    maxHp: 200000000,
    reward: 50000000,
    auroraEssence: 6000,
    artifactChance: 85,
    description: 'Истинный владыка льдов. Сражается в двух фазах, требует величайших воинов.',
    duration: 20,
    requiredCreatures: [
      { rarity: 'mythic', minCount: 2 },
      { rarity: 'legendary', minCount: 3 },
    ],
    mechanic: {
      id: 'dark_phases',
      name: 'Тёмные фазы',
      description: 'При 50% HP переходит во вторую фазу: урон x2, скорость атаки x3',
      phases: 2,
    },
  },
  {
    id: 'b10',
    name: 'Ледяной Феникс',
    emoji: '🔥',
    maxHp: 350000000,
    reward: 80000000,
    auroraEssence: 10000,
    artifactChance: 80,
    description: 'Возрождается из пепла метели. Каждое возрождение сильнее предыдущего.',
    duration: 18,
    requiredCreatures: [
      { rarity: 'legendary', minCount: 4 },
    ],
    mechanic: {
      id: 'resurrection',
      name: 'Возрождение',
      description: 'При 0 HP возрождается с 30% здоровья. Может возродиться до 2 раз. Каждый раз — урон x1.5',
      phases: 3,
    },
  },
  {
    id: 'b11',
    name: 'Хранитель Рун',
    emoji: '🪨',
    maxHp: 500000000,
    reward: 120000000,
    auroraEssence: 15000,
    artifactChance: 75,
    description: 'Древний великан, защищающий руны забытой цивилизации. Руны дают ему силу.',
    duration: 22,
    requiredCreatures: [
      { rarity: 'epic', minCount: 5 },
      { rarity: 'mythic', minCount: 1 },
    ],
    mechanic: {
      id: 'rune_shield',
      name: 'Рунический щит',
      description: 'Поглощает 70% урона, пока не получит 1000 ударов. После разрушения щита — уязвим 10 секунд',
      damageReduction: 70,
    },
  },
  {
    id: 'b12',
    name: 'Королева Метелей',
    emoji: '🌨️',
    maxHp: 750000000,
    reward: 180000000,
    auroraEssence: 20000,
    artifactChance: 85,
    description: 'Повелительница всех метелей. Замораживает атакующих и отражает урон.',
    duration: 24,
    requiredCreatures: [
      { rarity: 'legendary', minCount: 3 },
      { rarity: 'mythic', minCount: 2 },
    ],
    mechanic: {
      id: 'blizzard_reflect',
      name: 'Отражение Метели',
      description: 'Отражает 35% урона обратно. Каждые 15 секунд замораживает на 4 секунды',
      reflectDamage: 35,
      immuneInterval: 15,
    },
  },
  {
    id: 'b13',
    name: 'Прародитель Холода',
    emoji: '🌡️',
    maxHp: 1500000000,
    reward: 350000000,
    auroraEssence: 40000,
    artifactChance: 90,
    description: 'Изначальное существо, создавшее сам холод. Три фазы боя, каждая сложнее предыдущей.',
    duration: 30,
    requiredCreatures: [
      { rarity: 'mythic', minCount: 3 },
      { rarity: 'legendary', minCount: 5 },
    ],
    mechanic: {
      id: 'primordial_cold',
      name: 'Изначальный холод',
      description: '3 фазы: Фаза 1 — 50% снижение урона. Фаза 2 — отражение 25% + высасывание 2%/с. Фаза 3 — всё вместе + иммунитет каждые 12с',
      phases: 3,
      damageReduction: 50,
      reflectDamage: 25,
      drainPerSecond: 2,
      immuneInterval: 12,
    },
  },
  {
    id: 'b14',
    name: 'Зеркальный Демон',
    emoji: '🪞',
    maxHp: 1000000000,
    reward: 250000000,
    auroraEssence: 30000,
    artifactChance: 88,
    description: 'Демон, создающий зеркальные копии атакующего. Чем сильнее ты — тем сильнее он.',
    duration: 20,
    requiredCreatures: [
      { rarity: 'mythic', minCount: 2 },
    ],
    mechanic: {
      id: 'mirror_damage',
      name: 'Зеркальное отражение',
      description: 'Отражает 50% урона. Каждые 8 секунд создаёт щит, поглощающий 5% от максимального HP',
      reflectDamage: 50,
      immuneInterval: 8,
    },
  },
];

// ===== Artifact sets =====
export const ARTIFACT_SETS = [
  { name: 'Комплект Авроры', bonus: '+200% к добыче', pieces: 4 },
  { name: 'Комплект Мороза', bonus: '+150% к доходу', pieces: 4 },
  { name: 'Комплект Короны', bonus: '+50% к престижу', pieces: 3 },
  { name: 'Комплект Севера', bonus: '+100% к удаче', pieces: 4 },
];

// ===== Sample artifacts (12 key pieces) =====
export const ARTIFACTS: Artifact[] = [
  { id: 'a1', name: 'Осколок Авроры', emoji: '💎', set: 'Комплект Авроры', rarity: 'rare', bonus: '+50% к доходу', bonusValue: 50, bonusType: 'income', description: 'Застывший луч северного сияния.' },
  { id: 'a2', name: 'Корона Авроры', emoji: '👑', set: 'Комплект Авроры', rarity: 'epic', bonus: '+100% к удаче', bonusValue: 100, bonusType: 'luck', description: 'Корона, сотканная из света полярного неба.' },
  { id: 'a3', name: 'Сердце Авроры', emoji: '💗', set: 'Комплект Авроры', rarity: 'legendary', bonus: '+150% к доходу', bonusValue: 150, bonusType: 'income', description: 'Сердце, что бьётся в ритме сияния.' },
  { id: 'a4', name: 'Душа Авроры', emoji: '✨', set: 'Комплект Авроры', rarity: 'mythic', bonus: '+200% к доходу (полный комплект)', bonusValue: 200, bonusType: 'income', description: 'Душа самой Авроры в кристаллической форме.' },
  { id: 'a5', name: 'Меч Мороза', emoji: '⚔️', set: 'Комплект Мороза', rarity: 'epic', bonus: '+80% к урону по боссам', bonusValue: 80, bonusType: 'damage', description: 'Клинок, что замораживает всё, чего коснётся.' },
  { id: 'a6', name: 'Щит Мороза', emoji: '🛡️', set: 'Комплект Мороза', rarity: 'epic', bonus: '+60% к HP клана', bonusValue: 60, bonusType: 'damage', description: 'Несокрушимый щит из вечного льда.' },
  { id: 'a7', name: 'Скипетр Мороза', emoji: '🪄', set: 'Комплект Мороза', rarity: 'legendary', bonus: '+120% к доходу', bonusValue: 120, bonusType: 'income', description: 'Скипетр, повелевающий метелями.' },
  { id: 'a8', name: 'Корона Севера', emoji: '🔮', set: 'Комплект Короны', rarity: 'legendary', bonus: '+30% к престижу', bonusValue: 30, bonusType: 'prestige', description: 'Корона, носить которую дано лишь достойным.' },
  { id: 'a9', name: 'Печать Севера', emoji: '🔱', set: 'Комплект Короны', rarity: 'mythic', bonus: '+50% к престижу', bonusValue: 50, bonusType: 'prestige', description: 'Печать, скрепляющая договор с зимой.' },
  { id: 'a10', name: 'Звезда Севера', emoji: '⭐', set: 'Комплект Севера', rarity: 'rare', bonus: '+50% к удаче', bonusValue: 50, bonusType: 'luck', description: 'Полярная звезда в материальной форме.' },
  { id: 'a11', name: 'Компас Севера', emoji: '🧭', set: 'Комплект Севера', rarity: 'epic', bonus: '+40% к скорости экспедиций', bonusValue: 40, bonusType: 'speed', description: 'Всегда указывает на Север.' },
  { id: 'a12', name: 'Карта Севера', emoji: '🗺️', set: 'Комплект Севера', rarity: 'legendary', bonus: '+100% к удаче', bonusValue: 100, bonusType: 'luck', description: 'Карта всех тайн полярного мира.' },
];

// ===== Chests (with dynamic pricing support) =====
export const CHESTS: Chest[] = [
  {
    id: 'wooden',
    name: 'Деревянный сундук',
    emoji: '📦',
    baseCost: 500,
    currency: 'crystals',
    rarityDrops: { common: 70, uncommon: 25, rare: 4.5, epic: 0.4, legendary: 0.1, mythic: 0, ancient: 0 },
    description: 'Простой сундук для новичков. 1 предмет.',
    gradient: 'from-amber-900/60 to-stone-900/60',
    priceMultiplier: 1.08,
    itemCount: 1,
    isDonate: false,
  },
  {
    id: 'ice',
    name: 'Ледяной сундук',
    emoji: '🧊',
    baseCost: 5000,
    currency: 'crystals',
    rarityDrops: { common: 40, uncommon: 40, rare: 15, epic: 4, legendary: 0.9, mythic: 0.1, ancient: 0 },
    description: 'Заледеневший сундук с редкими находками. 2 предмета.',
    gradient: 'from-cyan-800/60 to-blue-950/60',
    priceMultiplier: 1.10,
    itemCount: 2,
    isDonate: false,
  },
  {
    id: 'north',
    name: 'Северный сундук',
    emoji: '⛄',
    baseCost: 50000,
    currency: 'crystals',
    rarityDrops: { common: 10, uncommon: 30, rare: 35, epic: 18, legendary: 5.5, mythic: 1.4, ancient: 0.1 },
    description: 'Сундук с тайнственных северных земель. 3 предмета.',
    gradient: 'from-sky-700/60 to-indigo-950/60',
    priceMultiplier: 1.12,
    itemCount: 3,
    isDonate: false,
  },
  {
    id: 'aurora',
    name: 'Сундук Авроры',
    emoji: '🌌',
    baseCost: 100,
    currency: 'stars',
    rarityDrops: { common: 0, uncommon: 5, rare: 20, epic: 35, legendary: 28, mythic: 10.9, ancient: 1.1 },
    description: 'Донатный сундук! 10 предметов, усиленные шансы редких. ★ за открытие.',
    gradient: 'from-purple-700/60 to-pink-950/60',
    priceMultiplier: 1.10,
    itemCount: 10,
    isDonate: true,
  },
  {
    id: 'ancient',
    name: 'Древний сундук',
    emoji: '🗝️',
    baseCost: 500,
    currency: 'stars',
    rarityDrops: { common: 0, uncommon: 0, rare: 5, epic: 20, legendary: 40, mythic: 30, ancient: 5 },
    description: 'Легендарный донатный сундук! 10 предметов, шанс Ancient: 5%! ★ за открытие.',
    gradient: 'from-amber-600/60 to-yellow-900/60',
    priceMultiplier: 1.12,
    itemCount: 10,
    isDonate: true,
  },
  {
    id: 'skins',
    name: 'Сундук Скинов',
    emoji: '🎭',
    baseCost: 100,
    currency: 'stars',
    rarityDrops: { common: 0, uncommon: 25, rare: 35, epic: 25, legendary: 12, mythic: 2.9, ancient: 0.1 },
    description: 'Сундук с рамками профиля и скинами! 10 предметов. ★ за открытие.',
    gradient: 'from-pink-700/60 to-purple-950/60',
    priceMultiplier: 1.15,
    frameDropChance: 60, // 60% chance to drop a frame instead of creature
    itemCount: 10,
    isDonate: true,
  },
];

// ===== Donate Packs =====
export const DONATE_PACKS: DonatePack[] = [
  { id: 'dp1', stars: 50, crystals: 50000, bonus: '' },
  { id: 'dp2', stars: 100, crystals: 120000, bonus: '' },
  { id: 'dp3', stars: 250, crystals: 350000, bonus: '+10% бонус', popular: true },
  { id: 'dp4', stars: 500, crystals: 800000, bonus: '+20% бонус' },
];

// ===== Clan Levels =====
export const CLAN_LEVELS: ClanLevel[] = [
  { level: 1, requiredTreasury: 0, clickBonus: 0, autoMineBonus: 0, memberLimit: 10, title: 'Новички' },
  { level: 2, requiredTreasury: 100000, clickBonus: 5, autoMineBonus: 3, memberLimit: 15, title: 'Искатели' },
  { level: 3, requiredTreasury: 500000, clickBonus: 10, autoMineBonus: 7, memberLimit: 20, title: 'Охотники' },
  { level: 4, requiredTreasury: 2000000, clickBonus: 15, autoMineBonus: 12, memberLimit: 25, title: 'Воины' },
  { level: 5, requiredTreasury: 5000000, clickBonus: 22, autoMineBonus: 18, memberLimit: 30, title: 'Стражи' },
  { level: 6, requiredTreasury: 10000000, clickBonus: 30, autoMineBonus: 25, memberLimit: 40, title: 'Лорды' },
  { level: 7, requiredTreasury: 25000000, clickBonus: 40, autoMineBonus: 35, memberLimit: 50, title: 'Властелины' },
  { level: 8, requiredTreasury: 50000000, clickBonus: 50, autoMineBonus: 45, memberLimit: 60, title: 'Императоры' },
  { level: 9, requiredTreasury: 100000000, clickBonus: 65, autoMineBonus: 55, memberLimit: 75, title: 'Божественные' },
  { level: 10, requiredTreasury: 500000000, clickBonus: 80, autoMineBonus: 70, memberLimit: 100, title: 'Вечные' },
];

// ===== Daily rewards (30 days) =====
export const DAILY_REWARDS: DailyReward[] = [
  { day: 1, type: 'crystals', amount: 100, label: '100 💎' },
  { day: 2, type: 'shards', amount: 50, label: '50 ❄️' },
  { day: 3, type: 'crystals', amount: 200, label: '200 💎' },
  { day: 4, type: 'chest', amount: 1, label: 'Ледяной сундук' },
  { day: 5, type: 'crystals', amount: 300, label: '300 💎' },
  { day: 6, type: 'shards', amount: 100, label: '100 ❄️' },
  { day: 7, type: 'creature', amount: 1, label: 'Epic существо', rarity: 'epic' },
  { day: 8, type: 'crystals', amount: 400, label: '400 💎' },
  { day: 9, type: 'shards', amount: 150, label: '150 ❄️' },
  { day: 10, type: 'chest', amount: 1, label: 'Северный сундук' },
  { day: 14, type: 'creature', amount: 1, label: 'Legendary существо', rarity: 'legendary' },
  { day: 21, type: 'chest', amount: 1, label: 'Сундук Авроры' },
  { day: 30, type: 'chest', amount: 1, label: 'Legendary сундук', rarity: 'legendary' },
];

// ===== Profile Frames (droppable from chests) =====
export const PROFILE_FRAMES: ProfileFrame[] = [
  // Common frames
  { id: 'pf1', name: 'Ледяной обод', emoji: '🔷', rarity: 'common', borderColor: 'linear-gradient(135deg, #94a3b8, #cbd5e1)', glowColor: '0 0 8px rgba(148,163,184,0.4)', description: 'Простая ледяная рамка. Начало пути.' },
  { id: 'pf2', name: 'Снежный венок', emoji: '❄️', rarity: 'common', borderColor: 'linear-gradient(135deg, #7dd3fc, #bae6fd)', glowColor: '0 0 10px rgba(125,211,252,0.4)', description: 'Венок из снежинок вокруг профиля.' },
  { id: 'pf3', name: 'Морозный край', emoji: '🌫️', rarity: 'common', borderColor: 'linear-gradient(135deg, #a5b4fc, #c7d2fe)', glowColor: '0 0 8px rgba(165,180,252,0.3)', description: 'Туманный мороз обволакивает аватар.' },
  // Uncommon frames
  { id: 'pf4', name: 'Аврорное кольцо', emoji: '✦', rarity: 'uncommon', borderColor: 'linear-gradient(135deg, #a78bfa, #c4b5fd, #7dd3fc)', glowColor: '0 0 12px rgba(167,139,250,0.5)', description: 'Кольцо северного сияния.' },
  { id: 'pf5', name: 'Кристальный обод', emoji: '💎', rarity: 'uncommon', borderColor: 'linear-gradient(135deg, #67e8f9, #a5f3fc)', glowColor: '0 0 14px rgba(103,232,249,0.5)', description: 'Огранённые кристаллы вокруг профиля.' },
  { id: 'pf6', name: 'Вихрь снега', emoji: '🌀', rarity: 'uncommon', borderColor: 'linear-gradient(135deg, #e0f2fe, #bae6fd, #7dd3fc)', glowColor: '0 0 12px rgba(186,230,253,0.5)', description: 'Вращающийся вихрь снежинок.' },
  // Rare frames
  { id: 'pf7', name: 'Корона мороза', emoji: '👑', rarity: 'rare', borderColor: 'linear-gradient(135deg, #fbbf24, #f59e0b, #fbbf24)', glowColor: '0 0 16px rgba(251,191,36,0.5)', description: 'Золотая корона инея. Знак власти.' },
  { id: 'pf8', name: 'Ледяной щит', emoji: '🛡️', rarity: 'rare', borderColor: 'linear-gradient(135deg, #38bdf8, #0ea5e9, #0284c7)', glowColor: '0 0 18px rgba(56,189,248,0.6)', description: 'Щит из вечного льда защитит твой профиль.' },
  { id: 'pf9', name: 'Звезда Севера', emoji: '⭐', rarity: 'rare', borderColor: 'linear-gradient(135deg, #fde68a, #fbbf24, #f59e0b)', glowColor: '0 0 16px rgba(253,230,138,0.5)', description: 'Полярная звезда освещает путь.' },
  // Epic frames
  { id: 'pf10', name: 'Дыхание дракона', emoji: '🐉', rarity: 'epic', borderColor: 'linear-gradient(135deg, #c084fc, #a855f7, #7c3aed)', glowColor: '0 0 22px rgba(168,85,247,0.6), 0 0 44px rgba(168,85,247,0.2)', description: 'Морозное дыхание ледяного дракона.' },
  { id: 'pf11', name: 'Пламя Авроры', emoji: '🔥', rarity: 'epic', borderColor: 'linear-gradient(135deg, #f472b6, #a855f7, #6366f1)', glowColor: '0 0 22px rgba(244,114,182,0.5), 0 0 44px rgba(168,85,247,0.2)', description: 'Горящее северное сияние в рамке.' },
  { id: 'pf12', name: 'Ледяной клинок', emoji: '⚔️', rarity: 'epic', borderColor: 'linear-gradient(135deg, #818cf8, #6366f1, #4f46e5)', glowColor: '0 0 20px rgba(129,140,248,0.6)', description: 'Два скрещённых клинка из вечного льда.' },
  // Legendary frames
  { id: 'pf13', name: 'Вечная зима', emoji: '🌍', rarity: 'legendary', borderColor: 'linear-gradient(135deg, #fbbf24, #f59e0b, #eab308, #fbbf24)', glowColor: '0 0 28px rgba(251,191,36,0.7), 0 0 56px rgba(251,191,36,0.3)', description: 'Рамка повелителя зимы. Мир замерзает.' },
  { id: 'pf14', name: 'Коронация льда', emoji: '👸', rarity: 'legendary', borderColor: 'linear-gradient(135deg, #ec4899, #f472b6, #fbbf24, #f59e0b)', glowColor: '0 0 26px rgba(236,72,153,0.6), 0 0 52px rgba(251,191,36,0.3)', description: 'Корона ледяной королевы. Величие и холод.' },
  // Mythic frames
  { id: 'pf15', name: 'Абсолютный нуль', emoji: '🌡️', rarity: 'mythic', borderColor: 'linear-gradient(135deg, #06b6d4, #8b5cf6, #ec4899, #06b6d4)', glowColor: '0 0 32px rgba(6,182,212,0.7), 0 0 64px rgba(139,92,246,0.4), 0 0 96px rgba(236,72,153,0.2)', description: 'Температура пустоты. Рамка за гранью понимания.' },
  { id: 'pf16', name: 'Снежный прародитель', emoji: '❄️', rarity: 'mythic', borderColor: 'linear-gradient(135deg, #e0f2fe, #bae6fd, #a5f3fc, #67e8f9, #e0f2fe)', glowColor: '0 0 30px rgba(224,242,254,0.7), 0 0 60px rgba(103,232,249,0.4), 0 0 90px rgba(125,211,252,0.2)', description: 'Первая снежинка вселенной обнимает профиль.' },
  // Ancient frame — ultra rare
  { id: 'pf17', name: 'Император Льда', emoji: '🧊', rarity: 'ancient', borderColor: 'linear-gradient(135deg, #fbbf24, #f59e0b, #06b6d4, #8b5cf6, #ec4899, #fbbf24)', glowColor: '0 0 40px rgba(251,191,36,0.8), 0 0 80px rgba(6,182,212,0.5), 0 0 120px rgba(139,92,246,0.3), 0 0 160px rgba(236,72,153,0.15)', description: 'Легендарная рамка Императора. Тот, кто правит вечным морозом.' },

  // ===== NEW: Animated & Glowing frames =====
  // Legendary — Glowing ice shards
  { id: 'pf18', name: 'Осколки вечного льда', emoji: '🧊', rarity: 'legendary', borderColor: 'linear-gradient(135deg, #67e8f9, #22d3ee, #06b6d4, #67e8f9)', glowColor: '0 0 24px rgba(103,232,249,0.7), 0 0 48px rgba(34,211,238,0.4), 0 0 72px rgba(6,182,212,0.2)', description: 'Осколки льда мерцают и светятся вокруг профиля.' },
  // Mythic — Pulsing aurora
  { id: 'pf19', name: 'Пульсация Авроры', emoji: '🌌', rarity: 'mythic', borderColor: 'linear-gradient(135deg, #a78bfa, #c084fc, #f472b6, #fb923c, #a78bfa)', glowColor: '0 0 30px rgba(167,139,250,0.7), 0 0 60px rgba(244,114,182,0.4), 0 0 90px rgba(251,146,60,0.2)', description: 'Пульсирующее северное сияние в рамке.' },
  // Mythic — Frozen fire
  { id: 'pf20', name: 'Замёрзший огонь', emoji: '🔥', rarity: 'mythic', borderColor: 'linear-gradient(135deg, #f97316, #ef4444, #dc2626, #f97316)', glowColor: '0 0 28px rgba(249,115,22,0.7), 0 0 56px rgba(239,68,68,0.4), 0 0 84px rgba(220,38,38,0.2)', description: 'Огонь, замёрзший на грани льда и пламени.' },
  // Ancient — Shattered ice crown
  { id: 'pf21', name: 'Расколотая корона', emoji: '💎', rarity: 'ancient', borderColor: 'linear-gradient(135deg, #e0f2fe, #bae6fd, #fbbf24, #f59e0b, #a78bfa, #e0f2fe)', glowColor: '0 0 36px rgba(251,191,36,0.8), 0 0 72px rgba(167,139,250,0.5), 0 0 108px rgba(186,230,253,0.3), 0 0 144px rgba(251,191,36,0.1)', description: 'Корона из осколков древнего льда. Сияет и пульсирует.' },
  // Epic — Ice thorns
  { id: 'pf22', name: 'Ледяные шипы', emoji: '🗡️', rarity: 'epic', borderColor: 'linear-gradient(135deg, #38bdf8, #7dd3fc, #bae6fd)', glowColor: '0 0 20px rgba(56,189,248,0.6), 0 0 40px rgba(125,211,252,0.3)', description: 'Шипы из чистого льда оплетают профиль.' },
];

// ===== Profile Skins (head overlays on top of Telegram avatar) =====
export const PROFILE_SKINS: ProfileSkin[] = [
  // Common — small decorative overlays
  { id: 'ps1', name: 'Ледяной странник', emoji: '🧊', rarity: 'common', bgColor: 'oklch(0.60 0.08 215)', description: 'Лёд на голове — знак странника.', overlayPosition: 'top', overlayScale: 0.65 },
  { id: 'ps2', name: 'Снежный охотник', emoji: '🐺', rarity: 'common', bgColor: 'oklch(0.55 0.06 230)', description: 'Уши волка — видишь сквозь метель.', overlayPosition: 'top', overlayScale: 0.7 },
  { id: 'ps11', name: 'Снежок', emoji: '❄️', rarity: 'common', bgColor: 'oklch(0.65 0.05 210)', description: 'Снежинка тает на макушке.', overlayPosition: 'top', overlayScale: 0.55 },
  // Uncommon — crowns & hats
  { id: 'ps3', name: 'Шапка медведя', emoji: '🐻', rarity: 'uncommon', bgColor: 'oklch(0.70 0.04 60)', description: 'Уши белого медведя на голове.', overlayPosition: 'top', overlayScale: 0.7 },
  { id: 'ps4', name: 'Аврорный дух', emoji: '👻', rarity: 'uncommon', bgColor: 'oklch(0.55 0.12 295)', description: 'Призрачное свечение над головой.', overlayPosition: 'top', overlayScale: 0.6 },
  { id: 'ps12', name: 'Ледяная корона', emoji: '👑', rarity: 'uncommon', bgColor: 'oklch(0.65 0.08 85)', description: 'Простая корона из сосулек.', overlayPosition: 'top', overlayScale: 0.6 },
  { id: 'ps13', name: 'Слизь', emoji: '🟢', rarity: 'uncommon', bgColor: 'oklch(0.55 0.14 150)', description: 'Зелёная слизь стекает с макушки.', overlayPosition: 'top', overlayScale: 0.7 },
  // Rare — glowing accessories
  { id: 'ps5', name: 'Ведьмина шляпа', emoji: '🧝‍♀️', rarity: 'rare', bgColor: 'oklch(0.50 0.14 300)', description: 'Морозная шляпа ведьмы.', overlayPosition: 'top', overlayScale: 0.75 },
  { id: 'ps6', name: 'Шлем рыцаря', emoji: '⚔️', rarity: 'rare', bgColor: 'oklch(0.55 0.10 250)', description: 'Ледяной шлем с забралом.', overlayPosition: 'top', overlayScale: 0.7 },
  { id: 'ps14', name: 'Огненный рог', emoji: '🔥', rarity: 'rare', bgColor: 'oklch(0.55 0.16 30)', description: 'Пылающий рог на голове.', overlayPosition: 'top-right', overlayScale: 0.6 },
  { id: 'ps15', name: 'Кристальный нимб', emoji: '💎', rarity: 'rare', bgColor: 'oklch(0.55 0.10 215)', description: 'Сияющий нимб из кристаллов.', overlayPosition: 'top', overlayScale: 0.65 },
  // Epic — dramatic headpieces
  { id: 'ps7', name: 'Драконьи рога', emoji: '🐉', rarity: 'epic', bgColor: 'oklch(0.50 0.16 280)', description: 'Рога ледяного дракона на голове.', overlayPosition: 'top', overlayScale: 0.8 },
  { id: 'ps16', name: 'Ледяная слизь', emoji: '🧊', rarity: 'epic', bgColor: 'oklch(0.50 0.12 215)', description: 'Ледяная слизь покрывает голову.', overlayPosition: 'top', overlayScale: 0.75 },
  { id: 'ps17', name: 'Корона бурь', emoji: '⚡', rarity: 'epic', bgColor: 'oklch(0.55 0.14 280)', description: 'Молнии вьются вокруг короны.', overlayPosition: 'top', overlayScale: 0.7 },
  // Legendary — royal
  { id: 'ps8', name: 'Корона Льда', emoji: '👑', rarity: 'legendary', bgColor: 'oklch(0.65 0.12 85)', description: 'Истинная корона Короля Льда.', overlayPosition: 'top', overlayScale: 0.75 },
  { id: 'ps18', name: 'Тиара Авроры', emoji: '✦', rarity: 'legendary', bgColor: 'oklch(0.55 0.14 295)', description: 'Тиара из чистого северного сияния.', overlayPosition: 'top', overlayScale: 0.7 },
  // Mythic
  { id: 'ps9', name: 'Венец Зимы', emoji: '👸', rarity: 'mythic', bgColor: 'oklch(0.60 0.16 320)', description: 'Божественный венец Богини Зимы.', overlayPosition: 'top', overlayScale: 0.8 },
  { id: 'ps19', name: 'Ледяной демон', emoji: '😈', rarity: 'mythic', bgColor: 'oklch(0.55 0.18 350)', description: 'Рога ледяного демона — страх и мощь.', overlayPosition: 'top', overlayScale: 0.8 },
  // Ancient
  { id: 'ps10', name: 'Корона Императора', emoji: '🧊', rarity: 'ancient', bgColor: 'linear-gradient(135deg, oklch(0.65 0.12 85), oklch(0.55 0.16 280))', description: 'Вечная корона Императора Льда.', overlayPosition: 'top', overlayScale: 0.85 },
  { id: 'ps20', name: 'Око Вечности', emoji: '👁️', rarity: 'ancient', bgColor: 'linear-gradient(135deg, oklch(0.55 0.18 280), oklch(0.65 0.12 85))', description: 'Третий глаз — видит сквозь время и лёд.', overlayPosition: 'top', overlayScale: 0.75 },
];

// ===== Season Pass (Battle Pass) =====

export type SeasonRewardType = 'crystals' | 'iceShards' | 'auroraEssence' | 'creature' | 'frame' | 'skin' | 'chest' | 'stars';

export interface SeasonTierReward {
  type: SeasonRewardType;
  amount: number;
  label: string;
  rarity?: Rarity;
  itemId?: string; // specific frame/skin/creature id
}

export interface SeasonTier {
  level: number; // 1-50
  xpRequired: number; // cumulative XP to reach this tier
  freeReward: SeasonTierReward;
  premiumReward: SeasonTierReward;
}

export interface SeasonPassSeason {
  id: string;
  name: string;
  emoji: string;
  description: string;
  startDate: string; // ISO date
  endDate: string; // ISO date
  premiumCost: number; // in Telegram Stars
  tiers: SeasonTier[];
  bgGradient: string;
  accentColor: string;
}

// Generate 50 tiers with escalating rewards
function generateSeasonTiers(): SeasonTier[] {
  const tiers: SeasonTier[] = [];

  const freeRewards: SeasonTierReward[] = [
    { type: 'crystals', amount: 500, label: '500 💎' },
    { type: 'iceShards', amount: 50, label: '50 ❄️' },
    { type: 'crystals', amount: 800, label: '800 💎' },
    { type: 'crystals', amount: 1000, label: '1K 💎' },
    { type: 'chest', amount: 1, label: 'Ледяной сундук', rarity: 'rare' },
    { type: 'iceShards', amount: 100, label: '100 ❄️' },
    { type: 'crystals', amount: 1500, label: '1.5K 💎' },
    { type: 'auroraEssence', amount: 5, label: '5 ✦' },
    { type: 'crystals', amount: 2000, label: '2K 💎' },
    { type: 'chest', amount: 1, label: 'Северный сундук', rarity: 'epic' },
    { type: 'iceShards', amount: 150, label: '150 ❄️' },
    { type: 'crystals', amount: 3000, label: '3K 💎' },
    { type: 'auroraEssence', amount: 8, label: '8 ✦' },
    { type: 'crystals', amount: 4000, label: '4K 💎' },
    { type: 'chest', amount: 1, label: 'Ледяной сундук', rarity: 'rare' },
    { type: 'iceShards', amount: 200, label: '200 ❄️' },
    { type: 'crystals', amount: 5000, label: '5K 💎' },
    { type: 'auroraEssence', amount: 10, label: '10 ✦' },
    { type: 'crystals', amount: 7000, label: '7K 💎' },
    { type: 'chest', amount: 1, label: 'Сундук Авроры', rarity: 'legendary' },
    { type: 'iceShards', amount: 300, label: '300 ❄️' },
    { type: 'crystals', amount: 10000, label: '10K 💎' },
    { type: 'auroraEssence', amount: 15, label: '15 ✦' },
    { type: 'crystals', amount: 12000, label: '12K 💎' },
    { type: 'chest', amount: 1, label: 'Северный сундук', rarity: 'epic' },
    { type: 'iceShards', amount: 400, label: '400 ❄️' },
    { type: 'crystals', amount: 15000, label: '15K 💎' },
    { type: 'auroraEssence', amount: 20, label: '20 ✦' },
    { type: 'crystals', amount: 18000, label: '18K 💎' },
    { type: 'chest', amount: 1, label: 'Сундук Авроры', rarity: 'legendary' },
    { type: 'crystals', amount: 22000, label: '22K 💎' },
    { type: 'iceShards', amount: 500, label: '500 ❄️' },
    { type: 'auroraEssence', amount: 25, label: '25 ✦' },
    { type: 'crystals', amount: 25000, label: '25K 💎' },
    { type: 'chest', amount: 2, label: '2x Северный сундук', rarity: 'epic' },
    { type: 'crystals', amount: 30000, label: '30K 💎' },
    { type: 'iceShards', amount: 600, label: '600 ❄️' },
    { type: 'auroraEssence', amount: 30, label: '30 ✦' },
    { type: 'crystals', amount: 35000, label: '35K 💎' },
    { type: 'chest', amount: 1, label: 'Древний сундук', rarity: 'mythic' },
    { type: 'crystals', amount: 40000, label: '40K 💎' },
    { type: 'iceShards', amount: 800, label: '800 ❄️' },
    { type: 'auroraEssence', amount: 35, label: '35 ✦' },
    { type: 'crystals', amount: 50000, label: '50K 💎' },
    { type: 'chest', amount: 2, label: '2x Сундук Авроры', rarity: 'legendary' },
    { type: 'crystals', amount: 60000, label: '60K 💎' },
    { type: 'iceShards', amount: 1000, label: '1K ❄️' },
    { type: 'auroraEssence', amount: 40, label: '40 ✦' },
    { type: 'crystals', amount: 75000, label: '75K 💎' },
    { type: 'chest', amount: 1, label: 'Древний сундук', rarity: 'mythic' },
  ];

  const premiumRewards: SeasonTierReward[] = [
    { type: 'crystals', amount: 2000, label: '2K 💎' },
    { type: 'frame', amount: 1, label: 'Ледяной обод', rarity: 'common', itemId: 'pf1' },
    { type: 'crystals', amount: 3000, label: '3K 💎' },
    { type: 'skin', amount: 1, label: 'Снежок', rarity: 'common', itemId: 'ps11' },
    { type: 'crystals', amount: 5000, label: '5K 💎' },
    { type: 'iceShards', amount: 200, label: '200 ❄️' },
    { type: 'crystals', amount: 7000, label: '7K 💎' },
    { type: 'frame', amount: 1, label: 'Аврорное кольцо', rarity: 'uncommon', itemId: 'pf4' },
    { type: 'crystals', amount: 10000, label: '10K 💎' },
    { type: 'skin', amount: 1, label: 'Слизь', rarity: 'uncommon', itemId: 'ps13' },
    { type: 'crystals', amount: 12000, label: '12K 💎' },
    { type: 'auroraEssence', amount: 15, label: '15 ✦' },
    { type: 'frame', amount: 1, label: 'Корона мороза', rarity: 'rare', itemId: 'pf7' },
    { type: 'crystals', amount: 15000, label: '15K 💎' },
    { type: 'skin', amount: 1, label: 'Кристальный нимб', rarity: 'rare', itemId: 'ps15' },
    { type: 'crystals', amount: 18000, label: '18K 💎' },
    { type: 'frame', amount: 1, label: 'Ледяной щит', rarity: 'rare', itemId: 'pf8' },
    { type: 'auroraEssence', amount: 20, label: '20 ✦' },
    { type: 'crystals', amount: 22000, label: '22K 💎' },
    { type: 'skin', amount: 1, label: 'Драконьи рога', rarity: 'epic', itemId: 'ps7' },
    { type: 'crystals', amount: 25000, label: '25K 💎' },
    { type: 'frame', amount: 1, label: 'Дыхание дракона', rarity: 'epic', itemId: 'pf10' },
    { type: 'auroraEssence', amount: 30, label: '30 ✦' },
    { type: 'crystals', amount: 30000, label: '30K 💎' },
    { type: 'skin', amount: 1, label: 'Ледяная слизь', rarity: 'epic', itemId: 'ps16' },
    { type: 'crystals', amount: 35000, label: '35K 💎' },
    { type: 'frame', amount: 1, label: 'Ледяные шипы', rarity: 'epic', itemId: 'pf22' },
    { type: 'auroraEssence', amount: 35, label: '35 ✦' },
    { type: 'crystals', amount: 40000, label: '40K 💎' },
    { type: 'skin', amount: 1, label: 'Корона Льда', rarity: 'legendary', itemId: 'ps8' },
    { type: 'stars', amount: 50, label: '50 ★' },
    { type: 'frame', amount: 1, label: 'Вечная зима', rarity: 'legendary', itemId: 'pf13' },
    { type: 'crystals', amount: 50000, label: '50K 💎' },
    { type: 'auroraEssence', amount: 40, label: '40 ✦' },
    { type: 'skin', amount: 1, label: 'Тиара Авроры', rarity: 'legendary', itemId: 'ps18' },
    { type: 'crystals', amount: 55000, label: '55K 💎' },
    { type: 'frame', amount: 1, label: 'Осколки вечного льда', rarity: 'legendary', itemId: 'pf18' },
    { type: 'auroraEssence', amount: 50, label: '50 ✦' },
    { type: 'stars', amount: 75, label: '75 ★' },
    { type: 'skin', amount: 1, label: 'Венец Зимы', rarity: 'mythic', itemId: 'ps9' },
    { type: 'crystals', amount: 60000, label: '60K 💎' },
    { type: 'frame', amount: 1, label: 'Пульсация Авроры', rarity: 'mythic', itemId: 'pf19' },
    { type: 'auroraEssence', amount: 60, label: '60 ✦' },
    { type: 'crystals', amount: 70000, label: '70K 💎' },
    { type: 'skin', amount: 1, label: 'Ледяной демон', rarity: 'mythic', itemId: 'ps19' },
    { type: 'stars', amount: 100, label: '100 ★' },
    { type: 'frame', amount: 1, label: 'Абсолютный нуль', rarity: 'mythic', itemId: 'pf15' },
    { type: 'crystals', amount: 80000, label: '80K 💎' },
    { type: 'auroraEssence', amount: 75, label: '75 ✦' },
    { type: 'crystals', amount: 100000, label: '100K 💎' },
    { type: 'frame', amount: 1, label: 'Расколотая корона', rarity: 'ancient', itemId: 'pf21' },
  ];

  // XP curve: MUCH more generous — players should reach tier 30-40 casually
  // Total XP to max: ~60,000 (very achievable over 30 days)
  let cumulativeXp = 0;
  for (let i = 0; i < 50; i++) {
    const baseXp = 100 + i * 30 + Math.floor(i * i * 1.2);
    cumulativeXp += baseXp;
    tiers.push({
      level: i + 1,
      xpRequired: cumulativeXp,
      freeReward: freeRewards[i] || { type: 'crystals', amount: 1000, label: '1K 💎' },
      premiumReward: premiumRewards[i] || { type: 'crystals', amount: 5000, label: '5K 💎' },
    });
  }

  return tiers;
}

export const SEASON_PASS: SeasonPassSeason = {
  id: 'season_1',
  name: 'Эпоха Мороза',
  emoji: '🧊',
  description: 'Первый сезон ICE EMPIRE. Зима близко — собирай XP и открывай награды!',
  startDate: '2026-07-01T00:00:00Z',
  endDate: '2026-07-31T23:59:59Z',
  premiumCost: 300,
  tiers: generateSeasonTiers(),
  bgGradient: 'from-cyan-900/40 via-blue-950/40 to-indigo-950/40',
  accentColor: 'oklch(0.78 0.10 215)',
};

// XP rewards for various actions — GENEROUS: players should easily progress
export const SEASON_XP_REWARDS = {
  bossKill: 500,        // per boss killed — big chunk!
  chestOpen: 200,       // per chest opened
  dailyClaim: 250,      // per daily reward claimed
  tapMilestone: 100,    // per 100 taps
  creatureUpgrade: 50,  // per creature upgrade
  clanContribute: 150,  // per clan contribution
  prestige: 2000,       // per prestige — massive!
  loginBonus: 100,      // daily login bonus
} as const;

export function getSeasonTimeRemaining(): { days: number; hours: number; totalMs: number } {
  const now = Date.now();
  const end = new Date(SEASON_PASS.endDate).getTime();
  const remaining = Math.max(0, end - now);
  return {
    days: Math.floor(remaining / (24 * 3600 * 1000)),
    hours: Math.floor((remaining % (24 * 3600 * 1000)) / (3600 * 1000)),
    totalMs: remaining,
  };
}

export function getSeasonProgress(xp: number): { currentTier: number; currentTierXp: number; nextTierXp: number; progress: number } {
  const tiers = SEASON_PASS.tiers;
  let currentTier = 0;
  let currentTierXp = 0;
  let nextTierXp = tiers[0]?.xpRequired || 100;

  for (const tier of tiers) {
    if (xp >= tier.xpRequired) {
      currentTier = tier.level;
      currentTierXp = tier.xpRequired;
      nextTierXp = tiers[tier.level]?.xpRequired || tier.xpRequired;
    } else {
      nextTierXp = tier.xpRequired;
      break;
    }
  }

  const tierStartXp = currentTier > 0 ? tiers[currentTier - 1]?.xpRequired || 0 : 0;
  const tierEndXp = nextTierXp;
  const progress = tierEndXp > tierStartXp
    ? Math.min(1, (xp - tierStartXp) / (tierEndXp - tierStartXp))
    : 1;

  return { currentTier, currentTierXp, nextTierXp, progress };
}

// ===== Helper functions =====
export function getCreatureById(id: string): Creature | undefined {
  return CREATURES.find((c) => c.id === id);
}

export function getCreaturesByRarity(rarity: Rarity): Creature[] {
  return CREATURES.filter((c) => c.rarity === rarity);
}

export function getUpgradeCost(creature: Creature, currentLevel: number): number {
  return Math.floor(creature.baseCost * Math.pow(1.15, currentLevel));
}

export function getCreatureIncome(creature: Creature, level: number): number {
  // Nerfed: was baseIncome * level * (1 + (level - 1) * 0.1)
  // Now: baseIncome * level * (1 + (level - 1) * 0.02) / 50
  return (creature.baseIncome * level * (1 + (level - 1) * 0.02)) / 50;
}

export function getChestCost(chest: Chest, purchasesCount: number): number {
  return Math.floor(chest.baseCost * Math.pow(chest.priceMultiplier, purchasesCount));
}

export function getClanLevel(treasury: number): ClanLevel {
  let result = CLAN_LEVELS[0];
  for (const lvl of CLAN_LEVELS) {
    if (treasury >= lvl.requiredTreasury) {
      result = lvl;
    } else {
      break;
    }
  }
  return result;
}

export function getNextClanLevel(treasury: number): ClanLevel | null {
  for (const lvl of CLAN_LEVELS) {
    if (treasury < lvl.requiredTreasury) {
      return lvl;
    }
  }
  return null;
}

export function checkBossRequirements(boss: Boss, ownedCreatures: Record<string, { id: string; level: number; unlocked: boolean }>): { met: boolean; missing: string[] } {
  if (!boss.requiredCreatures) return { met: true, missing: [] };
  const missing: string[] = [];
  for (const req of boss.requiredCreatures) {
    const count = Object.values(ownedCreatures).filter(
      (c) => c.unlocked && CREATURES.find((cr) => cr.id === c.id)?.rarity === req.rarity
    ).length;
    if (count < req.minCount) {
      missing.push(`${req.minCount} ${RARITY_META[req.rarity].label} существ (есть ${count})`);
    }
  }
  return { met: missing.length === 0, missing };
}

export function getProfileFrameById(id: string): ProfileFrame | undefined {
  return PROFILE_FRAMES.find((f) => f.id === id);
}

export function getProfileSkinById(id: string): ProfileSkin | undefined {
  return PROFILE_SKINS.find((s) => s.id === id);
}

export function getFrameFromRarity(rarity: Rarity, ownedFrames: string[]): ProfileFrame {
  const available = PROFILE_FRAMES.filter((f) => f.rarity === rarity);
  const unowned = available.filter((f) => !ownedFrames.includes(f.id));
  const pool = unowned.length > 0 ? unowned : available;
  return pool[Math.floor(Math.random() * pool.length)];
}

export function getSkinFromRarity(rarity: Rarity, ownedSkins: string[]): ProfileSkin {
  const available = PROFILE_SKINS.filter((s) => s.rarity === rarity);
  const unowned = available.filter((s) => !ownedSkins.includes(s.id));
  const pool = unowned.length > 0 ? unowned : available;
  return pool[Math.floor(Math.random() * pool.length)];
}

export function formatNumber(num: number): string {
  if (num < 1000) return Math.floor(num).toString();
  if (num < 1_000_000) return (num / 1000).toFixed(2).replace(/\.?0+$/, '') + 'K';
  if (num < 1_000_000_000) return (num / 1_000_000).toFixed(2).replace(/\.?0+$/, '') + 'M';
  if (num < 1_000_000_000_000) return (num / 1_000_000_000).toFixed(2).replace(/\.?0+$/, '') + 'B';
  return (num / 1_000_000_000_000).toFixed(2).replace(/\.?0+$/, '') + 'T';
}
