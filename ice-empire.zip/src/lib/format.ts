// Currency display config
export const CURRENCIES = {
  crystals: { icon: '💎', label: 'Кристаллы', color: 'text-cyan-300' },
  iceShards: { icon: '❄️', label: 'Ледяные осколки', color: 'text-sky-300' },
  auroraEssence: { icon: '🌌', label: 'Эссенция Авроры', color: 'text-purple-300' },
  northCrowns: { icon: '👑', label: 'Короны Севера', color: 'text-amber-300' },
  telegramStars: { icon: '⭐', label: 'Звёзды Telegram', color: 'text-yellow-300' },
} as const;

export function formatNumber(num: number): string {
  if (num < 1000) return Math.floor(num).toString();
  if (num < 1_000_000) return (num / 1000).toFixed(2).replace(/\.?0+$/, '') + 'K';
  if (num < 1_000_000_000) return (num / 1_000_000).toFixed(2).replace(/\.?0+$/, '') + 'M';
  if (num < 1_000_000_000_000) return (num / 1_000_000_000).toFixed(2).replace(/\.?0+$/, '') + 'B';
  return (num / 1_000_000_000_000).toFixed(2).replace(/\.?0+$/, '') + 'T';
}

export function formatTime(ms: number): string {
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  if (hours > 0) return `${hours}ч ${minutes}м`;
  if (minutes > 0) return `${minutes}м ${seconds}с`;
  return `${seconds}с`;
}

export function formatTimeShort(ms: number): string {
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}
