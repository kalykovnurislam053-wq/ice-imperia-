'use client';

import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import {
  CREATURES,
  LOCATIONS,
  BOSSES,
  ARTIFACTS,
  CHESTS,
  DONATE_PACKS,
  CLAN_LEVELS,
  PROFILE_FRAMES,
  PROFILE_SKINS,
  SEASON_PASS,
  SEASON_XP_REWARDS,
  type Creature,
  type Rarity,
  type BossMechanic,
  type ProfileFrame,
  type ChestReward,
  type SeasonTierReward,
  getCreatureById,
  getUpgradeCost,
  getCreatureIncome,
  getChestCost,
  getClanLevel,
  getNextClanLevel,
  checkBossRequirements,
  getProfileFrameById,
  getProfileSkinById,
  getFrameFromRarity,
  getSkinFromRarity,
  getSeasonProgress,
} from './game-data';

export interface OwnedCreature {
  id: string;
  level: number;
  unlocked: boolean;
}

export interface ActiveBoss {
  bossId: string;
  currentHp: number;
  maxHp: number;
  endTime: number;
  damageDealt: number;
  phase?: number;
}

export interface ClanMember {
  id: string;
  name: string;
  contribution: number;
  joinedAt: number;
}

export interface ClanState {
  id: string | null;
  name: string | null;
  treasury: number;
  members: ClanMember[];
  level: number;
}

// ===== Dynamic chest pricing =====
export interface ChestPurchaseRecord {
  chestId: string;
  count: number;
  lastPurchaseTime: number;
}

const CHEST_PRICE_RESET_INTERVAL = 3 * 24 * 3600 * 1000; // 3 days in ms

const RARITY_META_ORDER: Record<Rarity, number> = {
  common: 1,
  uncommon: 2,
  rare: 3,
  epic: 4,
  legendary: 5,
  mythic: 6,
  ancient: 7,
};

function getRandomRarity(drops: Record<Rarity, number>): Rarity {
  const rand = Math.random() * 100;
  let cumulative = 0;
  const order: Rarity[] = ['common', 'uncommon', 'rare', 'epic', 'legendary', 'mythic', 'ancient'];
  for (const rarity of order) {
    cumulative += drops[rarity] || 0;
    if (rand <= cumulative) return rarity;
  }
  return 'common';
}

function getCreatureFromRarity(rarity: Rarity, ownedCreatures: Record<string, OwnedCreature>): Creature {
  const available = CREATURES.filter((c) => c.rarity === rarity);
  const unowned = available.filter((c) => !ownedCreatures[c.id]?.unlocked);
  const pool = unowned.length > 0 ? unowned : available;
  return pool[Math.floor(Math.random() * pool.length)];
}

export interface ChatMessage {
  id: string;
  playerId: string;
  playerName: string;
  playerLevel: number;
  frameId: string | null;
  skinId: string;
  avatarUrl: string | null;
  text: string;
  timestamp: number;
}

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  variant?: 'default' | 'success' | 'error';
}

interface GameState {
  // Currencies
  crystals: number;
  iceShards: number;
  auroraEssence: number;
  northCrowns: number;
  telegramStars: number;

  // Player progression
  playerLevel: number;
  playerXp: number;
  prestigeLevel: number;
  totalEarned: number;

  // Last income tick
  lastTick: number;

  // Creatures
  ownedCreatures: Record<string, OwnedCreature>;

  // Locations
  unlockedLocations: string[];
  currentLocation: string;

  // Bosses
  activeBoss: ActiveBoss | null;
  lastBossDefeat: Record<string, number>;
  bossesDefeated: number;

  // Artifacts
  ownedArtifacts: string[];
  equippedArtifacts: string[];

  // Clan
  clan: ClanState;

  // Daily rewards
  lastDailyClaim: number;
  dailyStreak: number;

  // Chest dynamic pricing
  chestPurchases: Record<string, ChestPurchaseRecord>;

  // Stats
  totalClicks: number;
  totalChestsOpened: number;
  joinedAt: number;

  // Profile
  playerName: string;
  selectedFrame: string | null;
  selectedSkin: string;
  ownedFrames: string[];
  ownedSkins: string[];
  telegramAvatarUrl: string | null;
  telegramUserId: string | null;

  // Season Pass
  seasonXp: number;
  seasonPremium: boolean;
  seasonClaimedFree: string[]; // tier levels claimed as free
  seasonClaimedPremium: string[]; // tier levels claimed as premium
  seasonTapCount: number; // for tap milestone tracking

  // Chat
  chatMessages: ChatMessage[];

  // Actions — Currencies
  addCrystals: (amount: number) => void;
  addIceShards: (amount: number) => void;
  addAuroraEssence: (amount: number) => void;
  addNorthCrowns: (amount: number) => void;
  addStars: (amount: number) => void;
  spendCrystals: (amount: number) => boolean;
  spendStars: (amount: number) => boolean;
  spendIceShards: (amount: number) => boolean;
  spendAuroraEssence: (amount: number) => boolean;

  // Actions — Income
  tickIncome: () => void;
  collectOfflineIncome: () => number;

  // Actions — Creatures
  buyCreature: (creatureId: string) => boolean;
  upgradeCreature: (creatureId: string) => boolean;

  // Actions — Locations
  unlockLocation: (locationId: string) => boolean;
  setCurrentLocation: (locationId: string) => void;

  // Actions — Bosses
  attackBoss: (damage: number) => { defeated: boolean; reward?: number; reflectedDamage?: number };
  startBoss: (bossId: string) => { success: boolean; error?: string };

  // Actions — Chests
  openChest: (chestId: string) => {
    items: Array<{
      type: 'creature' | 'frame';
      rarity: Rarity;
      creature?: Creature;
      frame?: ProfileFrame;
      isDuplicate: boolean;
      shardReward?: number;
    }>;
    success: boolean;
    error?: string;
  };
  getCurrentChestCost: (chestId: string) => number;
  getNextChestResetTime: () => number;

  // Actions — Donate
  purchaseDonatePack: (packId: string) => { success: boolean; crystalsAdded?: number; error?: string };

  // Actions — Clan
  createClan: (name: string) => void;
  leaveClan: () => void;
  contributeToClan: (amount: number) => boolean;

  // Actions — Daily
  claimDailyReward: () => { claimed: boolean; reward?: string };

  // Actions — Artifacts
  equipArtifact: (artifactId: string) => void;
  unequipArtifact: (artifactId: string) => void;

  // Actions — Prestige
  prestige: () => { success: boolean; crownsGained?: number };

  // Actions — Profile
  setSelectedFrame: (frameId: string | null) => void;
  setSelectedSkin: (skinId: string) => void;
  setPlayerName: (name: string) => void;
  setTelegramAvatar: (url: string | null, userId: string | null) => void;

  // Actions — Season Pass
  addSeasonXp: (amount: number) => void;
  claimSeasonTier: (tierLevel: number, track: 'free' | 'premium') => { success: boolean; reward?: SeasonTierReward; error?: string };
  purchaseSeasonPremium: () => { success: boolean; error?: string };
  getSeasonTierStatus: (tierLevel: number) => { freeUnlocked: boolean; premiumUnlocked: boolean; freeClaimed: boolean; premiumClaimed: boolean };

  // Actions — Chat
  sendChatMessage: (text: string) => void;
  loadChatMessages: () => void;

  // Actions — Reset
  resetGame: () => void;

  // Derived getters
  getIncomePerSecond: () => number;
  getTotalIncomeMultiplier: () => number;
  getLuckMultiplier: () => number;
  getPrestigeMultiplier: () => number;
  getClanBonus: () => { clickBonus: number; autoMineBonus: number };
  getClanLevelInfo: () => { level: number; title: string; nextLevelCrystals: number | null };
}

const STORAGE_KEY = 'ice-empire-save-v2';

export const useGameStore = create<GameState>()(
  persist(
    (set, get) => ({
      // Initial state
      crystals: 10,
      iceShards: 0,
      auroraEssence: 0,
      northCrowns: 0,
      telegramStars: 50,
      playerLevel: 1,
      playerXp: 0,
      prestigeLevel: 0,
      totalEarned: 0,
      lastTick: Date.now(),
      ownedCreatures: { c1: { id: 'c1', level: 1, unlocked: true } },
      unlockedLocations: ['l1'],
      currentLocation: 'l1',
      activeBoss: null,
      lastBossDefeat: {},
      bossesDefeated: 0,
      ownedArtifacts: [],
      equippedArtifacts: [],
      clan: { id: null, name: null, treasury: 0, members: [], level: 1 },
      lastDailyClaim: 0,
      dailyStreak: 0,
      chestPurchases: {},
      totalClicks: 0,
      totalChestsOpened: 0,
      joinedAt: Date.now(),
      playerName: 'Повелитель Льда',
      selectedFrame: null,
      selectedSkin: 'ps1',
      ownedFrames: [],
      ownedSkins: ['ps1'],
      telegramAvatarUrl: null,
      telegramUserId: null,
      seasonXp: 0,
      seasonPremium: false,
      seasonClaimedFree: [],
      seasonClaimedPremium: [],
      seasonTapCount: 0,
      chatMessages: [],

      // ===== Currency actions =====
      addCrystals: (amount) =>
        set((s) => ({
          crystals: s.crystals + amount,
          totalEarned: s.totalEarned + (amount > 0 ? amount : 0),
        })),
      addIceShards: (amount) => set((s) => ({ iceShards: s.iceShards + amount })),
      addAuroraEssence: (amount) => set((s) => ({ auroraEssence: s.auroraEssence + amount })),
      addNorthCrowns: (amount) => set((s) => ({ northCrowns: s.northCrowns + amount })),
      addStars: (amount) => set((s) => ({ telegramStars: s.telegramStars + amount })),
      spendCrystals: (amount) => {
        const s = get();
        if (s.crystals < amount) return false;
        set({ crystals: s.crystals - amount });
        return true;
      },
      spendStars: (amount) => {
        const s = get();
        if (s.telegramStars < amount) return false;
        set({ telegramStars: s.telegramStars - amount });
        return true;
      },
      spendIceShards: (amount) => {
        const s = get();
        if (s.iceShards < amount) return false;
        set({ iceShards: s.iceShards - amount });
        return true;
      },
      spendAuroraEssence: (amount) => {
        const s = get();
        if (s.auroraEssence < amount) return false;
        set({ auroraEssence: s.auroraEssence - amount });
        return true;
      },

      // ===== Income =====
      tickIncome: () => {
        const s = get();
        const now = Date.now();
        const elapsed = (now - s.lastTick) / 1000;
        if (elapsed < 1) return;
        const income = s.getIncomePerSecond() * elapsed;

        // Boss life drain mechanic
        let drain = 0;
        if (s.activeBoss) {
          const boss = BOSSES.find((b) => b.id === s.activeBoss!.bossId);
          if (boss?.mechanic?.drainPerSecond) {
            drain = income * (boss.mechanic.drainPerSecond / 100) * elapsed;
          }
        }

        const netIncome = Math.max(0, income - drain);
        set({
          crystals: s.crystals + netIncome,
          totalEarned: s.totalEarned + netIncome,
          lastTick: now,
        });
      },
      collectOfflineIncome: () => {
        const s = get();
        const now = Date.now();
        const elapsed = Math.min((now - s.lastTick) / 1000, 8 * 3600);
        if (elapsed < 60) return 0;
        const income = s.getIncomePerSecond() * elapsed;
        set({
          crystals: s.crystals + income,
          totalEarned: s.totalEarned + income,
          lastTick: now,
        });
        return income;
      },

      // ===== Creatures =====
      buyCreature: (creatureId) => {
        const s = get();
        const creature = getCreatureById(creatureId);
        if (!creature) return false;
        const owned = s.ownedCreatures[creatureId];
        if (owned?.unlocked) return false;
        const cost = creature.baseCost;
        if (s.crystals < cost) return false;
        set({
          crystals: s.crystals - cost,
          ownedCreatures: {
            ...s.ownedCreatures,
            [creatureId]: { id: creatureId, level: 1, unlocked: true },
          },
        });
        return true;
      },
      upgradeCreature: (creatureId) => {
        const s = get();
        const creature = getCreatureById(creatureId);
        if (!creature) return false;
        const owned = s.ownedCreatures[creatureId];
        if (!owned?.unlocked) return false;
        const cost = getUpgradeCost(creature, owned.level);
        if (s.crystals < cost) return false;
        set({
          crystals: s.crystals - cost,
          ownedCreatures: {
            ...s.ownedCreatures,
            [creatureId]: { ...owned, level: owned.level + 1 },
          },
          seasonXp: s.seasonXp + SEASON_XP_REWARDS.creatureUpgrade,
        });
        return true;
      },

      // ===== Locations =====
      unlockLocation: (locationId) => {
        const s = get();
        const loc = LOCATIONS.find((l) => l.id === locationId);
        if (!loc) return false;
        if (s.unlockedLocations.includes(locationId)) return false;
        if (s.crystals < loc.unlockCost) return false;
        set({
          crystals: s.crystals - loc.unlockCost,
          unlockedLocations: [...s.unlockedLocations, locationId],
          currentLocation: locationId,
        });
        return true;
      },
      setCurrentLocation: (locationId) => {
        const s = get();
        if (!s.unlockedLocations.includes(locationId)) return;
        set({ currentLocation: locationId });
      },

      // ===== Bosses =====
      attackBoss: (damage) => {
        const s = get();
        if (!s.activeBoss) return { defeated: false };
        const boss = BOSSES.find((b) => b.id === s.activeBoss!.bossId);
        if (!boss) return { defeated: false };

        // Apply damage reduction mechanic
        let actualDamage = damage;
        let reflectedDamage = 0;
        if (boss.mechanic?.damageReduction) {
          actualDamage = damage * (1 - boss.mechanic.damageReduction / 100);
        }
        if (boss.mechanic?.reflectDamage) {
          reflectedDamage = damage * (boss.mechanic.reflectDamage / 100);
        }

        // Check time-freeze immunity
        if (boss.mechanic?.immuneInterval) {
          const elapsed = (Date.now() - (s.activeBoss.endTime - boss.duration * 3600 * 1000)) / 1000;
          const cyclePosition = elapsed % boss.mechanic.immuneInterval;
          if (cyclePosition > boss.mechanic.immuneInterval - 3) {
            // Boss is immune for 3 seconds at the end of each cycle
            return { defeated: false, reflectedDamage: 0 };
          }
        }

        // Phase mechanic — increase boss power at 50% HP
        let currentPhase = s.activeBoss.phase || 1;
        if (boss.mechanic?.phases && boss.mechanic.phases >= 2) {
          const hpPercent = s.activeBoss.currentHp / s.activeBoss.maxHp;
          if (hpPercent <= 0.5 && currentPhase === 1) {
            currentPhase = 2;
            // In phase 2, boss deals more reflected damage
            reflectedDamage *= 2;
          }
        }

        const newHp = Math.max(0, s.activeBoss.currentHp - actualDamage);
        const defeated = newHp <= 0;

        // Subtract reflected damage from crystals
        if (reflectedDamage > 0) {
          set({ crystals: Math.max(0, s.crystals - reflectedDamage) });
        }

        if (defeated) {
          set({
            activeBoss: null,
            crystals: s.crystals + boss.reward - reflectedDamage,
            totalEarned: s.totalEarned + boss.reward,
            auroraEssence: s.auroraEssence + boss.auroraEssence,
            bossesDefeated: s.bossesDefeated + 1,
            lastBossDefeat: { ...s.lastBossDefeat, [boss.id]: Date.now() },
            ownedArtifacts:
              Math.random() * 100 < boss.artifactChance && ARTIFACTS.length > 0
                ? [...s.ownedArtifacts, ARTIFACTS[Math.floor(Math.random() * ARTIFACTS.length)].id]
                : s.ownedArtifacts,
            seasonXp: s.seasonXp + SEASON_XP_REWARDS.bossKill,
          });
          return { defeated: true, reward: boss.reward, reflectedDamage };
        }

        set({
          activeBoss: {
            ...s.activeBoss,
            currentHp: newHp,
            damageDealt: s.activeBoss.damageDealt + actualDamage,
            phase: currentPhase,
          },
        });
        return { defeated: false, reflectedDamage };
      },
      startBoss: (bossId) => {
        const s = get();
        if (s.activeBoss) return { success: false, error: 'У тебя уже активен босс' };
        const boss = BOSSES.find((b) => b.id === bossId);
        if (!boss) return { success: false, error: 'Босс не найден' };

        // Check requirements
        const reqCheck = checkBossRequirements(boss, s.ownedCreatures);
        if (!reqCheck.met) {
          return { success: false, error: `Требуется: ${reqCheck.missing.join(', ')}` };
        }

        set({
          activeBoss: {
            bossId,
            currentHp: boss.maxHp,
            maxHp: boss.maxHp,
            endTime: Date.now() + boss.duration * 3600 * 1000,
            damageDealt: 0,
            phase: 1,
          },
        });
        return { success: true };
      },

      // ===== Chests (dynamic pricing + frame drops) =====
      getCurrentChestCost: (chestId) => {
        const s = get();
        const chest = CHESTS.find((c) => c.id === chestId);
        if (!chest) return 0;

        const record = s.chestPurchases[chestId];
        if (!record) return chest.baseCost;

        // Check if 3-day reset is needed
        const now = Date.now();
        if (now - record.lastPurchaseTime >= CHEST_PRICE_RESET_INTERVAL) {
          return chest.baseCost;
        }

        return getChestCost(chest, record.count);
      },
      getNextChestResetTime: () => {
        const s = get();
        let earliestReset = Infinity;
        for (const record of Object.values(s.chestPurchases)) {
          if (record.count > 0) {
            const resetTime = record.lastPurchaseTime + CHEST_PRICE_RESET_INTERVAL;
            if (resetTime < earliestReset) {
              earliestReset = resetTime;
            }
          }
        }
        return earliestReset === Infinity ? 0 : earliestReset;
      },
      openChest: (chestId) => {
        const s = get();
        const chest = CHESTS.find((c) => c.id === chestId);
        if (!chest) return { items: [], success: false, error: 'Сундук не найден' };

        // Get current dynamic cost
        const currentCost = s.getCurrentChestCost(chestId);

        let canAfford = false;
        if (chest.currency === 'crystals') {
          canAfford = s.crystals >= currentCost;
        } else {
          canAfford = s.telegramStars >= currentCost;
        }
        if (!canAfford) {
          return { items: [], success: false, error: 'Недостаточно валюты' };
        }

        // Deduct cost
        if (chest.currency === 'crystals') {
          set({ crystals: s.crystals - currentCost });
        } else {
          set({ telegramStars: s.telegramStars - currentCost });
        }

        // Update purchase record
        const now = Date.now();
        const existing = s.chestPurchases[chestId];
        let newCount: number;

        // Reset count if 3 days have passed
        if (existing && now - existing.lastPurchaseTime >= CHEST_PRICE_RESET_INTERVAL) {
          newCount = 1;
        } else {
          newCount = (existing?.count || 0) + 1;
        }

        set({
          chestPurchases: {
            ...s.chestPurchases,
            [chestId]: { chestId, count: newCount, lastPurchaseTime: now },
          },
        });

        // Generate multiple items based on chest.itemCount
        const itemCount = chest.itemCount || 1;
        const items: Array<{
          type: 'creature' | 'frame';
          rarity: Rarity;
          creature?: Creature;
          frame?: ProfileFrame;
          isDuplicate: boolean;
          shardReward?: number;
        }> = [];

        // Track state changes to batch them
        let currentOwnedCreatures = { ...s.ownedCreatures };
        let currentOwnedFrames = [...s.ownedFrames];
        let shardsGained = 0;
        let newFrames: string[] = [];

        for (let i = 0; i < itemCount; i++) {
          // Determine rarity
          const rarity = getRandomRarity(chest.rarityDrops);

          // Determine if frame drop or creature drop
          const frameChance = chest.frameDropChance || 15; // default 15% for non-skin chests
          const isFrameDrop = Math.random() * 100 < frameChance;

          if (isFrameDrop) {
            // Drop a profile frame
            const frame = getFrameFromRarity(rarity, currentOwnedFrames);
            const isDuplicate = currentOwnedFrames.includes(frame.id);

            if (isDuplicate) {
              const shardReward = Math.floor(500 * Math.pow(3, RARITY_META_ORDER[frame.rarity] - 1));
              shardsGained += shardReward;
              items.push({ type: 'frame', rarity, frame, isDuplicate: true, shardReward });
            } else {
              currentOwnedFrames = [...currentOwnedFrames, frame.id];
              newFrames.push(frame.id);
              items.push({ type: 'frame', rarity, frame, isDuplicate: false });
            }
          } else {
            // Drop a creature
            const creature = getCreatureFromRarity(rarity, currentOwnedCreatures);
            if (currentOwnedCreatures[creature.id]?.unlocked) {
              // Already owned — convert to ice shards
              const shardReward = Math.floor(creature.baseCost * 0.3);
              shardsGained += shardReward;
              items.push({ type: 'creature', creature, rarity, isDuplicate: true, shardReward });
            } else {
              currentOwnedCreatures[creature.id] = { id: creature.id, level: 1, unlocked: true };
              items.push({ type: 'creature', creature, rarity, isDuplicate: false });
            }
          }
        }

        // Batch update all state changes
        set({
          ownedCreatures: currentOwnedCreatures,
          ownedFrames: currentOwnedFrames,
          iceShards: s.iceShards + shardsGained,
          totalChestsOpened: s.totalChestsOpened + 1,
          seasonXp: s.seasonXp + SEASON_XP_REWARDS.chestOpen,
        });

        return { items, success: true };
      },

      // ===== Donate =====
      purchaseDonatePack: (packId) => {
        const s = get();
        const pack = DONATE_PACKS.find((p) => p.id === packId);
        if (!pack) return { success: false, error: 'Пакет не найден' };

        if (s.telegramStars < pack.stars) {
          return { success: false, error: 'Недостаточно Telegram Stars' };
        }

        // In production, this would call Telegram.WebApp.openInvoice()
        // For now, deduct stars and add crystals
        set({
          telegramStars: s.telegramStars - pack.stars,
          crystals: s.crystals + pack.crystals,
          totalEarned: s.totalEarned + pack.crystals,
        });

        return { success: true, crystalsAdded: pack.crystals };
      },

      // ===== Clan =====
      createClan: (name) => {
        const s = get();
        if (s.clan.id) return;
        const clanId = 'clan_' + Date.now();
        const member: ClanMember = {
          id: 'player_' + Date.now(),
          name: 'Повелитель Льда',
          contribution: 0,
          joinedAt: Date.now(),
        };
        set({
          clan: {
            id: clanId,
            name: name.trim(),
            treasury: 0,
            members: [member],
            level: 1,
          },
        });
      },
      leaveClan: () => {
        set({
          clan: { id: null, name: null, treasury: 0, members: [], level: 1 },
        });
      },
      contributeToClan: (amount) => {
        const s = get();
        if (!s.clan.id) return false;
        if (s.crystals < amount) return false;

        const newTreasury = s.clan.treasury + amount;
        const clanLevelInfo = getClanLevel(newTreasury);

        // Update member contribution
        const members = s.clan.members.map((m) =>
          m.id.startsWith('player_')
            ? { ...m, contribution: m.contribution + amount }
            : m
        );

        set({
          crystals: s.crystals - amount,
          clan: {
            ...s.clan,
            treasury: newTreasury,
            members,
            level: clanLevelInfo.level,
          },
          seasonXp: s.seasonXp + SEASON_XP_REWARDS.clanContribute,
        });
        return true;
      },

      // ===== Daily rewards =====
      claimDailyReward: () => {
        const s = get();
        const now = Date.now();
        const dayMs = 24 * 3600 * 1000;
        if (now - s.lastDailyClaim < dayMs) {
          return { claimed: false };
        }
        const newStreak = now - s.lastDailyClaim < 2 * dayMs ? s.dailyStreak + 1 : 1;
        const dayIndex = Math.min(newStreak - 1, 29);
        const reward = [
          { type: 'crystals', amount: 5, label: '5 💎' },
          { type: 'shards', amount: 5, label: '5 ❄️' },
          { type: 'crystals', amount: 10, label: '10 💎' },
          { type: 'crystals', amount: 15, label: '15 💎 (сундук)' },
          { type: 'crystals', amount: 20, label: '20 💎' },
          { type: 'shards', amount: 10, label: '10 ❄️' },
          { type: 'crystals', amount: 30, label: '30 💎 (Epic существо)' },
          { type: 'crystals', amount: 40, label: '40 💎' },
          { type: 'shards', amount: 15, label: '15 ❄️' },
          { type: 'crystals', amount: 60, label: '60 💎' },
          { type: 'crystals', amount: 80, label: '80 💎' },
          { type: 'crystals', amount: 100, label: '100 💎' },
          { type: 'crystals', amount: 130, label: '130 💎' },
          { type: 'crystals', amount: 170, label: '170 💎 (Legendary существо)' },
          { type: 'crystals', amount: 200, label: '200 💎' },
          { type: 'crystals', amount: 250, label: '250 💎' },
          { type: 'crystals', amount: 300, label: '300 💎' },
          { type: 'crystals', amount: 350, label: '350 💎' },
          { type: 'crystals', amount: 400, label: '400 💎' },
          { type: 'crystals', amount: 500, label: '500 💎' },
          { type: 'crystals', amount: 700, label: '700 💎 (Сундук Авроры)' },
          { type: 'crystals', amount: 900, label: '900 💎' },
          { type: 'crystals', amount: 1200, label: '1.2K 💎' },
          { type: 'crystals', amount: 1500, label: '1.5K 💎' },
          { type: 'crystals', amount: 2000, label: '2K 💎' },
          { type: 'crystals', amount: 2500, label: '2.5K 💎' },
          { type: 'crystals', amount: 3000, label: '3K 💎' },
          { type: 'crystals', amount: 4000, label: '4K 💎' },
          { type: 'crystals', amount: 5000, label: '5K 💎' },
          { type: 'crystals', amount: 8000, label: '8K 💎 (Legendary сундук)' },
        ][dayIndex];

        set({
          lastDailyClaim: now,
          dailyStreak: newStreak,
          crystals: s.crystals + reward.amount,
          iceShards: reward.type === 'shards' ? s.iceShards + reward.amount : s.iceShards,
          seasonXp: s.seasonXp + SEASON_XP_REWARDS.dailyClaim,
        });
        return { claimed: true, reward: reward.label };
      },

      // ===== Artifacts =====
      equipArtifact: (artifactId) => {
        const s = get();
        if (!s.ownedArtifacts.includes(artifactId)) return;
        if (s.equippedArtifacts.includes(artifactId)) return;
        if (s.equippedArtifacts.length >= 6) return;
        set({ equippedArtifacts: [...s.equippedArtifacts, artifactId] });
      },
      unequipArtifact: (artifactId) => {
        const s = get();
        set({ equippedArtifacts: s.equippedArtifacts.filter((id) => id !== artifactId) });
      },

      // ===== Prestige =====
      prestige: () => {
        const s = get();
        const requiredLevel = 100;
        if (s.playerLevel < requiredLevel) {
          return { success: false };
        }
        const crownsGained = Math.floor(Math.sqrt(s.totalEarned / 1000000));
        if (crownsGained < 1) return { success: false };

        set({
          crystals: 100,
          iceShards: s.iceShards,
          auroraEssence: s.auroraEssence,
          northCrowns: s.northCrowns + crownsGained,
          telegramStars: s.telegramStars,
          playerLevel: 1,
          playerXp: 0,
          prestigeLevel: s.prestigeLevel + 1,
          totalEarned: 0,
          lastTick: Date.now(),
          ownedCreatures: { c1: { id: 'c1', level: 1, unlocked: true } },
          unlockedLocations: ['l1'],
          currentLocation: 'l1',
          activeBoss: null,
          seasonXp: s.seasonXp + SEASON_XP_REWARDS.prestige,
        });
        return { success: true, crownsGained };
      },

      // ===== Season Pass =====
      addSeasonXp: (amount) =>
        set((s) => ({ seasonXp: s.seasonXp + amount })),

      claimSeasonTier: (tierLevel, track) => {
        const s = get();
        const tier = SEASON_PASS.tiers.find((t) => t.level === tierLevel);
        if (!tier) return { success: false, error: 'Тир не найден' };

        // Check if tier is unlocked
        const progress = getSeasonProgress(s.seasonXp);
        if (tierLevel > progress.currentTier + 1) {
          return { success: false, error: 'Тир ещё не открыт' };
        }
        if (tierLevel > progress.currentTier) {
          return { success: false, error: 'Недостаточно XP' };
        }

        if (track === 'free') {
          if (s.seasonClaimedFree.includes(String(tierLevel))) {
            return { success: false, error: 'Награда уже получена' };
          }
          const reward = tier.freeReward;
          // Apply reward
          const updates: Partial<GameState> = {
            seasonClaimedFree: [...s.seasonClaimedFree, String(tierLevel)],
          };
          if (reward.type === 'crystals') updates.crystals = s.crystals + reward.amount;
          else if (reward.type === 'iceShards') updates.iceShards = s.iceShards + reward.amount;
          else if (reward.type === 'auroraEssence') updates.auroraEssence = s.auroraEssence + reward.amount;
          else if (reward.type === 'stars') updates.telegramStars = s.telegramStars + reward.amount;
          else if (reward.type === 'frame' && reward.itemId) updates.ownedFrames = [...s.ownedFrames, reward.itemId];
          else if (reward.type === 'skin' && reward.itemId) updates.ownedSkins = [...s.ownedSkins, reward.itemId];
          set(updates as any);
          return { success: true, reward };
        } else {
          // Premium track
          if (!s.seasonPremium) {
            return { success: false, error: 'Нужен премиум-пропуск' };
          }
          if (s.seasonClaimedPremium.includes(String(tierLevel))) {
            return { success: false, error: 'Награда уже получена' };
          }
          const reward = tier.premiumReward;
          const updates: Partial<GameState> = {
            seasonClaimedPremium: [...s.seasonClaimedPremium, String(tierLevel)],
          };
          if (reward.type === 'crystals') updates.crystals = s.crystals + reward.amount;
          else if (reward.type === 'iceShards') updates.iceShards = s.iceShards + reward.amount;
          else if (reward.type === 'auroraEssence') updates.auroraEssence = s.auroraEssence + reward.amount;
          else if (reward.type === 'stars') updates.telegramStars = s.telegramStars + reward.amount;
          else if (reward.type === 'frame' && reward.itemId) updates.ownedFrames = [...s.ownedFrames, reward.itemId];
          else if (reward.type === 'skin' && reward.itemId) updates.ownedSkins = [...s.ownedSkins, reward.itemId];
          set(updates as any);
          return { success: true, reward };
        }
      },

      purchaseSeasonPremium: () => {
        const s = get();
        if (s.seasonPremium) return { success: false, error: 'Премиум уже активен' };
        if (s.telegramStars < SEASON_PASS.premiumCost) {
          return { success: false, error: 'Недостаточно Telegram Stars' };
        }
        // In production: call Telegram.WebApp.openInvoice()
        set({
          telegramStars: s.telegramStars - SEASON_PASS.premiumCost,
          seasonPremium: true,
        });
        return { success: true };
      },

      getSeasonTierStatus: (tierLevel) => {
        const s = get();
        const progress = getSeasonProgress(s.seasonXp);
        const unlocked = tierLevel <= progress.currentTier;
        return {
          freeUnlocked: unlocked,
          premiumUnlocked: unlocked && s.seasonPremium,
          freeClaimed: s.seasonClaimedFree.includes(String(tierLevel)),
          premiumClaimed: s.seasonClaimedPremium.includes(String(tierLevel)),
        };
      },

      // ===== Profile =====
      setSelectedFrame: (frameId) => set({ selectedFrame: frameId }),
      setSelectedSkin: (skinId) => set({ selectedSkin: skinId }),
      setPlayerName: (name) => set({ playerName: name }),
      setTelegramAvatar: (url, userId) => set({ telegramAvatarUrl: url, telegramUserId: userId }),

      // ===== Chat =====
      sendChatMessage: (text) => {
        const s = get();
        if (!text.trim()) return;
        const msg: ChatMessage = {
          id: 'msg_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8),
          playerId: s.telegramUserId || 'local_player',
          playerName: s.playerName,
          playerLevel: s.playerLevel,
          frameId: s.selectedFrame,
          skinId: s.selectedSkin,
          avatarUrl: s.telegramAvatarUrl,
          text: text.trim().slice(0, 200),
          timestamp: Date.now(),
        };
        const updated = [...s.chatMessages, msg].slice(-100); // keep last 100
        set({ chatMessages: updated });
        // Also save to localStorage for cross-session persistence
        try {
          localStorage.setItem('ice-empire-chat', JSON.stringify(updated));
        } catch {}
      },
      loadChatMessages: () => {
        try {
          const saved = localStorage.getItem('ice-empire-chat');
          if (saved) {
            const msgs = JSON.parse(saved) as ChatMessage[];
            set({ chatMessages: msgs.slice(-100) });
          }
        } catch {}
      },

      resetGame: () => {
        set({
          crystals: 100,
          iceShards: 0,
          auroraEssence: 0,
          northCrowns: 0,
          telegramStars: 50,
          playerLevel: 1,
          playerXp: 0,
          prestigeLevel: 0,
          totalEarned: 0,
          lastTick: Date.now(),
          ownedCreatures: { c1: { id: 'c1', level: 1, unlocked: true } },
          unlockedLocations: ['l1'],
          currentLocation: 'l1',
          activeBoss: null,
          lastBossDefeat: {},
          bossesDefeated: 0,
          ownedArtifacts: [],
          equippedArtifacts: [],
          clan: { id: null, name: null, treasury: 0, members: [], level: 1 },
          lastDailyClaim: 0,
          dailyStreak: 0,
          chestPurchases: {},
          totalClicks: 0,
          totalChestsOpened: 0,
          joinedAt: Date.now(),
          playerName: 'Повелитель Льда',
          selectedFrame: null,
          selectedSkin: 'ps1',
          ownedFrames: [],
          ownedSkins: ['ps1'],
          telegramAvatarUrl: null,
          telegramUserId: null,
          seasonXp: 0,
          seasonPremium: false,
          seasonClaimedFree: [],
          seasonClaimedPremium: [],
          seasonTapCount: 0,
          chatMessages: [],
        });
      },

      // ===== Derived getters =====
      getIncomePerSecond: () => {
        const s = get();
        let total = 0;
        Object.values(s.ownedCreatures).forEach((owned) => {
          if (owned.unlocked) {
            const creature = getCreatureById(owned.id);
            if (creature) {
              total += getCreatureIncome(creature, owned.level);
            }
          }
        });
        const loc = LOCATIONS.find((l) => l.id === s.currentLocation);
        const locMult = loc ? loc.incomeMultiplier : 1;
        const prestigeMult = 1 + s.northCrowns * 0.1;
        const artifactBonus = s.getTotalIncomeMultiplier();
        const clanBonus = s.getClanBonus().autoMineBonus / 100 + 1;
        return total * locMult * prestigeMult * artifactBonus * clanBonus;
      },

      getTotalIncomeMultiplier: () => {
        const s = get();
        let mult = 1;
        s.equippedArtifacts.forEach((artId) => {
          const art = ARTIFACTS.find((a) => a.id === artId);
          if (art && art.bonusType === 'income') {
            mult += art.bonusValue / 100;
          }
        });
        return mult;
      },

      getLuckMultiplier: () => {
        const s = get();
        let mult = 1;
        s.equippedArtifacts.forEach((artId) => {
          const art = ARTIFACTS.find((a) => a.id === artId);
          if (art && art.bonusType === 'luck') {
            mult += art.bonusValue / 100;
          }
        });
        return mult;
      },

      getPrestigeMultiplier: () => {
        const s = get();
        let mult = 1;
        s.equippedArtifacts.forEach((artId) => {
          const art = ARTIFACTS.find((a) => a.id === artId);
          if (art && art.bonusType === 'prestige') {
            mult += art.bonusValue / 100;
          }
        });
        return mult;
      },

      getClanBonus: () => {
        const s = get();
        if (!s.clan.id) return { clickBonus: 0, autoMineBonus: 0 };
        const clanLevelInfo = getClanLevel(s.clan.treasury);
        return {
          clickBonus: clanLevelInfo.clickBonus,
          autoMineBonus: clanLevelInfo.autoMineBonus,
        };
      },

      getClanLevelInfo: () => {
        const s = get();
        const currentLevel = getClanLevel(s.clan.treasury);
        const nextLevel = getNextClanLevel(s.clan.treasury);
        return {
          level: currentLevel.level,
          title: currentLevel.title,
          nextLevelCrystals: nextLevel ? nextLevel.requiredTreasury - s.clan.treasury : null,
        };
      },
    }),
    {
      name: STORAGE_KEY,
      storage: createJSONStorage(() => localStorage),
    }
  )
);
